<?php
/**
 * @var yii\web\View $this
 * @var              $first_name
 * @var              $sign_in_url
 * @var              $password
 */

use yii\helpers\Html;

?>
<p>
    Hello <?= Html::encode($first_name) ?>,<br>
    Welcome to ACT
</p>
<p>
    You can log in <a href="<?= $sign_in_url ?>"><?= $sign_in_url ?></a> .
</p>
<p>
    Use your email address as login.<br>
    Your password has been temporarily set to : <?= $password ?>
</p>
<p>
    Thank you, and welcome.<br>
    ACT team.
</p>
