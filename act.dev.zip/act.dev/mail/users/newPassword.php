<?php
/**
 * @var yii\web\View $this
 * @var              $first_name
 * @var              $sign_in_url
 * @var              $password
 */

use yii\helpers\Html;

?>
<p>
    Hello <?= Html::encode($first_name) ?>,<br>
    Your password was reset.
</p>
<p>
    You can log in <a href="<?= $sign_in_url ?>"><?= $sign_in_url ?></a> .
</p>
<p>
    Please use your email address to login.<br>
    Your password has been temporarily set to : <?= $password ?>
</p>
<p>
    Thank you.<br>
    ACT team.
</p>
