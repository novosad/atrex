<?php
/**
 * @var yii\web\View $this
 * @var              $first_name
 * @var              $url
 */

use yii\helpers\Html;

?>
<p>
    Hello <?= Html::encode($first_name) ?>,<br>
</p>
<p>
    We all lose our marbles. Visit this link to reset your password:
</p>
<p>
    <a href="<?= $url ?>"><?= $url ?></a>
</p>
<p>
    If the password comes back to you, just ignore this email.
</p>
<p>
    We've got your back.<br>
    ACT team.
</p>

