<?php
/**
 * @var yii\web\View $this
 * @var              $body
 */

?>
<p>
    <?= $body ?>
</p>
