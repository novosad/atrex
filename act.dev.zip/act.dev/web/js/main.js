
function showMessage(type, message) {
    $("html, body").animate({
        scrollTop: 0
    }, "fast", function () {
        var cnt = $('._alert._alert-' + type);
        cnt.find('.message').html(message);
        cnt.slideDown("fast", function () {
            tableHeight();
        });
    });
    console.log('show msg and set time out for hide');
    setTimeout(hideMessage, 3000);
}

var hm = null;

function hideMessage() {
    if (hm != null)  clearTimeout(hm);
    hm = setTimeout( function () {
        console.log('hide msg');
        $('._alert').slideUp("fast", function () {
            tableHeight();
        });
    }, 50);
}

var th = null;

function tableHeight() {
    if (th != null)  clearTimeout(th);
    th = setTimeout( function () {
        console.log('resize table');
        var t = $('table.fixed-header');
        if (t.length > 0) {
            var fullHeight = window.innerHeight,
                $tableScroll = t.find('tbody'),
                topOffset = $tableScroll.offset().top;
            $tableScroll.css('height', fullHeight - topOffset + 'px');
        }
    }, 50);
}

tableHeight();
$(window).resize(function () {
    tableHeight();
});


$(function () {

    if ($('._alert:visible').length > 0) {
        setTimeout(hideMessage, 3000);
    }

    function attachConfirmationHandler() {
        $('[data-toggle="confirmation"]').confirmation({
            onConfirm: function (event, element) {
                var e = $(element.get(0)),
                    c = e.data('onclick');
                if (typeof c != 'undefined' && c.length > 0) {
                    eval(c);
                }
            }
        });
    }

    attachConfirmationHandler();

    $(document).ajaxStart(function () {
        //$('#loader').removeClass('hidden');
    });

    $(document).ajaxStop(function () {
        //$('#loader').addClass('hidden');
        // on pjax reload confirmations need to reattach and tableHeight to recall
        attachConfirmationHandler();
        tableHeight();
    });

    // to prevent pjax action when some out link present in grid
    $(document).on('click', '.link_out', function (e) {
        e.preventDefault();
        window.location.href = $(this).attr('href');
    });

    $('.iframe-loader').on('load', function () {
        $('.iframe-preloader').delay(100).fadeOut(50);
    });
});