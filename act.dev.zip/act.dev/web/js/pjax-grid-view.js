$(function () {
    var reload_timing = null;

    $(document).on("updateCounterEvent", function(e, count) {
        e.stopPropagation();
        var statusText = $('#selected_count'), totalCount = $('#list-table').attr('total_count');
        if (count > 0) {
            var selected = [];
            $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]:checked').each(function () {
                selected.push($(this).val());
            });
            if ((selected.length)) {
                // TODO: refactor
                // this is partial solution - we should include filter if we add select_all from all other pages or when some sort or filter presents
                // var filter = {'query': {'id': {'\$or': selected}}};
                // var query = encodeURIComponent(JSON.stringify(filter));
                // here is better to use selected.length
                statusText.html('Selected ' + count + ' from ' + totalCount);
            }
            $('.mass_actions button').removeClass('disabled').attr('disabled', false);
        } else {
            statusText.html('');
            $('.mass_actions button:not(.do_not_disable)').addClass('disabled').attr('disabled', true);
            $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]').prop('checked', false).parents('tr').toggleClass('selected', false);
            $('#pjax_grid_view input[type="checkbox"][class^="select-on-check-all"]').prop('checked', false);
        }
    });

    $(document).on('click', '#pjax_grid_view input[type="checkbox"][name^="ids"]:not(:disabled)', function (e) {
        e.stopPropagation();
        if ($(this).hasClass('select-on-check-all')) {
            var self = $(this);
            $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]:not(:disabled)').prop('checked', self.is(':checked')).parents('tr').toggleClass('selected', self.is(':checked'));
        } else {
            $(this).parents('tr').toggleClass('selected');
            $('#pjax_grid_view input[type="checkbox"][class^="select-on-check-all"]').prop('checked', false);
        }
        var count = 0;
        $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]').each(function () {
            if ($(this).is(":checked")) {
                count++;
            }
        });
        $(document).trigger( "updateCounterEvent", count);
    });

    $(document).on('click', '#pjax_grid_view th, #pjax_grid_view td', function () {
        $(this).find(':checkbox:not(:disabled)').click();
    });

    $(document).ajaxStart(function () {
        $(document).trigger( "updateCounterEvent", 0);
    });

    $(document).on("triggerReloadEvent", function(e, options) {
        e.stopPropagation();
        if (reload_timing != null)  clearTimeout(reload_timing);
        reload_timing = setTimeout(function () {
            var url = window.location.href;
            if (window.location.search.length) {
                var query = window.location.search.substring(1), vars = query.split("&"), query_string = [];
                for (var i = 0; i < vars.length; i++) {
                    if (typeof vars[i] != 'undefined' && vars[i].indexOf('page') !== 0 && vars[i].indexOf('filter') !== 0) {
                        query_string.push(vars[i]);
                    }
                }
                url = url.split("?")[0] + '?' + query_string.join('&');
            }
            $.pjax.reload({url: url, container: '#pjax_grid_view', type: 'GET', data: options}).success(function () {
            });
        }, 500);
    });

    $('#filter_search').on('change keyup paste input', function () {
        if ($(this).data('v') === $(this).val()) return;
        $(this).data('v', $(this).val());

        var self = $(this);
        var options = {
            'filter': {'search': $(this).val()}
        };

        $(document).trigger( "triggerReloadEvent", options);

        // todo: have not needed focus after clear search and some sort
        $('#pjax_grid_view').on('pjax:complete', function () {
            self.focus();
        });
    }).data('v', '');
});