<?php

namespace app\models;

use Yii;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\db\Expression;
use yii\web\IdentityInterface;

/**
 * Class User
 * @package app\models
 *
 * @property integer $id
 * @property string $first_name
 * @property string $last_name
 * @property string $email
 * @property string $password
 * @property string $role
 * @property string $created
 * @property string $updated
 * @property string $last_login
 * @property string $status
 * @property string $access_token
 * @property string $reset_token
 *
 */

class User extends ActiveRecord implements IdentityInterface
{
    const STATUS_ACTIVE  = 'active';
    const STATUS_BLOCKED = 'blocked';

    const ROLE_ADMIN   = 'administrator';
    const ROLE_MANAGER = 'manager';

    public static function tableName()
    {
        return 'user';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'first_name',
            'last_name',
            'email',
            'password',
            'role',
            'created',
            'updated',
            'last_login',
            'status',
            'access_token',
            'reset_token'
        ];
    }

    public function rules()
    {
        return [
            [['first_name', 'last_name'], 'required'],
            [['email'], 'email'],
            [
                ['status'],
                'in',
                'range' => [
                    static::STATUS_ACTIVE,
                    static::STATUS_BLOCKED,
                ]
            ],
            [
                ['role'],
                'in',
                'range' => [
                    static::ROLE_ADMIN,
                    static::ROLE_MANAGER,
                ]
            ],
            [['email', 'first_name', 'last_name'], 'filter', 'filter' => 'trim'],
            [['first_name', 'last_name'], 'filter', 'filter' => '\yii\helpers\HtmlPurifier::process'],
            [['password','created', 'updated', 'last_login', 'access_token', 'reset_token'], 'safe']
        ];
    }

    public function attributeLabels()
    {
        return [
            'id'         => Yii::t('app', 'User ID'),
            'first_name' => Yii::t('app', 'First Name'),
            'last_name'  => Yii::t('app', 'Last Name'),
            'email'      => Yii::t('app', 'Email'),
            'password'   => Yii::t('app', 'Password'),
            'created'    => Yii::t('app', 'Created'),
            'updated'    => Yii::t('app', 'Updated'),
            'last_login' => Yii::t('app', 'Last Login'),
            'status'     => Yii::t('app', 'Status')
        ];
    }

    public function behaviors()
    {
        return [
            [
                'class'      => TimestampBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created', 'updated'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated'],
                    'value' => new Expression('NOW()'),
                ]
            ]
        ];
    }

    public static function findIdentity($id)
    {
        return static::findOne($id);
    }

    public static function checkRole($user) {
        // check is role assigned and eq current role, if not - reassign.
        $auth = Yii::$app->authManager;
        $roles = $auth->getRolesByUser($user->id);
        if (empty($roles) || !isset($roles[$user->role])) {
            $role = $auth->getRole($user->role);
            $auth->revokeAll($user->id);
            $auth->assign($role, $user->id);
        }
    }

    public static function login($email, $password)
    {
        if ($user = self::findOne(['email' => $email, 'password' => $password])) {
            if (Yii::$app->user->login($user, isset(Yii::$app->params['sessionLifeTime']) ? Yii::$app->params['sessionLifeTime'] : 10800 )) {
                self::checkRole($user);
                return $user;
            }
        }
        return false;
    }

    public static function findIdentityByAccessToken($access_token, $type = null)
    {
        if ($access_token) {
            if ($identity = static::findOne(['access_token' => $access_token, 'status' => static::STATUS_ACTIVE])) {
                self::checkRole($identity);
                return $identity;
            }
        }
        return false;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getAuthKey()
    {
        return $this->access_token;
    }

    public function validateAuthKey($access_token)
    {
        return $this->access_token === $access_token;
    }

    public function beforeValidate()
    {
        if ($this->isNewRecord) {
            $this->access_token = Yii::$app->security->generateRandomString();
        }
        return parent::beforeValidate();
    }

    public function afterSave($insert, $changedAttributes)
    {
        if ($insert || isset($changedAttributes['role'])) {
            self::checkRole($this);
        }
        parent::afterSave($insert, $changedAttributes);
    }

    public function afterDelete()
    {
        $auth = Yii::$app->authManager;
        $auth->revokeAll($this->id);
        parent::afterDelete();
    }

    public static function logout()
    {
        Yii::$app->user->logout();
    }

}
