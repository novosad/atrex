<?php

namespace app\models;

use yii\base\Model;
use yii\db\Query;

class District extends Model
{
    public static function all($data_id, $state)
    {
        $result = [];
        $query = new Query();
        $data = $query->select(['district'])
            ->from('store_ret')
            ->distinct()
            ->where(['data_id' => $data_id, 'state' => $state])
            ->all();
        if($data) {
            foreach($data as $row) {
                $result[] = ['id' => $row['district'], 'text' => $row['district']];
            }
        }
        return $result;
    }
}
