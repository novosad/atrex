<?php

namespace app\models\forms\report;

use app\models\Data;
use app\models\forms\store\StoreCD;
use app\models\forms\store\StoreCSC;
use app\models\forms\store\StoreFIN;
use app\models\forms\store\StoreIST;
use app\models\forms\store\StoreMMB;
use app\models\forms\store\StorePFG;
use app\models\forms\store\StorePSE;
use app\models\forms\store\StoreRET;
use app\models\forms\store\StoreSMO;
use app\models\forms\store\StoreUD;
use app\models\State;
use Yii;
use yii\base\Model;

class DataForm extends Model
{
    public $data_id;
    public $state;
    public $district;
    public $region;

    public function rules()
    {
        return [
            [['data_id', 'state'], 'required'],
            [['district', 'region'], 'safe']
        ];
    }

    public function process()
    {
        if ($this->validate()) {
            if (isset($this->region)) {
                return $this->region();
            } else {
                if (isset($this->district)) {
                    return $this->district();
                }
            }
        }
        return false;
    }


    public function district()
    {
        $result = [];
        if ($data = Data::findOne($this->data_id)) {
            $result['year'] = $data->year;
            $result['total_act_state'] = StoreRET::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('white + black + hispanic + asian + pacific_islander + native_american + two_or_more + no_response_missing');
            $result['total_act_district'] = StoreRET::find()->where(['data_id' => $this->data_id, 'state' => $this->state, 'district' => $this->district])->sum('white + black + hispanic + asian + pacific_islander + native_american + two_or_more + no_response_missing');

            $result['tested_percent'] = StoreUD::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('percent');

            // ['white', 'black', 'hispanic', 'asian', 'pacific_islander', 'native_american', 'two_or_more', 'no_response_missing']
            $partitions = StoreRET::partitions();
            if ($ret_row = StoreRET::find()->select($partitions)->where(['data_id' => $this->data_id, 'state' => $this->state, 'district' => $this->district])->asArray()->one()) {
                $sum = array_sum($ret_row);
                foreach ($partitions as $partition) {
                    $result['district_backgrounds_percent'][$partition] = $ret_row[$partition] * 100 / $sum;
                }
            }

            $result['first_gen_district'] = StorePFG::find()->where(['data_id' => $this->data_id, 'state' => $this->state, 'district' => $this->district])->one()->yes * 100 / StorePFG::find()->where(['data_id' => $this->data_id, 'state' => $this->state, 'district' => $this->district])->sum('no + yes + undef');
            $result['first_gen_state']    = StorePFG::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('yes') * 100 / StorePFG::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('no + yes + undef');
            $result['first_gen_nation']   = StorePFG::find()->where(['data_id' => $this->data_id])->sum('yes') * 100 / StorePFG::find()->where(['data_id' => $this->data_id])->sum('no + yes + undef');


            $result['low_income_district'] = StoreFIN::find()->where(['data_id' => $this->data_id, 'state' => $this->state, 'district' => $this->district])->one()->yes * 100 / StoreFIN::find()->where(['data_id' => $this->data_id, 'state' => $this->state, 'district' => $this->district])->sum('no + yes + undef');
            $result['low_income_state']    = StoreFIN::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('yes') * 100 / StoreFIN::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('no + yes + undef');
            $result['low_income_nation']   = StoreFIN::find()->where(['data_id' => $this->data_id])->sum('yes') * 100 / StoreFIN::find()->where(['data_id' => $this->data_id])->sum('no + yes + undef');

            foreach(['_19', '19_23', '24_'] as $i) {
                $result['composite_score_' . $i . '_district'] = StoreCSC::find()->where(['data_id' => $this->data_id, 'state' => $this->state, 'district' => $this->district])->sum($i) * 100 / StoreCSC::find()->where(['data_id' => $this->data_id, 'state' => $this->state, 'district' => $this->district])->sum('_19 + 19_23 + 24_');
                $result['composite_score_' . $i . '_state']    = StoreCSC::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum($i) * 100 / StoreCSC::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('_19 + 19_23 + 24_');
                $result['composite_score_' . $i . '_nation']   = StoreCSC::find()->where(['data_id' => $this->data_id])->sum($i) * 100 / StoreCSC::find()->where(['data_id' => $this->data_id])->sum('_19 + 19_23 + 24_');
            }

            foreach(['overall', 'first-generation', 'low-income'] as $i) {
                $result['college_ready_benchmark_' . $i . '_district'] = StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state, 'district' => $this->district])->sum('yes') * 100 / StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state, 'district' => $this->district])->sum('no + yes');
                $result['college_ready_benchmark_' . $i . '_state']    = StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state])->sum('yes') * 100 / StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state])->sum('no + yes');
                $result['college_ready_benchmark_' . $i . '_nation']   = StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i])->sum('yes') * 100 / StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i])->sum('no + yes');
            }


            foreach(['overall', 'first-generation', 'low-income'] as $i) {
                $result['pse_' . $i . '_district_number'] = StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state, 'district' => $this->district])->sum('yes');
                $result['pse_' . $i . '_state_number']    = StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state])->sum('yes');
                $result['pse_' . $i . '_nation_number']   = StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i])->sum('yes');

                $result['pse_' . $i . '_district_percent'] = $result['pse_' . $i . '_district_number'] * 100 / StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state, 'district' => $this->district])->sum('no + yes');
                $result['pse_' . $i . '_state_percent']    = $result['pse_' . $i . '_state_number']    * 100 / StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state])->sum('no + yes');
                $result['pse_' . $i . '_nation_percent']   = $result['pse_' . $i . '_nation_number']   * 100 / StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i])->sum('no + yes');
            }

            foreach([
                        'fc' => 'First choice',
                        'fe' => 'First enrolled',
                        'fc_g' => 'First choice | First-generation+Low-income',
                        'fe_g' => 'First enrolled | First-generation+Low-income'] as $i => $section) {

                if ($cd_row = StoreCD::find()->where(['data_id' => $this->data_id, 'section' => $section, 'state' => $this->state, 'district' => $this->district])->orderBy('freq')->all()) {
                    foreach ($cd_row as $j => $row) {
                        $result['top_3_' . $i][$j] = $row->inst;
                    }
                }
            }

            $result['expressed_stem'] = StoreSMO::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('yes') * 100 / StoreSMO::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('no + yes');
            $result['measured_stem']  = StoreIST::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('yes') * 100 / StoreIST::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('no + yes');

            foreach([
                        'platinum',
                        'gold',
                        'silver',
                        'bronze'
                    ] as $i ) {

                $result['qw_aj_' . $i] = StoreUD::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->one()->$i;
            }

        }
        return $result;
    }

    public function region()
    {
        $result = [];
        if ($data = Data::findOne($this->data_id)) {

            $region_states = [];
            $_rs = State::all($this->region);
            foreach ($_rs as $_ro) {
                $region_states[] = $_ro['id'];
            }
            if (empty($region_states)) {
                return false;
            }

            $result['year'] = $data->year;
            $result['total_act_state'] = StoreRET::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('white + black + hispanic + asian + pacific_islander + native_american + two_or_more + no_response_missing');
            $result['total_act_district'] = StoreRET::find()->where(['data_id' => $this->data_id, 'state' => $region_states])->sum('white + black + hispanic + asian + pacific_islander + native_american + two_or_more + no_response_missing');
            $result['tested_percent'] = StoreUD::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('percent');

            // ['white', 'black', 'hispanic', 'asian', 'pacific_islander', 'native_american', 'two_or_more', 'no_response_missing']
            $partitions = StoreRET::partitions();
            if ($rows = StoreRET::find()->select($partitions)->where(['data_id' => $this->data_id, 'state' => $this->state])->asArray()->all()) {
                $sum = 0;
                $by_partition = [];
                foreach ($rows as $row) {
                    foreach ($partitions as $partition) {
                        !isset($by_partition[$partition]) && $by_partition[$partition] = 0;

                        $by_partition[$partition] += $row[$partition];
                        $sum += $row[$partition];
                    }
                }
                foreach ($partitions as $partition) {
                    $result['district_backgrounds_percent'][$partition] = $by_partition[$partition] * 100 / $sum;
                }
            }

            //   'state' => $region_states - for states located in region

            $result['first_gen_district'] = StorePFG::find()->where(['data_id' => $this->data_id, 'state' => $region_states])->sum('yes') * 100 / StorePFG::find()->where(['data_id' => $this->data_id, 'state' => $region_states])->sum('no + yes + undef');
            $result['first_gen_state']    = StorePFG::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('yes') * 100 / StorePFG::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('no + yes + undef');
            $result['first_gen_nation']   = StorePFG::find()->where(['data_id' => $this->data_id])->sum('yes') * 100 / StorePFG::find()->where(['data_id' => $this->data_id])->sum('no + yes + undef');


            $result['low_income_district'] = StoreFIN::find()->where(['data_id' => $this->data_id, 'state' => $region_states])->sum('yes') * 100 / StoreFIN::find()->where(['data_id' => $this->data_id, 'state' => $region_states])->sum('no + yes + undef');
            $result['low_income_state']    = StoreFIN::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('yes') * 100 / StoreFIN::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('no + yes + undef');
            $result['low_income_nation']   = StoreFIN::find()->where(['data_id' => $this->data_id])->sum('yes') * 100 / StoreFIN::find()->where(['data_id' => $this->data_id])->sum('no + yes + undef');

            foreach(['_19', '19_23', '24_'] as $i) {
                $result['composite_score_' . $i . '_district'] = StoreCSC::find()->where(['data_id' => $this->data_id, 'state' => $region_states])->sum($i) * 100 / StoreCSC::find()->where(['data_id' => $this->data_id, 'state' => $region_states])->sum('_19 + 19_23 + 24_');
                $result['composite_score_' . $i . '_state']    = StoreCSC::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum($i) * 100 / StoreCSC::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('_19 + 19_23 + 24_');
                $result['composite_score_' . $i . '_nation']   = StoreCSC::find()->where(['data_id' => $this->data_id])->sum($i) * 100 / StoreCSC::find()->where(['data_id' => $this->data_id])->sum('_19 + 19_23 + 24_');
            }

            foreach(['overall', 'first-generation', 'low-income'] as $i) {
                $result['college_ready_benchmark_' . $i . '_district'] = StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $region_states])->sum('yes') * 100 / StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $region_states])->sum('no + yes');
                $result['college_ready_benchmark_' . $i . '_state']    = StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state])->sum('yes') * 100 / StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state])->sum('no + yes');
                $result['college_ready_benchmark_' . $i . '_nation']   = StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i])->sum('yes') * 100 / StoreMMB::find()->where(['data_id' => $this->data_id, 'section' => $i])->sum('no + yes');
            }


            foreach(['overall', 'first-generation', 'low-income'] as $i) {
                $result['pse_' . $i . '_district_number'] = StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $region_states])->sum('yes');
                $result['pse_' . $i . '_state_number']    = StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state])->sum('yes');
                $result['pse_' . $i . '_nation_number']   = StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i])->sum('yes');

                $result['pse_' . $i . '_district_percent'] = $result['pse_' . $i . '_district_number'] * 100 / StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $region_states])->sum('no + yes');
                $result['pse_' . $i . '_state_percent']    = $result['pse_' . $i . '_state_number']    * 100 / StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i, 'state' => $this->state])->sum('no + yes');
                $result['pse_' . $i . '_nation_percent']   = $result['pse_' . $i . '_nation_number']   * 100 / StorePSE::find()->where(['data_id' => $this->data_id, 'section' => $i])->sum('no + yes');
            }

            foreach([
                        'fc' => 'First choice',
                        'fe' => 'First enrolled',
                        'fc_g' => 'First choice | First-generation+Low-income',
                        'fe_g' => 'First enrolled | First-generation+Low-income'] as $i => $section) {

                if ($cd_row = StoreCD::find()->where(['data_id' => $this->data_id, 'section' => $section, 'state' => $region_states])->orderBy('freq')->all()) {
                    foreach ($cd_row as $j => $row) {
                        $result['top_3_' . $i][$j] = $row->inst;
                    }
                }
            }

            $result['expressed_stem'] = StoreSMO::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('yes') * 100 / StoreSMO::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('no + yes');
            $result['measured_stem']  = StoreIST::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('yes') * 100 / StoreIST::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->sum('no + yes');

            foreach([
                        'platinum',
                        'gold',
                        'silver',
                        'bronze'
                    ] as $i ) {

                $result['qw_aj_' . $i] = StoreUD::find()->where(['data_id' => $this->data_id, 'state' => $this->state])->one()->$i;
            }
        }
        return $result;
    }
}