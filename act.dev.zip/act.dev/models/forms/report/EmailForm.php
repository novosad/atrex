<?php
namespace app\models\forms\report;

use app\models\Report;
use Yii;
use yii\base\Model;
use yii\web\ServerErrorHttpException;


class EmailForm extends Model
{
    public $id;
    public $email;
    public $cc;
    public $subject;
    public $body;

    public function rules()
    {
        return [
            [['id', 'email'], 'required'],
            [['email', 'cc'], 'email'],
            [['subject', 'body'], 'safe']
        ];
    }

    public function send()
    {
        if ($this->validate()) {
            if ($report = Report::findOne($this->id)) {

                $message = Yii::$app->mailer->compose('report/email', [
                    'body' => $this->body
                ])->setFrom(Yii::$app->params['mailFrom'])
                    ->setTo($this->email)
                    ->setSubject($this->subject);

                $filename = $report->template['type'] . '-' . $report->data['year'] . '(' . date('m/d/Y gA:i') . ').pdf';

                $message->attach($report->path, ['fileName' => $filename]);

                return $message->send() ? true : false;
            }
            throw new ServerErrorHttpException("Unable to find report");
        }
        return false;
    }
}
