<?php

namespace app\models\forms\report;

use app\components\web\ModelValidationException;
use app\models\Report;
use app\models\State;
use Yii;
use yii\base\Model;
use yii\helpers\ArrayHelper;

class CreateForm extends Model
{
    public $template_id;
    public $data_id;
    public $state;
    public $district;
    public $region;
    public $recipient;
    public $students_count;

    public function rules()
    {
        return [
            [['template_id', 'data_id', 'state'], 'required'],
            ['district', 'required', 'when' => function ($model) {return !isset($model->template_id) || $model->template_id != 4;}, 'whenClient' => "function (attribute, value) {return $('input[name*=\"template_id\"]:checked').val() != 4 ? true : false  ;}", 'message' => 'Required'],
            ['region',   'required', 'when' => function ($model) {return  isset($model->template_id) && $model->template_id == 4;}, 'whenClient' => "function (attribute, value) {return $('input[name*=\"template_id\"]:checked').val() == 4 ? true : false  ;}", 'message' => 'Required'],
            [['template_id', 'data_id'], 'integer'],
            [['recipient', 'students_count'], 'safe'],
        ];
    }

    public function attributeLabels()
    {
        return [
            'template_id'    => 'Choose Template',
            'data_id'        => 'Data',
            'state'          => 'Select State',
            'district'       => 'Select District',
            'region'         => 'Select Region',
            'recipient'      => 'Recipient',
            'students_count' => 'Students Count'
        ];
    }

    public function save()
    {
        if ($this->validate()) {
            if ($this->template_id == 4) {
                $this->district = null;
            } else {
                $this->region = null;
            }

            $model = new Report();
            $model->setAttributes(ArrayHelper::merge(
                $this->attributes,
                [
                    'state_name' =>  State::state_map($this->state),
                    'path'    => '',
                    'status'  => Report::STATUS_DRAFT,
                    'user_id' => Yii::$app->user->identity->getId(),
                ]
            ));

            if ($model->save()) {
                return $model->id;
            }
            throw new ModelValidationException($model);
        }
        return false;
    }
}