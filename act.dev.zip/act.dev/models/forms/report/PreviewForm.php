<?php

namespace app\models\forms\report;

use app\components\web\ModelValidationException;
use app\models\Report;
use Yii;
use yii\base\Model;
use Dompdf\Dompdf;
use Dompdf\Options;
use yii\web\ServerErrorHttpException;
use Exception;


class PreviewForm extends Model
{
    public $id;
    public $content;
    public $template_id;
    
    public function rules()
    {
        return [
            [['id', 'content', 'template_id'], 'required'],
        ];
    }

    public function process()
    {
        if ($this->validate()) {

            try {
                $options = new Options();
                $options->set('defaultFont', 'IdealSans');
                $dompdf = new Dompdf($options);
                $dompdf->loadHtml($this->content);
                $dompdf->setPaper('A4', ($this->template_id == 2 ? 'landscape' : 'portrait') );
                $dompdf->render();
                $pdf = $dompdf->output();
            } catch (Exception $e) {
                throw new Exception($e);
            }

            $reportPath = isset(Yii::$app->params['reportsPath']) ? Yii::$app->params['reportsPath'] : '@runtime/reports';
            $i = 100;
            $unique_id = uniqid();
            $path = Yii::getAlias($reportPath) . DIRECTORY_SEPARATOR;
            while (--$i >= 0 && file_exists($path . $unique_id)) {
                $unique_id = uniqid();
            }
            if (!$i) {
                throw new ServerErrorHttpException("Unable to generate unique safe filename");
            }

            $file_path = $path . DIRECTORY_SEPARATOR .  $unique_id;

            if (file_put_contents($file_path, $pdf)) {
                $report = Report::findOne($this->id);
                $report->path = $file_path;
                if ($report->save()) {
                    return $file_path;
                }
                throw new ModelValidationException($report);
            }
            throw new ServerErrorHttpException("Unable put file contents " . $reportPath);
        }
        return false;
    }
}