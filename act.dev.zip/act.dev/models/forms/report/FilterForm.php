<?php

namespace app\models\forms\report;

use app\models\Report;
use yii\base\Model;
use yii\data\ActiveDataProvider;

class FilterForm extends Model
{
    public $filter;
    public $status = Report::STATUS_ACTIVE;

    public function rules()
    {
        return [
            [['filter'], 'safe'],
            [
                ['status'],
                'in',
                'range' => [
                    Report::STATUS_ACTIVE,
                    Report::STATUS_ARCHIVED,
                ]
            ],

        ];
    }

    public function search()
    {
        if ($this->validate()) {
            $query = Report::find()->where(['in', 'report.status', [$this->status]]);
            $query->joinWith(['template', 'data']);
            isset($this->filter) && $query->andFilterWhere([
                'or',
                ['like', 'recipient', $this->filter],
                ['like', 'template.type', $this->filter],
                ['like', 'data.year', $this->filter],
                ['like', 'data.name', $this->filter],
                ['like', 'state_name', $this->filter],
                ['like', 'district', $this->filter],
                ['like', 'region', $this->filter],
            ]);

            $dataProvider = new ActiveDataProvider([
                'query' => $query,
                'sort'  => [
                    'attributes'   => [
                        'template.type',
                        'created',
                        'data.year',
                        'recipient',
                        'data.name',
                        'state_name',
                        'district',
                    ],
                    'defaultOrder' => [
                        'created' => SORT_DESC
                    ]
                ]
            ]);
            return $dataProvider;
        }
        return false;
    }
}