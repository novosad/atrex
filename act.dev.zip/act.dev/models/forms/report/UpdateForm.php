<?php

namespace app\models\forms\report;

use app\models\Report;
use Yii;
use yii\base\Model;

class UpdateForm extends Model
{
    public $ids;
    public $status;

    public function rules()
    {
        return [
            [['ids', 'status'], 'required'],
            ['ids', 'each', 'rule' => ['integer']],
            [
                ['status'],
                'in',
                'range' => [
                    Report::STATUS_ACTIVE,
                    Report::STATUS_ARCHIVED,
                    Report::STATUS_DELETED,
                    Report::STATUS_DRAFT,
                ]
            ]
        ];
    }

    public function save()
    {
        if ($this->validate()) {
            $count = 0;
            foreach ($this->ids as $id) {
                if ($model = Report::findOne(['id' => $id])) {
                    $model->status = $this->status;
                    $model->save() && $count++;
                }
            }
            return $count;
        }
        return false;
    }
}