<?php

namespace app\models\forms\user;

use app\models\User;
use Yii;
use yii\base\Model;

class LoginForm extends Model
{
    public $email;
    public $password;

    public function rules()
    {
        return [
            [['email', 'password'], 'required'],
            [['email'], 'email'],
            [['email'], 'filter', 'filter' => 'trim'],
        ];
    }

    public function login()
    {
        if ($this->validate()) {
            if ($user = User::login($this->email, md5($this->password))) {
                $user->last_login = time();
                $user->save();
                return true;
            } else {
                $this->addError('email', 'Login or password incorrect');
            }
        }
        return false;
    }
}
