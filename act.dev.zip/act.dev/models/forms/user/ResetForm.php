<?php

namespace app\models\forms\user;

use app\components\web\ModelValidationException;
use app\models\User;
use Yii;
use yii\base\Model;
use yii\helpers\Url;
use yii\web\ServerErrorHttpException;

class ResetForm extends Model
{
    public $email;

    public function rules()
    {
        return [
            [['email'], 'required'],
            [['email'], 'email'],
        ];
    }

    public function reset()
    {
        if ($this->validate()) {
            if ($user = User::findOne(['email' => $this->email, 'status' => User::STATUS_ACTIVE])) {

                $user->reset_token = Yii::$app->getSecurity()->generateRandomString();
                if ($user->save()) {

                    $result = Yii::$app->mailer->compose('users/resetPassword', [
                        'first_name' => $user->first_name,
                        'url'        => Url::to(['/user/password', 'reset_token' => $user->reset_token], true)
                    ])->setFrom(Yii::$app->params['mailFrom'])
                        ->setTo($user->email)
                        ->setSubject('Password reset request')
                        ->send();

                    if ($result) {
                        return true;
                    }
                    throw new ServerErrorHttpException('Something went wrong. Please contact support or try again later.');
                }
                throw new ModelValidationException($user);
            }
            $this->addError('email', 'Email not found');
        }
        return false;
    }
}
