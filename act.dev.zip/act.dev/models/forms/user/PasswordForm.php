<?php

namespace app\models\forms\user;

use app\components\web\ModelValidationException;
use app\models\User;
use Yii;
use yii\base\Model;

class PasswordForm extends Model
{
    public $reset_token;
    public $password;
    public $confirm_password;

    public function rules()
    {
        return [
            [['reset_token', 'password', 'confirm_password'], 'required'],
            [['confirm_password'], 'compare', 'compareAttribute' => 'password'],
        ];
    }

    public function save()
    {
        if ($this->validate()) {
            if ($user = User::findOne(['reset_token' => $this->reset_token, 'status' => User::STATUS_ACTIVE])) {
                $user->password = md5($this->password);
                if ($user->save()) {
                    return User::login($user->email, $user->password);
                }
                throw new ModelValidationException($user);
            }
            $this->addError('password', 'Reset token is outdated');
        }
        return false;
    }
}
