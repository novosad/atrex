<?php

namespace app\models\forms\account;

use app\models\User;
use yii\base\Model;
use Yii;

class DeleteForm extends Model
{
    public $ids;

    public function rules()
    {
        return [
            [['ids'], 'required'],
            ['ids', 'each', 'rule' => ['integer']],
        ];
    }

    public function delete()
    {
        if ($this->validate()) {
            $count = 0;
            foreach ($this->ids as $id) {
                if ($id == Yii::$app->user->identity->getId()) {
                    $this->addError('ids', 'You are try to delete your self');
                }
                if ($model = User::findOne(['id' => $id])) {
                    $id != Yii::$app->user->identity->getId() && $model->delete() && $count++;
                }
            }
            return $count;
        }
        return false;
    }
}