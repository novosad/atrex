<?php

namespace app\models\forms\account;

use app\models\User;
use yii\base\Model;
use yii\data\ActiveDataProvider;

class FilterForm extends Model
{
    public $filter;

    public function rules()
    {
        return [
            [['filter'], 'safe'],
        ];
    }

    public function search()
    {
        if ($this->validate()) {
            $query = User::find()->where(['in', 'status', [User::STATUS_ACTIVE, User::STATUS_BLOCKED]]);
            isset($this->filter) && $query->andFilterWhere(['or', ['like', 'first_name', $this->filter], ['like', 'last_name', $this->filter]]);

            $dataProvider = new ActiveDataProvider([
                'query' => $query,
                'sort'  => [
                    'attributes'   => [
                        'first_name',
                        'last_name',
                        'role',
                        'email'
                    ],
                    'defaultOrder' => [
                        'first_name' => SORT_ASC,
                    ]
                ]
            ]);
            return $dataProvider;
        }
        return false;
    }
}