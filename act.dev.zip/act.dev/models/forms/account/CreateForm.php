<?php

namespace app\models\forms\account;

use app\components\web\ModelValidationException;
use app\models\User;
use Yii;
use yii\base\Model;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use yii\web\ServerErrorHttpException;

class CreateForm extends Model
{
    public $first_name;
    public $last_name;
    public $email;
    public $role;

    //public $auto_pass = 1;
    //public $password;
    //public $confirm_password;

    public function rules()
    {
        return [
            [['first_name', 'last_name', 'email', 'role'], 'required'],
            [['email'], 'email'],
            [['email'], 'unique', 'targetClass' => User::className(), 'targetAttribute' => 'email'],
            [
                ['role'],
                'in',
                'range' => [
                    User::ROLE_ADMIN,
                    User::ROLE_MANAGER,
                ]
            ],
            //[['auto_pass'], 'boolean', 'strict' => true],
            /*
            [
                ['password', 'confirm_password'],
                'required',
                'when'       => function ($model) {
                    return $model->auto_pass == '0';
                },
                'whenClient' => "function (attribute, value) {return $('input[name*=\"auto_pass\"]:checked').val() == '0' ? true : false  ;}",
                'message'    => 'Required'
            ],
            [
                ['confirm_password'],
                'compare',
                'compareAttribute' => 'password',
                'when'             => function ($model) {
                    return $model->auto_pass == '0';
                },
                'whenClient'       => "function (attribute, value) {return $('input[name*=\"auto_pass\"]:checked').val() == '0' ? true : false  ;}"
            ],
            */
        ];
    }

    public function attributeLabels()
    {
        return [
            'first_name'       => 'First Name',
            'last_name'        => 'Last Name',
            'email'            => 'Email',
            'role'             => 'Role',
            //'auto_pass'        => 'Generate random password and send it via email',
            //'password'         => 'Password',
            //'confirm_password' => 'Confirm password',
        ];
    }

    public function save()
    {
        if ($this->validate()) {
            $auto_pass = Yii::$app->getSecurity()->generateRandomString(6);

            $user = new User();
            $user->setAttributes(ArrayHelper::merge(
                $this->attributes,
                [
                    //'password' => isset($this->auto_pass) && $this->auto_pass ? md5($auto_pass) : md5($this->password),
                    'password' => md5($auto_pass),
                    'status'   => User::STATUS_ACTIVE,
                    'email'    => strtolower($this->email)
                ]
            ));

            if ($user->save()) {
                //if (isset($this->auto_pass) && $this->auto_pass) {

                    $result = Yii::$app->mailer->compose('users/welcome', [
                        'first_name'  => $user->first_name,
                        'sign_in_url' => Url::to(['/'], true),
                        'password'    => $auto_pass
                    ])->setFrom(Yii::$app->params['mailFrom'])
                        ->setTo($user->email)
                        ->setSubject('Welcome to ACT')
                        ->send();

                    if (!$result) {
                        throw new ServerErrorHttpException('Something went wrong. Please contact support or try again later.');
                    }
                //}

                return true;
            }
            throw new ModelValidationException($user);
        }
        return false;
    }
}