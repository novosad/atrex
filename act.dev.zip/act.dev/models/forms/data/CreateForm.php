<?php

namespace app\models\forms\data;

use app\components\web\ModelValidationException;
use app\models\Data;
use app\models\forms\store\ProcessForm;
use Yii;
use yii\base\Model;

class CreateForm extends Model
{
    public $files;
    public $year;

    public function rules()
    {
        return [
            [['files', 'year'], 'required'],
            [['year'], 'match', 'pattern' => '/^\d{4}$/', 'message' => 'Invalid format'],

        ];
    }

    public function attributeLabels()
    {
        return [
            'files' => 'Files',
            'year'  => 'Year',
        ];
    }

    public function save()
    {
        if ($this->validate() && is_array($this->files) && !empty($this->files)) {
            $uploadPath = isset(Yii::$app->params['uploadsPath']) ? Yii::$app->params['uploadsPath'] : '@runtime/uploads';

            $model = new Data();
            $model->setAttributes([
                'name'      => 'not processed',
                'file_data' => json_encode($this->files),
                'year'      => $this->year,
                'user_id'   => Yii::$app->user->identity->getId(),
                'status'    => Data::STATUS_QUEUED
            ]);
            if ($model->save()) {

                $file_data = [];
                $_n = [];
                $_c = 0;

                foreach ($this->files as $file) {
                    $path = Yii::getAlias($uploadPath) . DIRECTORY_SEPARATOR . $file->id;
                    if (file_exists($path)) {
                        // PROCESSOR
                        $store = new ProcessForm([
                            'data_id'   => $model->id,
                            'file_name' => $file->file_name,
                            'path'      => $path
                        ]);
                        // if something goes wrong in parser we always can relaunch it without loosing files - so cron job needed if needed.
                        $processed = $store->parse();
                        $file_data[] = ['file_name' => $file->file_name, 'path' => $path, 'processed' => $processed];
                        if ($processed) {
                            $_n[] = $file->file_name;
                            $_c++;
                        }
                    }
                }

                if (!empty($file_data)) {
                    $model->setAttributes([
                        'name'      => empty($_n) ? 'not processed' : implode(', ', $_n),
                        'file_data' => json_encode($file_data),
                        'processed' => $_c,
                        'status'    => Data::STATUS_ACTIVE
                    ]);
                    if ($model->save()) {
                        return $file_data;
                    }
                }
            }
            throw new ModelValidationException($model);
        }
        return false;
    }
}