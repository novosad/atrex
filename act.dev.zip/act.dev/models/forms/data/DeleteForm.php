<?php

namespace app\models\forms\data;

use app\models\Data;
use Yii;
use yii\base\Model;

class DeleteForm extends Model
{
    public $ids;

    public function rules()
    {
        return [
            [['ids'], 'required'],
            ['ids', 'each', 'rule' => ['integer']],
        ];
    }

    public function delete()
    {
        if ($this->validate()) {
            $count = 0;
            foreach ($this->ids as $id) {
                if ($model = Data::findOne(['id' => $id])) {
                    $model->status = Data::STATUS_DELETED;
                    $model->save() && $count++;
                }
            }
            return $count;
        }
        return false;
    }
}