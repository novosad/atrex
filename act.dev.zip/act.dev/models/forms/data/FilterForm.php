<?php

namespace app\models\forms\data;

use app\models\Data;
use yii\base\Model;
use yii\data\ActiveDataProvider;

class FilterForm extends Model
{
    public $filter;

    public function rules()
    {
        return [
            [['filter'], 'safe'],
        ];
    }

    public function search()
    {
        if ($this->validate()) {
            $query = Data::find()->where(['in', 'status', [Data::STATUS_ACTIVE, Data::STATUS_QUEUED]]);
            isset($this->filter) && $query->andFilterWhere(['or', ['like', 'name', $this->filter], ['like', 'year', $this->filter]]);

            $dataProvider = new ActiveDataProvider([
                'query' => $query,
                'sort'  => [
                    'attributes'   => [
                        'name',
                        'year',
                        'created',
                    ],
                    'defaultOrder' => [
                        'created' => SORT_DESC
                    ]
                ]
            ]);
            return $dataProvider;
        }
        return false;
    }
}