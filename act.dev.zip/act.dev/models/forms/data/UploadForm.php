<?php

namespace app\models\forms\data;

use Yii;
use yii\base\Exception;
use yii\base\Model;

class UploadForm extends Model
{
    public $file;

    public function rules()
    {
        return [
            [['file'], 'file'],
        ];
    }

    public function save()
    {
        if ($this->validate()) {
            if ($this->validate()) {
                $uploadPath = isset(Yii::$app->params['uploadsPath']) ? Yii::$app->params['uploadsPath'] : '@runtime/uploads';

                $i = 100;
                $unique_id = uniqid();
                $path = Yii::getAlias($uploadPath) . DIRECTORY_SEPARATOR;
                while (--$i >= 0 && file_exists($path . $unique_id)) {
                    $unique_id = uniqid();
                }
                if (!$i) {
                    throw new Exception("Unable to generate unique safe filename");
                }

                $this->file->saveAs($path . $unique_id);

                return ['id' => $unique_id, 'file_name' => $this->file->baseName . '.' . $this->file->extension];
            }
        }
        return false;
    }
}