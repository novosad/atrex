<?php

namespace app\models\forms\store;

use Yii;
use yii\db\ActiveRecord;

// Recode: Family income ($36k or less)
class StoreFIN extends ActiveRecord
{
    public static function tableName()
    {
        return 'store_fin';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'data_id',
            'state',
            'district',
            'no',
            'yes',
            'undef',
        ];
    }

    public function rules()
    {
        return [
            [['data_id'], 'required'],
            [['state', 'district', 'no', 'yes', 'undef'], 'safe']
        ];
    }

    public static function import($data_id, $data)
    {
        $data = explode("\n", $data);
        $countInserts = 0;
        if (is_array($data) && !empty($data)) {
            $rows = [];
            foreach ($data as $line) {
                if (preg_match('/^.*,\d+,\d+,\d+/i', $line)) {
                    $_dt = explode(',', $line);
                    $code = trim($_dt[0]);
                    $state = '';
                    $district = '';
                    if (strlen($code) && strpos($code, '-') !== false) {
                        $parts = explode('-', $code);
                        if (count($parts) == 2) {
                            $state = $parts[0];
                            $district = $parts[1];
                        }
                    }
                    $rows[] = [$data_id, $state, $district, trim($_dt[1]), trim($_dt[2]), trim($_dt[3])];
                }
            }
            if (!empty($rows)) {
                $expected_rows = [
                    'data_id',
                    'state',
                    'district',
                    'no',
                    'yes',
                    'undef'
                ];

                $maxItemsPerInsert = 1000;
                $chunks = array_chunk($rows, $maxItemsPerInsert);
                foreach ($chunks as $chunk) {
                    $countInserts += Yii::$app->db->createCommand()->batchInsert(self::tableName(), $expected_rows, $chunk)->execute();
                }
            }
        }
        return $countInserts;
    }
}
