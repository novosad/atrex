<?php

namespace app\models\forms\store;

use Exception;
use Yii;
use yii\base\Model;

class ProcessForm extends Model
{

    public $data_id;
    public $file_name;
    public $path;

    private $csvOptions = ['length' => 0, 'delimiter' => ',', 'enclosure' => '"', 'escape' => "\\"];

    public function rules()
    {
        return [
            [['data_id', 'file_name', 'path'], 'required'],
        ];
    }

    public function parse()
    {
        if ($this->validate()) {
            $path_parts = pathinfo($this->file_name);
            $countInserts = 0;

            if (!(file_exists($this->path) && in_array($path_parts['extension'], ['txt', 'csv']))) {
                throw new Exception(__CLASS__ . ' could not find file or it os a file with unsupported extension');
            }

            if (strtolower($path_parts['extension']) == 'txt') {
                if ($data = file($this->path)) {
                    // list parser
                    /*
                     * This type of file has 3 sections :
                     * 1 Congressional district
                     * 2 State
                     * 3 National
                     * each of them has ~3 subsections [First choice, First enrolled, [First-generation and low-income students, First choice | First-generation+Low-income] ]
                     * First 2 main sections we have state division.
                     */

                    // split file on to 3 sections
                    $_store_key = false;
                    $markers = [
                        'Congressional district' => 'cd',
                        'State'                  => 'st',
                        'National'               => 'nl'
                    ];
                    $store = ['cd' => [], 'st' => [], 'nl' => []];
                    foreach ($data as $line) {
                        if (preg_match("/\*\*(.*)\*\*/", $line, $matches)) {
                            $section = trim($matches[1]);
                            isset($markers[$section]) && $_store_key = $markers[$section];
                        }
                        ($_store_key != false) && $store[$_store_key][] = $line;
                    }
                    $countInserts += isset($store['cd']) ? StoreCD::import($this->data_id, $store['cd']) : 0;
                    $countInserts += isset($store['st']) ? StoreST::import($this->data_id, $store['st']) : 0;
                    $countInserts += isset($store['nl']) ? StoreNL::import($this->data_id, $store['nl']) : 0;

                    return $countInserts;
                }
                throw new Exception(__CLASS__ . ' could not get file contents ' . $this->path);

            } else {
                // Numbers file data
                /*
                 *  This file contains several sections
                 */
                if (strpos(strtolower($this->file_name), '_n_')) {
                    if ($data = file_get_contents($this->path)) {
                        $markers = [
                            [
                                'search' => "/PSE: Student enrolled in college in Fall \d+,[^,\n]*,\s*\nStudent: Full Congressional district\,No\,Yes\,Total(.*?)Total,\d+/is",
                                'store'  => 'StorePSE',
                                'map'    => ['overall', 'first-generation', 'low-income']
                            ],
                            [
                                'search' => "/Recode: Race\/ethnicity,+[^,\n]*,\s*\nStudent: Full Congressional district,White,Black,Hispanic,Asian,Pacific Islander,Native American,Two or more,No response\/Missing,Total(.*?)Total,\d+/is",
                                'store'  => 'StoreRET',
                            ],
                            [
                                'search' => "/Recode: Potential first-gen college student,+[^,\n]*,\s*\nStudent: Full Congressional district,No,Yes,,Total(.*?)Total,\d+/is",
                                'store'  => 'StorePFG',
                            ],
                            [
                                'search' => "/Recode: Family income \(\\$36k or less\).*Student: Full Congressional district,No,Yes,,Total(.*?)Total,\d+/is",
                                'store'  => 'StoreFIN',
                            ],
                            [
                                'search' => "/Recode: ACT Composite score \[categorical\],+[^,\n]*,\s*\nStudent: Full Congressional district,Less than 19,19 to 23,24 or higher,Total(.*?)Total,\d+/is",
                                'store'  => 'StoreCSC',
                            ],
                            [
                                'search' => "/Recode: Met 3 or more benchmarks,[^,\n]*,\s*\nStudent: Full Congressional district,No,Yes,Total(.*?)Total,\d+/is",
                                'store'  => 'StoreMMB',
                                'map'    => ['overall', 'first-generation', 'low-income']
                            ],
                            [
                                'search' => "/Recode: Expressed interest in STEM major or occupation,[^,\n]*,\s*\nStudent: Home state of residence \[alpha\],No,Yes,Total(.*?)Total,\d+/is",
                                'store'  => 'StoreSMO',
                            ],
                            [
                                'search' => "/Recode: Measured STEM interest \[Science or Technical\],[^,\n]*,\s*\nStudent: Home state of residence \[alpha\],No,Yes,Total(.*?)Total,\d+/is",
                                'store'  => 'StoreIST',
                            ]
                        ];

                        foreach ($markers as $marker) {
                            if (preg_match_all($marker['search'], $data, $matches)) {
                                if (isset($matches[1])) {
                                    if (isset($marker['map']) && is_array($matches[1])) {
                                        foreach ($marker['map'] as $i => $section) {
                                            if (isset($matches[1][$i])) {
                                                $countInserts += call_user_func(["app\\models\\forms\\store\\" . $marker['store'], 'import'], $this->data_id, $matches[1][$i], $section);
                                            }
                                        }
                                    } else {
                                        // as all models located in this folder we can use them without call
                                        $countInserts += call_user_func(["app\\models\\forms\\store\\" . $marker['store'], 'import'], $this->data_id, $matches[1][0]);
                                    }
                                }
                            }
                        }
                        return $countInserts;
                    }
                    throw new Exception(__CLASS__ . ' could not get file contents ' . $this->path);
                }

                if (strpos(strtolower($this->file_name), 'act')) {
                    if (file_exists($this->path)) {
                        // bottle nec here if we have not enough memory
                        if (($fp = fopen($this->path, 'r')) !== false) {
                            $lines = [];
                            while (($line = fgetcsv($fp, $this->csvOptions['length'], $this->csvOptions['delimiter'], $this->csvOptions['enclosure'], $this->csvOptions['escape'])) !== false) {
                                $lines[] = $line;
                            }

                            if (!empty($lines)) {
                                $countInserts += StoreUD::import($this->data_id, $lines);
                            }
                            return $countInserts;
                        }
                    }
                    throw new Exception(__CLASS__ . ' could not get file contents ' . $this->path);
                }
            }
        }
        return false;
    }
}