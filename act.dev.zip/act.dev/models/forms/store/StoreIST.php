<?php

namespace app\models\forms\store;

use Yii;
use yii\db\ActiveRecord;

// Recode: Measured STEM interest [Science or Technical]
class StoreIST extends ActiveRecord
{
    public static function tableName()
    {
        return 'store_ist';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'data_id',
            'state',
            'no',
            'yes',
        ];
    }

    public function rules()
    {
        return [
            [['data_id'], 'required'],
            [['state', 'no', 'yes'], 'safe']
        ];
    }

    public static function import($data_id, $data)
    {
        $data = explode("\n", $data);
        $countInserts = 0;
        if (is_array($data) && !empty($data)) {
            $rows = [];
            foreach ($data as $line) {
                if (preg_match('/^.*,\d+,\d+/i', $line)) {
                    $_dt = explode(',', $line);
                    $state = trim($_dt[0]);
                    $rows[] = [$data_id, $state, trim($_dt[1]), trim($_dt[2])];
                }
            }
            if (!empty($rows)) {
                $expected_rows = [
                    'data_id',
                    'state',
                    'no',
                    'yes',
                ];

                $maxItemsPerInsert = 1000;
                $chunks = array_chunk($rows, $maxItemsPerInsert);
                foreach ($chunks as $chunk) {
                    $countInserts += Yii::$app->db->createCommand()->batchInsert(self::tableName(), $expected_rows, $chunk)->execute();
                }
            }
        }
        return $countInserts;
    }
}
