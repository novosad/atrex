<?php

namespace app\models\forms\store;

use Yii;
use yii\db\ActiveRecord;

// Recode: Met 3 or more benchmarks
class StoreMMB extends ActiveRecord
{
    public static function tableName()
    {
        return 'store_mmb';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'data_id',
            'section',
            'state',
            'district',
            'no',
            'yes',
        ];
    }

    public function rules()
    {
        return [
            [['data_id'], 'required'],
            [['section', 'state', 'district', 'no', 'yes'], 'safe']
        ];
    }

    public static function import($data_id, $data, $section)
    {
        $data = explode("\n", $data);
        $countInserts = 0;
        if (is_array($data) && !empty($data)) {
            $rows = [];
            foreach ($data as $line) {
                if (preg_match('/^.*,\d+,\d+/i', $line)) {
                    $_dt = explode(',', $line);
                    $code = trim($_dt[0]);
                    $state = '';
                    $district = '';
                    if (strlen($code) && strpos($code, '-') !== false) {
                        $parts = explode('-', $code);
                        if (count($parts) == 2) {
                            $state = $parts[0];
                            $district = $parts[1];
                        }
                    }
                    $rows[] = [$data_id, $section, $state, $district, trim($_dt[1]), trim($_dt[2])];
                }
            }
            if (!empty($rows)) {
                $expected_rows = [
                    'data_id',
                    'section',
                    'state',
                    'district',
                    'no',
                    'yes',
                ];

                $maxItemsPerInsert = 1000;
                $chunks = array_chunk($rows, $maxItemsPerInsert);
                foreach ($chunks as $chunk) {
                    $countInserts += Yii::$app->db->createCommand()->batchInsert(self::tableName(), $expected_rows, $chunk)->execute();
                }
            }
        }
        return $countInserts;
    }
}
