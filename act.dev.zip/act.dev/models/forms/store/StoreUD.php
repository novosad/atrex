<?php

namespace app\models\forms\store;

use app\models\State;
use Exception;
use Yii;
use yii\db\ActiveRecord;

class StoreUD extends ActiveRecord
{
    public static function tableName()
    {
        return 'store_ud';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'data_id',
            'state',
            'percent',
            'platinum',
            'gold',
            'silver',
            'bronze'
        ];
    }

    public function rules()
    {
        return [
            [['data_id'], 'required'],
            [['state', 'percent', 'platinum', 'gold', 'silver', 'bronze'], 'safe']
        ];
    }

    public static function import($data_id, $data = [])
    {
        $countInserts = 0;
        if (is_array($data) && !empty($data)) {
            $rows = [];
            foreach ($data as $line) {
                if (preg_match('/^.*,\d+,\d+,\d+,\d+,\d+/i', implode(',', $line))) {
                    // WARNING - seems in this report name of states is differs from all others reports - also we have some miss states
                    // and maybe warning needed if we can't warp state
                    $state = trim($line[0]);
                    $state = preg_replace('/\W/',' ', $state);
                    $state = State::state_wrap($state);
                    if ($state == '') {
                        Yii::error('Can not warp state in line: ' . $line);
                    }

                    $rows[] = [$data_id, $state, trim($line[1]), trim($line[2]), trim($line[3]), trim($line[4]), trim($line[5])];
                }
            }
            if (!empty($rows)) {
                $expected_rows = [
                    'data_id',
                    'state',
                    'percent',
                    'platinum',
                    'gold',
                    'silver',
                    'bronze'
                ];

                $maxItemsPerInsert = 1000;
                $chunks = array_chunk($rows, $maxItemsPerInsert);
                foreach ($chunks as $chunk) {
                    $countInserts += Yii::$app->db->createCommand()->batchInsert(self::tableName(), $expected_rows, $chunk)->execute();
                }
            }
        }
        return $countInserts;
    }
}
