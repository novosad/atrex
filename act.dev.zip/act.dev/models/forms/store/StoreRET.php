<?php

namespace app\models\forms\store;

use Yii;
use yii\db\ActiveRecord;

// Recode: Race/ethnicity
class StoreRET extends ActiveRecord
{
    public static function tableName()
    {
        return 'store_ret';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'data_id',
            'state',
            'district',
            'white',
            'black',
            'hispanic',
            'asian',
            'pacific_islander',
            'native_american',
            'two_or_more',
            'no_response_missing'
        ];
    }

    public function rules()
    {
        return [
            [['data_id'], 'required'],
            [['state', 'district', 'white', 'black', 'hispanic', 'asian', 'pacific_islander', 'native_american', 'two_or_more', 'no_response_missing'], 'safe']
        ];
    }

    public static function partitions()
    {
        return  ['white', 'black', 'hispanic', 'asian', 'pacific_islander', 'native_american', 'two_or_more', 'no_response_missing'];
    }

    public static function import($data_id, $data)
    {
        $data = explode("\n", $data);
        $countInserts = 0;
        if (is_array($data) && !empty($data)) {
            $rows = [];
            foreach ($data as $line) {
                if (preg_match('/^.*,\d+,\d+,\d+,\d+,\d+,\d+,\d+,\d+/i', $line)) {
                    $_dt = explode(',', $line);
                    $code = trim($_dt[0]);
                    $state = '';
                    $district = '';
                    if (strlen($code) && strpos($code, '-') !== false) {
                        $parts = explode('-', $code);
                        if (count($parts) == 2) {
                            $state = $parts[0];
                            $district = $parts[1];
                        }
                    }
                    $rows[] = [$data_id, $state, $district, trim($_dt[1]), trim($_dt[2]), trim($_dt[3]), trim($_dt[4]), trim($_dt[5]), trim($_dt[6]), trim($_dt[7]), trim($_dt[8])];
                }
            }
            if (!empty($rows)) {
                $expected_rows = [
                    'data_id',
                    'state',
                    'district',
                    'white',
                    'black',
                    'hispanic',
                    'asian',
                    'pacific_islander',
                    'native_american',
                    'two_or_more',
                    'no_response_missing'
                ];

                $maxItemsPerInsert = 1000;
                $chunks = array_chunk($rows, $maxItemsPerInsert);
                foreach ($chunks as $chunk) {
                    $countInserts += Yii::$app->db->createCommand()->batchInsert(self::tableName(), $expected_rows, $chunk)->execute();
                }
            }
        }
        return $countInserts;
    }
}
