<?php

namespace app\models\forms\store;

use Yii;
use yii\db\ActiveRecord;

// Congressional district
class StoreCD extends ActiveRecord
{
    public static function tableName()
    {
        return 'store_cd';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'data_id',
            'section',
            'state',
            'district',
            'inst',
            'freq',
        ];
    }

    public function rules()
    {
        return [
            [['data_id'], 'required'],
            [['section', 'state', 'district', 'inst', 'freq'], 'safe']
        ];
    }

    public static function import($data_id, $data)
    {
        $section = false;
        $countInserts = 0;
        $rows = [];
        $_start = false;
        $_end = false;
        $code = false;
        foreach ($data as $line) {

            if (preg_match("/^\.\s+\*(.*)$/", $line, $matches)) {
                $section = trim($matches[1]);
            }

            if (preg_match("/stu_congdist_full\s?=(.*)/", $line, $matches)) {
                $code = trim($matches[1]);
            }
            if (preg_match("/^\-{75,}$/", $line) || strpos($line, 'no observations') !== false) {
                $_start = false;
                $_end = false;
                $code = false;
            }
            if ($_start == true && preg_match("/\+-{5,}\+/", $line)) {
                $_end = true;
                $_start = false;
            }
            if ($_start && !$_end) {
                if (preg_match("/\|(.*)\s+(\d+).*\|/", $line, $matches)) {
                    if ($code !== false && isset($matches[1]) && isset($matches[2])) {
                        $inst = trim($matches[1]);
                        $freq = trim($matches[2]);
                        if ($inst && $freq) {
                            $state = '';
                            $district = '';
                            if (strlen($code) && strpos($code, '-') !== false) {
                                $parts = explode('-', $code);
                                if (count($parts) == 2) {
                                    $state = $parts[0];
                                    $district = $parts[1];
                                }
                            }
                            $rows[] = [$data_id, $section, $state, $district, $inst, $freq];
                        }
                    }
                }
            }
            if ($_start == false && preg_match("/\|-{5,}\|/", $line)) {
                $_start = true;
                $_end = false;
            }
        }

        if (!empty($rows)) {
            $expected_rows = [
                'data_id',
                'section',
                'state',
                'district',
                'inst',
                'freq'
            ];

            $maxItemsPerInsert = 1000;
            $chunks = array_chunk($rows, $maxItemsPerInsert);
            foreach ($chunks as $chunk) {
                $countInserts += Yii::$app->db->createCommand()->batchInsert(self::tableName(), $expected_rows, $chunk)->execute();
            }
        }
        return $countInserts;
    }
}
