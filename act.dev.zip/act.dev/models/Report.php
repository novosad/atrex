<?php

namespace app\models;

use Yii;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\db\Expression;

class Report extends ActiveRecord
{
    const STATUS_ACTIVE   = 'active';
    const STATUS_ARCHIVED = 'archived';
    const STATUS_DELETED  = 'deleted';
    const STATUS_DRAFT    = 'draft';

    public static function tableName()
    {
        return 'report';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'template_id',
            'data_id',
            'state',
            'state_name',
            'district',
            'region',
            'recipient',
            'students_count',
            'path',
            'status',
            'user_id',
            'created',
            'updated',
        ];
    }

    public function rules()
    {
        return [
            [['template_id', 'data_id'], 'required'],
            [['template_id', 'data_id', 'user_id'], 'integer'],
            [
                ['status'],
                'in',
                'range' => [
                    static::STATUS_ACTIVE,
                    static::STATUS_ARCHIVED,
                    static::STATUS_DELETED,
                    static::STATUS_DRAFT,
                ]
            ],
            [['recipient', 'students_count'], 'filter', 'filter' => 'trim'],
            [['recipient', 'students_count'], 'filter', 'filter' => '\yii\helpers\HtmlPurifier::process'],
            [[
                'state',
                'state_name',
                'district',
                'region',
                'recipient',
                'students_count',
                'path',
                'status',
                'user_id',
                'created',
                'updated'], 'safe']
        ];
    }

    public function attributeLabels()
    {
        return [
            'id'             => Yii::t('app', 'Report ID'),
            'template_id'    => Yii::t('app', 'Template'),
            'data_id'        => Yii::t('app', 'Data'),
            'state'          => Yii::t('app', 'State Alias'), // [AL, WA ...]
            'state_name'     => Yii::t('app', 'State'),       // [Alabama, Washington ...]
            'district'       => Yii::t('app', 'District'),
            'region'         => Yii::t('app', 'Region'),
            'recipient'      => Yii::t('app', 'Recipient'),
            'students_count' => Yii::t('app', 'Students Count'),
            'path'           => Yii::t('app', 'Path'),
            'status'         => Yii::t('app', 'Status'),
            'user_id'        => Yii::t('app', 'User ID'),
            'created'        => Yii::t('app', 'Created'),
            'updated'        => Yii::t('app', 'Updated'),
        ];
    }

    public function behaviors()
    {
        return [
            'timestamp' => [
                'class'      => TimestampBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created', 'updated'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated'],
                    'value'                           => new Expression('NOW()'),
                ]
            ]
        ];
    }

    public function getTemplate()
    {
        return $this->hasOne(Template::className(), ['id' => 'template_id']);
    }

    public function getData()
    {
        return $this->hasOne(Data::className(), ['id' => 'data_id']);
    }

    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

}
