<?php

namespace app\models;

use yii\base\Model;

class State extends Model
{
    public static function grid()
    {
        return [
            'AL' => ['Alabama', 'Southeast'],
            'AK' => ['Alaska', 'Northwest'],
            //'AS' => ['American Samoa', 'Islands'],
            'AZ' => ['Arizona', 'Southwest'],
            'AR' => ['Arkansas', 'Southwest'],
            'CA' => ['California', 'Southwest'],
            'CO' => ['Colorado', 'Northwest'],
            'CT' => ['Connecticut', 'Northeast'],
            'DE' => ['Delaware', 'Northeast'],
            'DC' => ['District of Columbia', 'Northeast'],
            //'FM' => ['Federated States of Micronesia', 'Islands'],
            'FL' => ['Florida', 'Southeast'],
            'GA' => ['Georgia', 'Southeast'],
            //'GU' => ['Guam', 'Islands'],
            'HI' => ['Hawaii', 'Southwest'],
            'ID' => ['Idaho', 'Northwest'],
            'IL' => ['Illinois', 'Midwest'],
            'IN' => ['Indiana', 'Midwest'],
            'IA' => ['Iowa', 'Midwest'],
            'KS' => ['Kansas', 'Northwest'],
            'KY' => ['Kentucky', 'Southeast'],
            'LA' => ['Louisiana', 'Southwest'],
            'ME' => ['Maine', 'Northeast'],
            //'MH' => ['Marshall Islands', 'Islands'],
            'MD' => ['Maryland', 'Northeast'],
            'MA' => ['Massachusetts', 'Northeast'],
            'MI' => ['Michigan', 'Midwest'],
            'MN' => ['Minnesota', 'Midwest'],
            'MS' => ['Mississippi', 'Southeast'],
            'MO' => ['Missouri', 'Midwest'],
            'MT' => ['Montana', 'Northwest'],
            'NE' => ['Nebraska', 'Midwest'],
            'NV' => ['Nevada', 'Northwest'],
            'NH' => ['New Hampshire', 'Northwest'],
            'NJ' => ['New Jersey', 'Northwest'],
            'NM' => ['New Mexico', 'Southwest'],
            'NY' => ['New York', 'Northeast'],
            'NC' => ['North Carolina', 'Southeast'],
            'ND' => ['North Dakota', 'Midwest'],
            //'MP' => ['Northern Mariana Islands', 'Islands'],
            'OH' => ['Ohio', 'Northeast'],
            'OK' => ['Oklahoma', 'Southwest'],
            'OR' => ['Oregon', 'Northwest'],
            //'PW' => ['Palau', 'Islands'],
            'PA' => ['Pennsylvania', 'Northeast'],
            //'PR' => ['Puerto Rico', 'Islands'],
            'RI' => ['Rhode Island', 'Northeast'],
            'SC' => ['South Carolina', 'Southeast'],
            'SD' => ['South Dakota', 'Midwest'],
            'TN' => ['Tennessee', 'Southeast'],
            'TX' => ['Texas', 'Southeast'],
            'UT' => ['Utah', 'Northwest'],
            'VT' => ['Vermont', 'Northeast'],
            //'VI' => ['Virgin Islands', 'Islands'],
            'VA' => ['Virginia', 'Southeast'],
            'WA' => ['Washington', 'Northwest'],
            'WV' => ['West Virginia', 'Northeast'],
            'WI' => ['Wisconsin', 'Midwest'],
            'WY' => ['Wyoming', 'Northwest'],
        ];
    }

    public static function state_map($state) // return full state name by short alias
    {
        $all = self::grid();
        return isset($all[$state]) ? $all[$state][0] : '';
    }

    public static function state_wrap($state_name) // return short state alias by full state name
    {
        $all = self::grid();
        foreach ($all as $state => $data) {
            if ($state_name == $data[0]) {
                return $state;
            }
        }
        return '';
    }

    public static function all($region = false) // return full state name by short alias
    {
        $all = self::grid();
        $result = [];
        if ($region && $region != 'false') {
            foreach ($all as $state => $data) {
                if ($region == $data[1]) {
                    $result[] = ['id' => $state, 'text' => $data[0]];
                }
            }
        } else {
            foreach ($all as $state => $data) {
                $result[] = ['id' => $state, 'text' => $data[0]];
            }
        }
        return $result;
    }

    public  static function regions()
    {
        $all = self::grid();
        $result = [];
        foreach ($all as $state => $data) {
            if (!isset($result[$data[1]])) {
                $result[$data[1]] = $data[1];
            }
        }
        return $result;
    }
}
