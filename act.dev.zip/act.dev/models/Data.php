<?php

namespace app\models;

use Yii;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\db\Expression;

class Data extends ActiveRecord
{
    const STATUS_ACTIVE = 'active';
    const STATUS_DELETED = 'deleted';
    const STATUS_QUEUED = 'queued';

    public static function tableName()
    {
        return 'data';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'name',
            'file_data',
            'year',
            'user_id',
            'status',
            'processed',
            'created',
            'updated'
        ];
    }

    public function rules()
    {
        return [
            [['year', 'user_id'], 'required'],
            [
                ['status'],
                'in',
                'range' => [
                    static::STATUS_ACTIVE,
                    static::STATUS_DELETED,
                    static::STATUS_QUEUED,
                ]
            ],
            [['name'], 'filter', 'filter' => 'trim'],
            [['name'], 'filter', 'filter' => '\yii\helpers\HtmlPurifier::process'],
            [['file_data', 'status', 'processed', 'created', 'updated'], 'safe']
        ];
    }

    public function attributeLabels()
    {
        return [
            'id'        => Yii::t('app', 'File ID'),
            'name'      => Yii::t('app', 'File Name'),
            'file_data' => Yii::t('app', 'File path'),
            'year'      => Yii::t('app', 'Year'),
            'user_id'   => Yii::t('app', 'User ID'),
            'status'    => Yii::t('app', 'Status'),
            'processed' => Yii::t('app', 'Processed'),
            'created'   => Yii::t('app', 'Created'),
            'updated'   => Yii::t('app', 'Updated'),
        ];
    }

    public function behaviors()
    {
        return [
            'timestamp' => [
                'class'      => TimestampBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created', 'updated'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated'],
                    'value'                           => new Expression('NOW()'),
                ]
            ]
        ];
    }

    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    public static function all()
    {
        $result = [];
        $data_set = Data::find()->where(['in', 'status', [Data::STATUS_ACTIVE]])->orderBy(['name' => SORT_ASC, 'created' => SORT_DESC])->all();
        if ($data_set) {
            foreach ($data_set as $data) {
                $result[$data->id] = $data->name;
            }
        }
        return $result;
    }
}
