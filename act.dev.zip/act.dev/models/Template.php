<?php

namespace app\models;

use Yii;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\db\Expression;

class Template extends ActiveRecord
{
    const STATUS_ACTIVE = 'active';
    const STATUS_DELETED = 'deleted';

    public static function tableName()
    {
        return 'template';
    }

    public static function primaryKey()
    {
        return ['id'];
    }

    public function attributes()
    {
        return [
            'id',
            'type',
            'path',
            'status',
            'created',
            'updated'
        ];
    }

    public function rules()
    {
        return [
            [['type'], 'required'],
            [
                ['status'],
                'in',
                'range' => [
                    static::STATUS_ACTIVE,
                    static::STATUS_DELETED,
                ]
            ],
            [['path', 'status', 'created', 'updated'], 'safe']
        ];
    }

    public function attributeLabels()
    {
        return [
            'id'      => Yii::t('app', 'Template ID'),
            'type'    => Yii::t('app', 'Template type'),
            'path'    => Yii::t('app', 'Template path'),
            'status'  => Yii::t('app', 'Status'),
            'created' => Yii::t('app', 'Created'),
            'updated' => Yii::t('app', 'Updated'),
        ];
    }

    public function behaviors()
    {
        return [
            'timestamp' => [
                'class'      => TimestampBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created', 'updated'],
                    ActiveRecord::EVENT_BEFORE_UPDATE => ['updated'],
                    'value'                           => new Expression('NOW()'),
                ]
            ]
        ];
    }

    public static function all() {
        $result = [];
        $data_set = Template::find()->where(['in', 'status', [Template::STATUS_ACTIVE]])->orderBy(['type' => SORT_ASC])->all();
        if ($data_set) {
            foreach ($data_set as $data) {
                $result[$data->id] = $data->type;
            }
        }
        return $result;
    }
}
