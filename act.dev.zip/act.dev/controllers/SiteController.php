<?php
namespace app\controllers;

use app\models\User;
use Yii;
use yii\filters\AccessControl;
use yii\helpers\Url;
use yii\web\Controller;
use yii\web\ServerErrorHttpException;

class SiteController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
        ];
    }

    public function actions()
    {
        return [
            'timezone' => [
                'class' => 'yii2mod\timezone\TimezoneAction',
            ],
        ];
    }

    public function actionIndex()
    {
        switch (Yii::$app->user->identity->role) {
            // TODO: for differed roles - differed pages. check design
            case User::ROLE_ADMIN:
                return $this->redirect(Url::to(['/report/index']));
                break;
            case User::ROLE_MANAGER:
                return $this->redirect(Url::to(['/report/index']));
                break;
            default:
                throw new ServerErrorHttpException("Unknown role or this user can't use this ui");
        }
    }

    public function  actionError()
    {
        $exception = Yii::$app->errorHandler->exception;
        if ($exception !== null) {
            return $this->render('error', ['exception' => $exception]);
        }
    }

}
