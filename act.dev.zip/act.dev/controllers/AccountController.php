<?php

namespace app\controllers;

use app\models\forms\account as forms;
use app\models\User;
use Yii;
use yii\filters\AccessControl;
use yii\helpers\Url;
use yii\web\Controller;
use yii\web\Response;

class AccountController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow'   => true,
                        'actions' => ['update', 'delete'],
                        'roles'   => [User::ROLE_ADMIN],
                    ],
                    [
                        'allow'   => true,
                        'actions' => ['index'],
                        'roles'   => ['@'],
                    ],
                ],
            ],
        ];
    }

    public function actionIndex()
    {
        $filter = Yii::$app->request->get('filter');
        $model = new forms\FilterForm([
            'filter' => $filter
        ]);
        $dataProvider = $model->search();

        if (Yii::$app->user->identity->role == User::ROLE_ADMIN) {
            $model = new forms\CreateForm();
            if ($model->load(Yii::$app->request->post()) && $model->save()) {
                Yii::$app->session->setFlash('success', 'User created successfully');
                $model = new forms\CreateForm();
            }
        } else {
            $model = false;
        }

        return $this->render('index', [
            'dataProvider' => $dataProvider,
            'filter'       => $filter,
            'model'        => $model,
        ]);
    }

    public function actionUpdate($id)
    {
        $model = new forms\UpdateForm(['id' => $id]);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', 'User updated successfully');
            return $this->redirect(Url::to(['account/index']));
        }
        return $this->redirect(Url::to(['account/index']));
    }

    public function actionDelete()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $model = new forms\DeleteForm();
        $model->load(Yii::$app->request->post(), '');
        $response = ($result = $model->delete()) ? ['success' => $result] : ['error' => ($error = $model->getFirstErrors()) ? json_encode(array_shift($error)) : 'Unknown error'];
        return $response;
    }
}
