<?php
namespace app\controllers;

use app\components\helpers\NumberToWords;
use app\models\Data;
use app\models\District;
use app\models\forms\report as forms;
use app\models\Report;
use app\models\State;
use app\models\Template;
use Yii;
use yii\filters\AccessControl;
use yii\helpers\Url;
use yii\web\Controller;
use yii\web\Response;
use yii\web\ServerErrorHttpException;

class ReportController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@']
                    ]
                ]
            ],
            [
                'class'   => 'yii\filters\ContentNegotiator',
                'only'    => ['update', 'email', 'available-districts', 'available-states'],
                'formats' => ['application/json' => Response::FORMAT_JSON]
            ]
        ];
    }

    public function actionIndex($status = Report::STATUS_ACTIVE)
    {
        $filter = Yii::$app->request->get('filter');

        $recent_data = false;
        if ($data = Data::find()->where(['status' => Data::STATUS_ACTIVE])->orderBy(['created' => SORT_DESC])->one()) {
            $recent_data = $data->created;
        }

        $model = new forms\FilterForm([
            'filter' => $filter,
            'status' => $status
        ]);
        $dataProvider = $model->search();

        return $this->render('index', [
            'dataProvider' => $dataProvider,
            'filter'       => $filter,
            'status'       => $status,
            'recent_data'  => $recent_data
        ]);
    }

    public function actionCreate()
    {
        $model = new forms\CreateForm();
        if ($model->load(Yii::$app->request->post()) && ($id = $model->save())) {
            return $this->redirect(Url::to(['report/preview', 'id' => $id]));
        }
        return $this->render('create', ['model' => $model, 'templates' => Template::all()]);
    }

    public function actionUpdate()
    {
        $model = new forms\UpdateForm();
        $model->load(Yii::$app->request->post(), '');
        $response = ($result = $model->save()) ? ['success' => $result] : ['error' => ($error = $model->getFirstErrors()) ? json_encode(array_shift($error)) : 'Unknown error'];
        return $response;
    }

    public function actionPreview($id, $html = false)
    {
        if ($report = Report::findOne($id)) {
            $template_id = $report->template_id;

            $_d = (int)$report->district;

            if ($_d > 0) {
                $n2w = new NumberToWords();
                $district = $n2w->getNumberOrdinal($_d);
            } else {
                $district = $report->district;
            }

            $data = new forms\DataForm([
                'data_id'  => $report->data_id,
                'state'    => $report->state, // [AL, WA ...]
                'district' => $report->district,
                'region'   => $report->region,
            ]);

            if ($_data_set = $data->process()) {
                $this->layout = 'report';
                $content = $this->render('templates/report_' . $template_id, [
                    'data'           => $_data_set,
                    'recipient'      => $report->recipient,
                    'state'          => $report->state,      // used in 1-3 templates for image map
                    'state_name'     => $report->state_name, // used in 1-3 templates for cover and back
                    'district'       => $district,           // used in 1-3 templates for cover
                    'students_count' => $report->students_count
                ]);

                if ($html) {
                    return $content;
                }

                // generate and save pdf from content
                $model = new forms\PreviewForm(['id' => $id, 'content' => $content, 'template_id' => $template_id]);
                if ($file = $model->process()) {


                    $this->layout = 'main';
                    return $this->render('preview', [
                        'id'            => $id,
                        'state_name'    => $report->state_name,
                        'file_name'     => $report->data->name,
                        'recipient'     => $report->recipient,
                        'area'          => $template_id == 4 ? '<strong>Region:</strong> ' . $report->region : '<strong>District:</strong> ' . $district,
                        'template_type' => $report->template['type']
                    ]);
                }
            }
        }
        throw new ServerErrorHttpException('Error while report generation - can not find report');
    }

    public function actionView($id)
    {
        if ($report = Report::findOne($id)) {
            if ($path = $report->path) {
                if (file_exists($path)) {
                    Yii::$app->response->format = Response::FORMAT_RAW;
                    $filename = 'preview.pdf';
                    header('Set-Cookie: fileDownload=true; path=/');
                    header('Content-Disposition: inline; filename="' . $filename . '"');
                    header('Content-Transfer-Encoding: binary');
                    header('Content-Type: application/pdf');

                    return file_get_contents($path);
                }
            }
        }
        throw new ServerErrorHttpException('can not find pdf file');
    }

    public function actionDownload($id)
    {
        if ($report = Report::findOne($id)) {
            if ($path = $report->path) {
                if (file_exists($path)) {
                    Yii::$app->response->format = Response::FORMAT_RAW;
                    $filename = $report->template['type'] . '-' . $report->data['year'] . '(' . date('m/d/Y gA:i') . ').pdf';
                    header('Set-Cookie: fileDownload=true; path=/');
                    header('Content-Disposition: attachment; filename="' . $filename . '"');
                    header('Content-Transfer-Encoding: binary');
                    header('Content-Type: application/pdf');

                    return file_get_contents($path);
                }
            }
        }
        throw new ServerErrorHttpException('can not find pdf file');
    }

    public function actionEmail($id)
    {
        $model = new forms\EmailForm(['id' => $id]);
        $model->load(Yii::$app->request->post());
        $response = ($result = $model->send()) ? ['success' => $result] : ['error' => ($error = $model->getFirstErrors()) ? json_encode(array_shift($error)) : 'Unknown error'];
        return $response;
    }

    public function actionAvailableDistricts($data_id, $state)
    {
        return ['results' => District::all($data_id, $state)];
    }

    public function actionAvailableStates($region)
    {
        return ['results' => State::all($region)];
    }
}
