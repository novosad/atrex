<?php

namespace app\controllers;

use app\models\forms\user as forms;
use Yii;
use yii\filters\AccessControl;
use yii\helpers\Url;
use yii\web\Controller;

class UserController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow'   => true,
                        'roles'   => ['@'],
                    ],
                    [
                        'actions' => ['login', 'reset', 'password'],
                        'allow'   => true,
                        'roles'   => ['?'],
                    ],
                ],
            ],
        ];
    }

    public function actionLogin()
    {
        $model = new forms\LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->redirect(Url::to(['site/index'])); // todo: redirect to remember url ?
        }
        return $this->render('login', ['model' => $model]);
    }

    public function actionLogout()
    {
        Yii::$app->user->identity->logout();
        return $this->goHome();
    }

    public function actionReset()
    {
        $model = new forms\ResetForm();
        if ($model->load(Yii::$app->request->post()) && $model->reset()) {
            Yii::$app->session->setFlash('info', 'We are sent instructions to your email');
            return $this->goHome();
        }
        return $this->render('reset', ['model' => $model]);
    }

    public function actionPassword($reset_token)
    {
        $model = new forms\PasswordForm([
            'reset_token' => $reset_token
        ]);
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('info', 'Your password was changed');
            return $this->goHome();
        }
        return $this->render('password', ['model' => $model]);
    }
}
