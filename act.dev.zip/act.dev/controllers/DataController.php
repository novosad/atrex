<?php

namespace app\controllers;

use app\models\Data;
use app\models\forms\data as forms;
use app\models\User;
use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\web\ServerErrorHttpException;
use yii\web\UploadedFile;

class DataController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow'   => true,
                        'actions' => ['upload', 'create', 'delete', 'download'],
                        'roles'   => [User::ROLE_ADMIN]
                    ],
                    [
                        'allow'   => true,
                        'actions' => ['index'],
                        'roles'   => [User::ROLE_ADMIN, User::ROLE_MANAGER]
                    ]
                ]
            ]
        ];
    }

    public function actionIndex()
    {
        $filter = Yii::$app->request->get('filter');
        $model = new forms\FilterForm([
            'filter' => $filter
        ]);
        $dataProvider = $model->search();
        return $this->render('index', [
            'dataProvider' => $dataProvider,
            'filter'       => $filter,
        ]);
    }

    // First we upload files to server [actionUpload] - and after create record in db with year and details information and process all files [actionCreate]
    public function actionUpload()
    {
        $model = new forms\UploadForm();
        if (Yii::$app->request->isPost) {
            $model->file = UploadedFile::getInstance($model, 'file');
            $response = ($result = $model->save()) ? ['success' => $result] : ['error' => ($error = $model->getFirstErrors()) ? json_encode(array_shift($error)) : 'Unknown error'];
            Yii::$app->response->format = Response::FORMAT_JSON;
            return $response;
        }
        return $this->render('upload', ['model' => $model]);
    }

    public function actionCreate($files)
    {
        $model = new forms\CreateForm([
            'files' => json_decode($files)
        ]);
        if ($model->load(Yii::$app->request->post())) {
            return $model->save() ? $this->render('complete') : $this->render('error');
        }
        return $this->render('create', ['model' => $model]);
    }

    public function actionDelete()
    {
        Yii::$app->response->format = Response::FORMAT_JSON;
        $model = new forms\DeleteForm();
        $model->load(Yii::$app->request->post(), '');
        $response = ($result = $model->delete()) ? ['success' => $result] : ['error' => ($error = $model->getFirstErrors()) ? json_encode(array_shift($error)) : 'Unknown error'];
        return $response;
    }

    public function actionDownload($ids)
    {
        $ids = json_decode($ids);
        if ($data = Data::findAll($ids)) {
            $dr = 'archive' . ' - ' . date('M j, Y H:i');
            $zip = new \ZipArchive();
            $filename = tempnam(Yii::getAlias('@runtime'), "_z");

            if ($zip->open($filename, \ZipArchive::CREATE) !== true) {
                throw new ServerErrorHttpException("cannot open <$filename>\n");
            }

            foreach ($data as $record) {

                if ($_rec = json_decode($record['file_data'])) {
                    foreach ($_rec as $file) {
                        $content = file_get_contents($file->path);
                        $zip->addFromString($dr . '/' . $file->file_name, $content);
                    }
                }
            }
            $zip->close();
            Yii::$app->response->format = Response::FORMAT_RAW;

            header('Content-Type: application/zip');
            header('Content-Length: ' . filesize($filename));
            header('Content-Disposition: attachment; filename="' . $dr . '.zip"');

            return readfile($filename);
        }
    }
}
