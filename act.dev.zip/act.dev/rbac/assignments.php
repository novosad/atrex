<?php
return [
    1 => [
        'administrator',
    ],
    3 => [
        'administrator',
    ],
];
