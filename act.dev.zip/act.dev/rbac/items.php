<?php

use app\models\User;
use yii\rbac\Item;

return [
    'guest'            => [
        'type'        => Item::TYPE_ROLE,
        'description' => 'Guest',
    ],
    User::ROLE_MANAGER => [
        'type'        => Item::TYPE_ROLE,
        'description' => 'Manager',
    ],
    User::ROLE_ADMIN   => [
        'type'        => Item::TYPE_ROLE,
        'description' => 'Administrator',
        'children'    => [
            'manager',
        ],
    ],
];
