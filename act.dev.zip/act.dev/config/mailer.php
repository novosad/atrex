<?php

/*
return [
    'useFileTransport' => true
];
*/

// Dev credentials

return [
    'apiKey' => 'key-90483682596352cda3c172bb2df16d61',
    'trackClicks' => false,
    'testMode' => false,
    'transport' => [
        'class' => 'Swift_SmtpTransport',
        'host' => 'smtp.mailgun.org',
        'username' => 'postmaster@act.darwinapps.com',
        'password' => 'd9fe865981d3cd0237d7336c5edadc30',
    ]
];
