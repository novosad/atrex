<?php

$params = require(__DIR__ . '/params.php');

$config = [
    'id' => 'act',
    'name' => 'ACT',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log', 'timezone'],
    'timeZone' => 'EST5EDT',
    'defaultRoute' => 'site/index',
    'components' => [
        'request' => [
            'enableCookieValidation' => true,
            'enableCsrfValidation' => false,
            'cookieValidationKey' => 'eXL232ZEmRA4fET',
        ],
        'cache' => ['class' => 'yii\caching\FileCache'],
        'user' => [
            'loginUrl' => ['/user/login'],
            'identityClass' => 'app\models\User',
            'authTimeout' => 86400, // 1 day
            'enableAutoLogin' => true,
            'identityCookie' => ['name' => 'uid', 'httpOnly' => true],
            'idParam' => 'uid',
        ],
        'session' => [
            'class' => 'yii\web\Session',
            'name' => 'sid',
            'useCookies' => true,
            'timeout' => 86400
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'mailer' => \yii\helpers\ArrayHelper::merge([
            'class' => 'app\components\swiftmailer\Mailer',
            'testMode' => YII_ENV == 'test' ? true : false,
        ], require(__DIR__ . '/mailer.php')),
        'authManager' => [
            'class' => 'yii\rbac\PhpManager'
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 1,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' =>  YII_DEBUG ? ['error', 'warning', 'info'] : ['error', 'warning'],
                    'logVars' => ['_POST', '_GET'],
                ],
            ],
        ],
        'db' => require(__DIR__ . '/db.php'),
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
            ],
        ],
        'assetManager' => [
            'linkAssets' => true // false //YII_ENV == 'dev' ? true : false,
        ],
        'timezone' => [
            'class' => 'yii2mod\timezone\Timezone',
            'actionRoute' => '/site/timezone'
        ],
    ],
    'params' => $params,
];

if (YII_DEBUG && YII_ENV == 'dev') {
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
    ];
}

return $config;
