<?php

return [
    'adminEmail' => 'admin@act.darwinapps.com',
    'sessionLifeTime' => 3600*24*30,
    'mailFrom' => 'info@act.darwinapps.com',
    'uploadsPath' => '@runtime/uploads',
    'reportsPath' => '@runtime/reports'
];
