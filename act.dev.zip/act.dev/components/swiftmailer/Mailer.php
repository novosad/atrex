<?php
namespace app\components\swiftmailer;

class Mailer extends \yii\swiftmailer\Mailer
{

    public $testMode = true;
    public $dkimEnabled = false;
    public $trackEnabled = true;
    public $trackOpens = true;
    public $trackClicks = true;
    public $apiKey = false;

    public $messageClass = '\app\components\swiftmailer\Message';

    private $_message;
    private $_params = [];

    public function composeFromString($view = null, array $params = [])
    {
        $message = $this->createMessage();
        $this->_params = $params;

        if ($view === null) {
            return $message;
        }

        if (isset($params['track_id'])) {
            $message->addTextHeader('X-Mailgun-Variables', '{"track_id": "' . $params['track_id'] . '"}');
        }

        if (!array_key_exists('message', $params)) {
            $params['message'] = $message;
        }

        $this->_message = $message;

        if (is_array($view)) {
            if (isset($view['html'])) {
                $html = $this->renderString($view['html'], $params, $this->htmlLayout);
            }
            if (isset($view['text'])) {
                $text = $this->renderString($view['text'], $params, $this->textLayout);
            }
        } else {
            $html = $this->renderString($view, $params, $this->htmlLayout);
        }

        $this->_message = null;

        if (isset($html)) {
            $message->setHtmlBody($html);
        }
        if (isset($text)) {
            $message->setTextBody($text);
        } elseif (isset($html)) {
            if (preg_match('|<body[^>]*>(.*?)</body>|is', $html, $match)) {
                $html = $match[1];
            }
            $html = preg_replace('|<style[^>]*>(.*?)</style>|is', '', $html);
            $message->setTextBody(strip_tags($html));
        }
        return $message;
    }

    public function compose($view = null, array $params = [])
    {
        $message = parent::compose($view, $params);
        if (isset($params['track_id'])) {
            $message->addTextHeader('X-Mailgun-Variables', '{"track_id": "' . $params['track_id'] . '"}');
        }
        return $message;
    }

    public function renderString($view, $params = [], $layout = false)
    {
        foreach ($params as $key => $value) {
            foreach ([$key, preg_replace('/[\-_]/', '', $key)] as $k) {
                $view = preg_replace('/%' . preg_quote($k) . '%/i', $value, $view);
                $view = preg_replace('/%25' . preg_quote($k) . '%25/i', $value, $view);
            }
        }

        if ($layout !== false) {
            return $this->getView()->render($layout, ['content' => $view, 'message' => $this->_message], $this);
        } else {
            return $view;
        }
    }

    public function createMessage()
    {
        $message = parent::createMessage();

        $message->addTextHeader('X-Mailgun-Dkim', $this->dkimEnabled ? 'yes' : 'no');
        $message->addTextHeader('X-Mailgun-Drop-Message', $this->testMode ? 'yes' : 'no');
        $message->addTextHeader('X-Mailgun-Track', $this->trackEnabled ? 'yes' : 'no');
        $message->addTextHeader('X-Mailgun-Track-Clicks', $this->trackEnabled && $this->trackClicks ? 'yes' : 'no');
        $message->addTextHeader('X-Mailgun-Track-Opens', $this->trackEnabled && $this->trackOpens ? 'yes' : 'no');

        return $message;
    }

    public function sendMessage($message)
    {
        if (!@$_GET['no_mail']) {
            $subject = $message->getSubject();
            foreach ($this->_params as $key => $value) {
                foreach ([$key, preg_replace('/[\-_]/', '', $key)] as $k)
                    $subject = preg_replace('/%' . preg_quote($k) . '%/i', $value, $subject);
            }
            $message->setSubject($subject);
            return parent::sendMessage($message);
        }
        return true;
    }

    public function saveMessage($message)
    {
        $subject = $message->getSubject();
        foreach ($this->_params as $key => $value) {
            $key = preg_replace('/[\-_]/', '', $key);
            $subject = preg_replace('/%' . preg_quote($key) . '%/i', $value, $subject);
        }
        $message->setSubject($subject);
        return parent::saveMessage($message);
    }
}
