<?php
namespace app\components\swiftmailer;

class Message extends \yii\swiftmailer\Message
{
    private $bodies = [];

    public function getTo()
    {
        return $this->getSwiftMessage()->getTo();
    }

    /**
     * @inheritdoc
     */
    public function setBody($body, $contentType)
    {
        $this->bodies[$contentType] = $body;
        parent::setBody($body, $contentType);
    }

    public function getBody($contentType)
    {
        return $this->bodies[$contentType];
    }

    public function addTextHeader($name, $value)
    {
        $this->getSwiftMessage()->getHeaders()->addTextHeader($name, $value);
    }
}