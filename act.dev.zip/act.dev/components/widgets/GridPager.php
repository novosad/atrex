<?php

namespace app\components\widgets;

use yii\widgets\LinkPager;
use yii\helpers\Html;

/**
 * Class GridPager
 *
 * @package app\components\widgets
 */
class GridPager extends LinkPager
{
    public function init()
    {
        $this->hideOnSinglePage = false;
        $this->firstPageLabel = true;
        $this->lastPageLabel = true;
        $this->options = ['class' => 'pagination'];

        parent::init();
    }

    public function run()
    {
        if ($this->registerLinkTags) {
            $this->registerLinkTags();
        }
        if ($this->pagination->pageCount > 1) {
            $buttons = str_replace("\n", "", $this->renderPageButtons());
        } else {
            $buttons = '';
        }
        $summary = $this->renderPagerSummary();
        echo '<div class="pagination-line"><div class="container-fluid"><div class="row"><div class="col-sm-4">' . $summary . '</div><div class="col-sm-8 text-right">' . $buttons . '</div></div></div></div>';
    }

    protected function renderPagerSummary()
    {
        $currentPage = $this->pagination->getPage();
        $pageSize = $this->pagination->getPageSize();
        $total = $this->pagination->totalCount;
        $start = $currentPage * $pageSize + 1;
        $end = ($currentPage + 1) * $pageSize;
        if ($end > $total) $end = $total;
        return "<div class='pages-count'>{$start}-{$end} of {$total}</div>";
    }

    protected function renderPageButton($label, $page, $class, $disabled, $active)
    {
        $options = ['class' => $class === '' ? null : $class];
        if ($active) {
            Html::addCssClass($options, $this->activePageCssClass);

            return Html::tag('li', Html::tag('span', $label), $options);
        }
        if ($disabled) {
            Html::addCssClass($options, $this->disabledPageCssClass);

            return Html::tag('li', Html::tag('span', $label), $options);
        }
        $linkOptions = $this->linkOptions;
        $linkOptions['data-page'] = $page;

        return Html::tag('li', Html::a($label, $this->pagination->createUrl($page), $linkOptions), $options);
    }


}