<?php

namespace app\components\web;

class ModelValidationException extends \yii\web\HttpException
{
    protected $model;

    /*
     * @param \yii\base\Model $model
     */
    public function __construct(\yii\base\Model $model, $code = 0, $previous = null)
    {
        $this->statusCode = $this->code = 422;
        $this->model = $model;
        parent::__construct($this->statusCode, "One or more inputs were not entered correctly", $code, $previous);
    }

    public function modelErrors()
    {
        return $this->model->getErrors();
    }
}