<?php

/* @var $this yii\web\View */
/* @var $exception Exception */

use yii\helpers\Html;
use yii\helpers\Url;

?>
<section class="page">
    <div class="container">

        <div class="row">
            <div class="col-xs-12">
                <h3 class="page__title">Error <?= isset($exception) && @$exception->getCode() ? $exception->getCode() : 404 ?></h3>
                <p><?= isset($exception) && @$exception->getMessage() ? nl2br(Html::encode($exception->getMessage())) : 'Page not found.' ?> </p>
                <p><a class="btn btn-primary" href="<?= Url::to(['/']) ?>">Go to home</a></p>
            </div>
        </div>
    </div>
</section>