<?php
use app\assets\AppAsset;
use yii\helpers\Html;
use yii\helpers\Url;

/**
 * @var \yii\web\View $this
 * @var string        $content
 */

AppAsset::register($this);

$this->beginPage();
?>
    <!DOCTYPE html>
    <html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" href="/favicon.ico" >

        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>

        <?php $this->head() ?>
    </head>
    <body class="<?= Yii::$app->user->isGuest ? 'not-logged-in' : '' ?>" >
    <!--[if lt IE 11]><div class="alert alert-warning text-center">Sorry, we don't support your old browser, friend.</div><![endif]-->
    <?php $this->beginBody() ?>

    <header class="header" role="banner">
        <div class="container clearfix">
            <div class="row">
                <div class="col-sm-5">
                    <h2 class="header__logo">
                        <a href="<?= Url::to(['/']) ?>">ACT</a>
                    </h2>

                    <?php if (!Yii::$app->user->isGuest) { ?>
                        <h2 class="header__site-name">Field Notes</h2>
                    <?php } ?>
                </div>
                <div class="col-sm-7">
                    <?=  Yii::$app->user->isGuest ? '' : $this->render('/layouts/main/_navigation', ['active_tab' => 'Report Dashboard']) ?>
                </div>
            </div>
        </div>
    </header>

    <!-- ALERTS -->
    <?php foreach (['error' => 'times-circle', 'warning' => 'exclamation-circle', 'success' => 'check-circle', 'info' => 'info-circle'] as $alert => $icon) : ?>
        <div class="_alert _alert-<?= $alert ?>" <?= null === Yii::$app->session->getFlash($alert) ? 'style="display:none"' : '' ?> >
            <div class="container">
                <button type="button" class="close" onclick="hideMessage()" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <i class="fa fa-<?= $icon ?>"></i> <strong class="uppercase"><?= $alert ?>: </strong> <span class="message"><?= Yii::$app->session->getFlash($alert) ?></span>
            </div>
        </div>
    <?php endforeach ?>

    <?= $content ?>

    <?php $this->endBody() ?>

    <?= $this->render('_loader') ?>
    </body>
    </html>
<?php $this->endPage() ?>