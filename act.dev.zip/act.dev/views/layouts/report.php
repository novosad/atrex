<?php
use app\assets\ReportAsset;

/**
 * @var \yii\web\View $this
 * @var string        $content
 */

ReportAsset::register($this);

$this->beginPage(); ?><html lang="<?= Yii::$app->language ?>"><head><meta charset="<?= Yii::$app->charset ?>"><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="viewport" content="width=device-width, initial-scale=1"><?php $this->head() ?><title>ACT</title></head><body><?php $this->beginBody() ?><?= $content ?><?php $this->endBody() ?></body></html><?php $this->endPage() ?>