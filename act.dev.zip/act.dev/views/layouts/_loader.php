<div id="loader" class="hidden">
    <div><i class="fa fa-spinner fa-pulse"></i> <span>Please wait...</span></div>
</div>
