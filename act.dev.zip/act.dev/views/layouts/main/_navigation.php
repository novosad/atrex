<?php
/**
 * @var yii\web\View $this
 * @var $active_tab
 */

use yii\helpers\Url;




$tabs = [
    [
        'name' => 'Report Dashboard',
        'href' => Url::to(['report/index']),
        'action' => 'report'
    ],
    [
        'name' => 'Manage Data',
        'href' => Url::to(['data/index']),
        'action' => 'data'
    ],
    [
        'name' => 'Manage Users',
        'href' => Url::to(['account/index']),
        'action' => 'account'
    ]
];


?>

<ul class="header__nav">
    <?php foreach ($tabs as $tab): ?>
        <li <?= Yii::$app->controller->id == $tab['action'] ? 'class="active"' : '' ?>>
            <a href="<?= $tab['href'] ?>" >
                <?= $tab['name'] ?>
            </a>
        </li>
    <?php endforeach ?>
        <li>
            <a href="/report/create" class="btn btn-danger">Create New Report</a>
        </li>
</ul>
