<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/**
 * @var yii\web\View                    $this
 * @var app\models\forms\user\ResetForm $model
 */

$this->title = Yii::$app->name;

?>

<section class="page page-reset">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="login-title">Field Notes</h1>
                <h4 class="reset-title">Reset Your Password</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                <div class="reset-form">
                    <?php
                    $form = ActiveForm::begin([
                        'validateOnBlur'   => false,
                        'validateOnSubmit' => false,
                        'validateOnType'   => true,
                    ]);
                    ?>
                    <?= $form->field($model, 'email')->input('email', ['placeholder' => 'Please enter your email', 'class' => 'form-control'])->label(false) ?>

                    <div class="reset-form__action">
                        <?= Html::submitButton('SEND', ['class' => 'btn btn-primary']) ?>
                    </div>
                    <?php
                    ActiveForm::end();
                    ?>
                </div>
                <div class="reset-form__forgot">
                    <a href="<?= Url::to(['/user/login']) ?>">Back to login page</a>
                </div>
            </div>
        </div>
    </div>
</section>