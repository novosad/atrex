<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/**
 * @var yii\web\View                    $this
 * @var app\models\forms\user\LoginForm $model
 */

$this->title = Yii::$app->name;

?>
<section class="page page-login">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="login-title">Field Notes</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                <div class="login-form">
                    <?php
                    $form = ActiveForm::begin([
                        'validateOnBlur'   => false,
                        'validateOnSubmit' => false,
                        'validateOnType'   => true,
                    ]);
                    ?>
                    <?= $form->field($model, 'email')->input('email', ['placeholder' => 'Email', 'class' => 'form-control'])->label(false) ?>
                    <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Password', 'class' => 'form-control'])->label(false) ?>

                    <div class="login-form__action">
                        <?= Html::submitButton('LOGIN', ['class' => 'btn btn-primary']) ?>
                    </div>
                    <?php
                    ActiveForm::end();
                    ?>
                </div>
                <div class="login-form__forgot">
                    <a href="<?= Url::to(['/user/reset']) ?>">Forgot password?</a>
                </div>
            </div>
        </div>
    </div>
</section>