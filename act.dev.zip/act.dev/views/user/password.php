<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\ActiveForm;

/**
 * @var yii\web\View                       $this
 * @var app\models\forms\user\PasswordForm $model
 */

$this->title = Yii::$app->name;

?>

<section class="page page-set-pass">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="login-title">Field Notes</h1>
                <h4 class="set-pass-title">Set New Password</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                <div class="set-pass-form">
                    <?php
                    $form = ActiveForm::begin([
                        'validateOnBlur'   => false,
                        'validateOnSubmit' => false,
                        'validateOnType'   => true,
                    ]);
                    ?>
                    <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Enter new password', 'class' => 'form-control'])->label(false) ?>
                    <?= $form->field($model, 'confirm_password')->passwordInput(['placeholder' => 'Confirm new password', 'class' => 'form-control'])->label(false) ?>

                    <div class="set-pass-form__action">
                        <?= Html::submitButton('SAVE', ['class' => 'btn btn-primary']) ?>
                    </div>
                    <?php
                    ActiveForm::end();
                    ?>
                </div>
                <div class="set-pass-form__forgot">
                    <a href="<?= Url::to(['/user/login']) ?>">Back to login page</a>
                </div>
            </div>
        </div>
    </div>
</section>