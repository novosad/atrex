<?php
/**
 * @var yii\web\View $this
 * @var              $id
 * @var              $template_type
 * @var              $file_name
 * @var              $recipient
 * @var              $state_name
 * @var              $area
 */

use yii\helpers\Url;
use yii\bootstrap\ActiveForm;
use app\models\Report;


$update_url   = Url::to(['report/update']);
$index_url    = Url::to(['report/index']);
$download_url = Url::to(['report/view', 'id' => $id]);
$email_url    = Url::to(['report/email', 'id' => $id]);
$save_status  = Report::STATUS_ACTIVE;


$js = <<<JS
$(document).on('click', '#save-and-close', function (e) {
    e.stopPropagation();
    $.post("{$update_url}", {'ids': ['{$id}'], 'status' : '{$save_status}' }, function(res) {
        if (res.success) {
            window.location.href = '{$index_url}';
        } else {
            showMessage('error', res.error);
        }
    }, 'json').fail(function () {
        showMessage('error', 'Unexpected error');
    });
});

$(document).on('click', '#send-email', function (e) {
    e.stopPropagation();
    var data = $('#sendEmailForm').serialize();
    $('#emailModal').modal('hide');
    $.post("{$email_url}", data, function(res) {
        if (res.success) {
            showMessage('info', 'Successfully send');
        } else {
            showMessage('error', res.error);
        }
    }, 'json').fail(function () {
        showMessage('error', 'Unexpected error');
    });
});

$(document).on('click', '#print', function (e) {
    e.stopPropagation();
    var PDF = document.getElementById('pdfDocument');
    PDF.focus();
    PDF.contentWindow.print();
});
JS;

$this->registerJs($js, \yii\web\View::POS_READY);


?>

<div class="modal fade" id="emailModal" tabindex="-1" role="dialog" aria-labelledby="emailModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="emailModalLabel">Send report by email</h4>
            </div>
            <?php
            $form = ActiveForm::begin([
                'id' => 'sendEmailForm',
                'options'                => [
                    'class'   => 'create-form clearfix',
                    'enctype' => 'multipart/form-data',
                ],
                'successCssClass'        => '',
                'enableClientValidation' => true,
                'validateOnSubmit'       => true,
                'validateOnBlur'         => true,
                'validateOnType'         => true,
            ]);

            $model = new app\models\forms\report\EmailForm();

            ?>
            <div class="modal-body">
                <?= $form->field($model, 'email')->textInput() ?>
                <?= $form->field($model, 'cc')->textInput() ?>
                <?= $form->field($model, 'subject')->textInput() ?>
                <?= $form->field($model, 'body')->textArea(['rows' => '6'])?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="send-email">Send message</button>
            </div>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>

<section class="page">
    <div class="container">
        <div class="page-info-wrapper">
            <div class="row">
                <div class="col-xs-12">
                    <h3 class="page__title no-desc">Report Created</h3>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="table-wrapper clearfix">
                <div class="table-wrapper__actions">
                    <div class="row">
                        <div class="col-sm-6">
                            <h4 class="table-wrapper__back"><a href="javascript:history.back()">&laquo; Back to Create New Report</a></h4>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group table-action-filter">
                                <div class="input-group-btn">
                                    <button id="print" class="btn btn-primary first-btn-group" type="button"><i class="fa fa-print"></i><span class="btn-label">Print</span></button>
                                    <a href="<?= Url::to(['report/download', 'id' => $id]) ?>" class="btn btn-primary" type="button"><i class="fa fa-download"></i><span class="btn-label">Download</span></a>
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#emailModal"><i class="fa fa-envelope"></i><span class="btn-label">Email</span></button>
                                    <button id="save-and-close" class="btn btn-info" type="button"><i class="fa fa-save"></i><span class="btn-label">Save & Close</span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-wrapper__data">

                    <div class="report-preview-info">
                        <div class="row">
                            <div class="col-sm-6">
                                <ul>
                                    <li><strong>Template:</strong>  <?= $template_type ?></li>
                                    <li><strong>Data:</strong>      <?= $file_name ?></li>
                                    <li><strong>Recipient:</strong> <?= $recipient ?></li>
                                </ul>
                            </div>
                            <div class="col-sm-6">
                                <ul>
                                    <li><strong>State:</strong> <?= $state_name ?></li>
                                    <li><?= $area ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="report-preview-wrapper">
                        <div class="pdf-document-wrapper">
                            <div class="iframe-preloader" id="iframe-preloader-<?= $id ?>"></div>
                            <iframe class="iframe-loader"
                                    width="100%"
                                    height="600px"
                                    id="pdfDocument"
                                    onload="javascript: var em = document.getElementById('iframe-preloader-<?= $id ?>'); if (typeof em != 'undefined') { em.parentNode.removeChild(em); }"
                                    src="<?= Url::to(['report/view', 'id' => $id]) ?>"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
