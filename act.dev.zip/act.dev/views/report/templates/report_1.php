<?php

use yii\helpers\Url;

/**
 * @var yii\web\View                $this
 * @var                             $data
 * @var                             $state
 * @var                             $state_name
 */
?>
<style scoped>
    html {
        font-family: sans-serif;
    }

    html, body {
        margin: 0;
        padding: 0;
        height: 100%;
    }

    article,
    aside,
    details,
    figcaption,
    figure,
    footer,
    header,
    main,
    menu,
    nav,
    section,
    summary {
        display: block;
    }

    audio,
    canvas,
    progress,
    video {
        display: inline-block;
        vertical-align: baseline;
    }

    audio:not([controls]) {
        display: none;
        height: 0;
    }

    [hidden],
    template {
        display: none;
    }

    a {
        background-color: transparent;
    }

    a:active,
    a:hover {
        outline: 0;
    }

    abbr[title] {
        border-bottom: 1px dotted;
    }

    b,
    strong {
        font-weight: bold;
    }

    dfn {
        font-style: italic;
    }

    h1 {
        font-size: 2em;
        margin: 0.67em 0;
    }

    mark {
        background: #ff0;
        color: #000;
    }

    small {
        font-size: 80%;
    }

    sub,
    sup {
        font-size: 75%;
        line-height: 0;
        position: relative;
        vertical-align: baseline;
    }

    sup {
        top: -0.5em;
    }

    sub {
        bottom: -0.25em;
    }

    img {
        border: 0;
    }

    svg:not(:root) {
        overflow: hidden;
    }

    figure {
        margin: 0 0 2.4rem;
        padding: 0;
    }

    hr {
        box-sizing: content-box;
        height: 0;
    }

    pre {
        overflow: auto;
    }

    code,
    kbd,
    pre,
    samp {
        font-family: monospace, monospace;
        font-size: 1em;
    }

    button,
    input,
    optgroup,
    select,
    textarea {
        color: inherit;
        font: inherit;
        margin: 0;
    }

    button {
        overflow: visible;
    }

    button,
    select {
        text-transform: none;
    }

    button,
    html input[type="button"],
    input[type="reset"],
    input[type="submit"] {
        cursor: pointer;
    }

    button[disabled],
    html input[disabled] {
        cursor: default;
    }

    input {
        line-height: normal;
    }

    input[type="checkbox"],
    input[type="radio"] {
        box-sizing: border-box;
        padding: 0;
    }

    input[type="search"] {
        box-sizing: content-box;
    }

    fieldset {
        border: 1px solid #c0c0c0;
        margin: 0 2px;
        padding: 0.35em 0.625em 0.75em;
    }

    legend {
        border: 0;
        padding: 0;
    }

    textarea {
        overflow: auto;
    }

    optgroup {
        font-weight: bold;
    }

    table {
        border-collapse: collapse;
        border-spacing: 0;
    }

    td,
    th {
        padding: 0;
    }

    @font-face {
        font-family: 'ForzaBook';
        font-style: normal;
        font-weight: normal; /*300**/
        src: local('ForzaBook'), local('forzabook'), url(<?= Url::base(true) ?>/report/fonts/ForzaBook.ttf) format('truetype');
    }

    @font-face {
        font-family: 'ForzaMedium';
        font-style: normal;
        font-weight: normal; /*400*/
        src: local('ForzaMedium'), local('forzamedium'), url(<?= Url::base(true) ?>/report/fonts/ForzaMedium.ttf) format('truetype');
    }

    @font-face {
        font-family: 'ForzaBold';
        font-style: normal;
        font-weight: normal; /*700*/
        src: local('ForzaBold'), local('forzabold'), url('<?= Url::base(true) ?>/report/fonts/ForzaBold.ttf') format('truetype');
    }

    @font-face {
        font-family: 'ForzaBlack';
        font-style: normal;
        font-weight: normal; /*800*/
        src: local('ForzaBlack'), local('forzablack'), url(<?= Url::base(true) ?>/report/fonts/ForzaBlack.ttf) format('truetype');
    }

    @font-face {
        font-family: 'IdealSansLight';
        font-style: normal;
        font-weight: normal; /*200*/
        src: local('IdealSansLight'), local('idealsanslight'), url(<?= Url::base(true) ?>/report/fonts/IdealSansLight.ttf) format('truetype');
    }

    @font-face {
        font-family: 'IdealSansLight';
        font-style: italic;
        font-weight: normal; /*200*/
        src: local('IdealSansLight'), local('idealsanslight'), url(<?= Url::base(true) ?>/report/fonts/IdealSansLightItalic.ttf) format('truetype');
    }

    @font-face {
        font-family: 'IdealSansBook';
        font-style: normal;
        font-weight: normal; /*300*/
        src: local('IdealSansBook'), local('idealsansbook'), url(<?= Url::base(true) ?>/report/fonts/IdealSansBook.ttf) format('truetype');

    }

    @font-face {
        font-family: 'IdealSansMedium';
        font-style: normal;
        font-weight: normal; /*400*/
        src: local('IdealSansMedium'), local('idealsansmedium'), url(<?= Url::base(true) ?>/report/fonts/IdealSansMedium.ttf) format('truetype');
    }

    @font-face {
        font-family: 'IdealSansMedium';
        font-style: italic;
        font-weight: normal; /*400*/
        src: local('IdealSansMedium'), local('idealsansmedium'), url(<?= Url::base(true) ?>/report/fonts/IdealSansMediumItalic.ttf) format('truetype');
    }

    @font-face {
        font-family: 'IdealSansBold';
        font-style: normal;
        font-weight: normal; /*600*/
        src: local('IdealSansBold'), local('idealsansbold'), url(<?= Url::base(true) ?>/report/fonts/IdealSansSemibold.ttf) format('truetype');
    }
    @font-face {
        font-family: 'AWConquerorInlineRegular';
        font-style: normal;
        font-weight: normal; /*400*/
        src: local('AWConquerorInlineRegular'), local('awconquerorinlineregular'), url(<?= Url::base(true) ?>/report/fonts/AWConquerorInlineRegular.ttf) format('truetype');
    }

    body {
        color: #364386;
        background: #e9f7fe;
    }

    /* REPORT1  */
    .site-wrapper {
        box-sizing: border-box;
        border: 15px solid #fff;
        position: absolute;
        padding: 0;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
    }

    .site-wrapper-inner {
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        z-index: 1;
        background: #e9f7fe;
    }

    .site-wrapper-page-content {
        padding: 40px 20px;
    }

    .site-wrapper-inner .left-border {
        width: 15px;
        position: absolute;
        left: -15px;
        top: 0;
        bottom: -15px;
        background: #fff;
    }

    .site-wrapper-inner .right-border {
        width: 15px;
        position: absolute;
        right: -15px;
        top: 0;
        bottom: -15px;
        background: #fff;
    }

    .site-wrapper-inner .bottom-border {
        height: 15px;
        position: absolute;
        left: -15px;
        right: -15px;
        bottom: -15px;
        background: #fff;
    }

    /* header */
    .page-header__first-line h3 {
        font-family: 'ForzaBold';
        font-weight: normal;
        font-size: 15px;
        line-height: 18px;
        margin: 0;
        color: #6e77a8;
    }

    .page-header__second-line {
        border-bottom: 4px solid #113184;
    }

    .page-header__second-line table {
        width: 100%;
    }

    .page-header__second-line--left h1 {
        margin: 0;
        padding: 0;
        font-family: 'IdealSansBold', arial, sans-serif;
        font-weight: normal;
        color: #e9495c;
        font-size: 40px;
        line-height: 36px;
        width: 630px;
        word-break: break-all;
        overflow: hidden;
    }
    .page-header__second-line--left h1.s1 {
        font-size: 40px; /* 1-16 */
        line-height: 36px;
    }
    .page-header__second-line--left h1.s2 {
        font-size: 30px; /* 17-20 */
        line-height: 36px;
    }
    .page-header__second-line--left h1.s3 {
        font-size: 20px; /* 21-33 */
        line-height: 36px;
    }
    .page-header__second-line--left h1.s4 {
        font-size: 16px; /* 34-40 */
        line-height: 36px;
    }
    .page-header__second-line--left h1.s5 {
        font-size: 12px; /* 40-55 */
        line-height: 36px;
    }
    .page-header__second-line--left h1.s6 {
        font-size: 12px; /* 40-55 two lines */
        line-height: 14px;
    }

    .page-header__second-line--right {
        width: 100px;
        text-align: center;
        letter-spacing: .15em;
        color: #e9495c;
        padding-left: 8px;
        position: relative;
        overflow: hidden;
        text-transform: uppercase;
    }

    .page-header__second-line--right .border {
        position: absolute;
        left: 0;
        top: 6px;
        height: 34px;
        border-left: 1px dotted #113084;
    }

    .page-header__second-line--right p {
        margin: 0;
        font-family: 'ForzaMedium', arial, sans-serif;
        font-size: 11px;
        line-height: 8px;
        text-align: center;
    }

    .page-header__second-line--right .year {
        display: block;
        font-family: 'AWConquerorInlineRegular','ForzaMedium', arial, sans-serif;
        font-size: 32px;
        line-height: 24px;
        color: #6e77a8;
        letter-spacing: normal;
        margin-left: -4px;
    }

    /* arrow line */

    .arrow-line {
        margin-top: 20px;
        margin-bottom: 20px;
    }

    .arrow-line__table {
        width: 100%;
        height: 150px;
        background: url('/report/img/bg-arrow-table-left.jpg') 0 0 no-repeat;
    }

    .arrow-line__table td {
        padding: 10px;
    }

    .arrow-line__table td.first-td {
        vertical-align: top;
        padding-left: 20px;
        font-family: 'IdealSansLight', arial, sans-serif;
        font-size: 13px;
        font-weight: normal;
        line-height: 13px;
        width: 260px;
        background: url('/report/img/bg-dotted-separator.png') 100% 50% no-repeat;
    }

    .arrow-line__table td.first-td .td-box {
        margin-top: 30px;
    }

    .arrow-line__table td.first-td strong {
        font-family: 'IdealSansMedium', arial, sans-serif;
        font-weight: normal;
    }

    .arrow-line__table td.first-td span {
        color: #e84356;
        font-family: 'ForzaBook', arial, sans-serif;
        font-size: 36px;
        font-weight: normal;
        line-height: 30px;
        white-space: nowrap;
        display: block;
    }

    .arrow-line__table td.second-td {
        font-family: 'IdealSansLight', arial, sans-serif;
        font-weight: normal;
        font-size: 12px;
        line-height: 12px;
        text-transform: uppercase;
        padding-left: 30px;
        padding-right: 28px;
        width: 200px;
    }

    .arrow-line__table td.second-td span.top-text {
        font-size: 14px;
        line-height: 14px;
        display: block;
        white-space: nowrap;
        text-transform: uppercase;
        margin-top: 3px;
    }

    .arrow-line__table td.second-td span.number {
        font-family: 'AWConquerorInlineRegular','ForzaMedium', arial, sans-serif;
        display: block;
        font-size: 68px;
        line-height: 50px;
        color: #e84356;
        margin-bottom: -6px;
    }

    .arrow-line__table td.arrows-center {
        padding: 0;
        width: 52px;
        background: url('/report/img/bg-arrow-table-center.jpg') 50% 0 no-repeat;
    }

    .arrow-line__table td.arrow-right {
        width: 145px;
        background: url('/report/img/bg-arrow-table-right.jpg') 100% 0 no-repeat;
        text-align: center;
        font-family: 'ForzaBook', arial, sans-serif;
        font-weight: normal;
        font-size: 10px;
        vertical-align: top;
    }

    .arrow-line__table td.arrow-right .td-box {
        margin-top: 23px;
        padding-left: 5px;
    }

    .arrow-line__table td.arrow-right span {
        display: block;
        max-width: 80px;
        margin: 0 auto;
    }

    .arrow-line__table td.arrow-right span.top {
        border-bottom: 1px dotted #364386;
        line-height: 18px;
    }

    .arrow-line__table td.arrow-right span.middle {
        font-size: 13px;
        line-height: 10px;
        font-family: 'ForzaMedium', arial, sans-serif;
        font-weight: normal;
    }

    .arrow-line__table td.arrow-right span.middle-number {
        font-size: 22px;
        line-height: 18px;
        font-family: 'ForzaBold', arial, sans-serif;
        font-weight: normal;
        color: #e84356;
    }

    .arrow-line__table td.arrow-right span.bottom {
        border-top: 1px dotted #364386;
        line-height: 14px;
    }

    /* page content */
    .page-content {
        position: relative;
    }

    .page-content table {
        width: 100%;
    }

    .page-content--bottom-line {
        border-top: none;
        border-bottom: 4px solid #868eb6;
    }

    .page-content--top-line {
        border-top: 4px solid #868eb6;
    }

    .page-content h3 {
        font-family: 'IdealSansBold', arial, sans-serif;
        font-size: 16px;
        font-weight: normal;
        line-height: 12px;
        margin-bottom: 10px;
    }

    .page-content h3.top-m {
        margin-top: 20px;
    }

    .page-content p {
        margin: 0;
        padding: 0;
        font-family: 'IdealSansLight', arial, sans-serif;
        font-size: 14px;
        font-weight: normal;
        font-style: italic;
        line-height: 12px;
    }

    /* left col */
    .page-content__left-col {
        width: 345px;
        height: 356px;
        vertical-align: top;

    }

    .page-content__left-col-inner {
        padding: 15px 10px 0 0;
    }

    .graph-ethnic {
        padding-bottom: 20px;
    }

    .graph-ethnic__box {
        background: #e8e5ed;
        position: relative;
        height: 250px;

    }

    .graph-ethnic__box .corner {
        width: 20px;
        height: 20px;
        position: absolute;
    }

    .graph-ethnic__box .corner-l-t {
        left: 0;
        top: 0;
        background: url(/report/img/graph-ethnic-corner-l-t.jpg) 50% 50% no-repeat;
    }

    .graph-ethnic__box .corner-r-t {
        right: 0;
        top: 0;
        background: url(/report/img/graph-ethnic-corner-r-t.jpg) 50% 50% no-repeat;
    }

    .graph-ethnic__box .corner-r-b {
        right: 0;
        top: 230px;
        background: url(/report/img/graph-ethnic-corner-r-b.jpg) 50% 50% no-repeat;
    }

    .graph-ethnic__box .corner-l-b {
        left: 0;
        top: 230px;
        background: url(/report/img/graph-ethnic-corner-l-b.jpg) 50% 50% no-repeat;
    }

    .graph-ethnic .n-dot {
        position: absolute;
        color: #fff;
        text-align: center;
        font-family: 'ForzaMedium', arial, sans-serif;
        font-size: 11px;
        z-index: 1;
        transform: translate(-50%, -50%);
    }

    .graph-ethnic .n-dot img {
        position: absolute;
        width: 100%;
        z-index: 1;
    }
    .graph-ethnic .n-dot div {
        text-align: center;
        position: relative;
        z-index: 2;
    }

    .n-dot--red {
        width: 20px; /* adjust this in script */
        height: 20px; /* adjust this in script */
        left: 135px;
        top: 135px;
    }

    .n-dot--red div {
        /* text size and alignment */
        font-size: 11px; /* adjust this in script */
        line-height: 15px; /* adjust this in script */
    }

    .n-dot--red.offset-text div {
        /*margin: -22px 0 0 0;*/ /* adjust this in script */
        color: #E41D34;
    }

    .n-dot--blue {
        width: 50px;
        height: 50px;
        left: 85px;
        top: 95px;
    }

    .n-dot--blue div {
        font-size: 16px;
        line-height: 30px;
    }

    .n-dot--blue.offset-text div {
        color: #244091;
    }

    .n-dot--gray {
        width: 50px;
        height: 50px;
        left: 145px;
        top: 70px;
    }

    .n-dot--gray div {
        font-size: 16px;
        line-height: 30px;
    }

    .n-dot--gray.offset-text div {
        color: #9AA7A9;
    }

    .n-dot--blue-light {
        width: 50px;
        height: 50px;
        left: 195px;
        top: 120px;
    }

    .n-dot--blue-light div {
        font-size: 16px;
        line-height: 30px;
    }

    .n-dot--blue-light.offset-text div {
        color: #727AAC;
    }

    .n-dot--rose {
        width: 50px;
        height: 50px;
        left: 255px;
        top: 115px;
    }

    .n-dot--rose div {
        font-size: 16px;
        line-height: 30px;
    }

    .n-dot--rose.offset-text div {
        color: #FD8698;
    }

    .n-dot--blue-lighten {
        width: 50px;
        height: 50px;
        left: 215px;
        top: 55px;
    }

    .n-dot--blue-lighten div {
        font-size: 16px;
        line-height: 30px;
    }

    .n-dot--blue-lighten.offset-text div {
        color: #ABB1CD;
    }

    .graph-ethnic .labels-line {
        position: absolute;
        left: 10px;
        right: 10px;
        top: 200px;
        font-family: 'IdealSansBook', arial, sans-serif;
        font-size: 11px;
        line-height: 14px;
        font-weight: normal;
    }

    .graph-ethnic .label {
        color: #fff;
        padding: 2px 3px;
        display: inline;
        white-space: nowrap;
    }

    .graph-ethnic .label--blue {
        background: #233F90;
    }

    .graph-ethnic .label--rose {
        background: #FC8597;
    }

    .graph-ethnic .label--gray {
        background: #99A6A8;
    }

    .graph-ethnic .label--blue-light {
        background: #5F7BB2;
    }

    .graph-ethnic .label--red {
        background: #F92D28;
    }

    .graph-ethnic .label--blue-lighten {
        background: #B2C1D8;
    }

    .graph-underrepresented h3 {
        font-size: 14px;
    }

    .graph-underrepresented__box {
        background: #c7ecff url('/report/img/bg-graph-head.png') 50% 50% no-repeat;
        position: relative;
        height: 210px;
    }

    .graph-underrepresented__box .corner {
        width: 20px;
        height: 20px;
        position: absolute;
        z-index: 1;
    }

    .graph-underrepresented__box .corner-l-t {
        left: 0;
        top: 0;
        background: url(/report/img/graph-underrepresented-corner-l-t.png) 50% 50% no-repeat;
    }

    .graph-underrepresented__box .corner-r-t {
        right: 0;
        top: 0;
        background: url(/report/img/graph-underrepresented-corner-r-t.png) 50% 50% no-repeat;
    }

    .graph-underrepresented__box .corner-r-b {
        right: 0;
        top: 190px;
        background: url(/report/img/graph-underrepresented-corner-r-b.png) 50% 50% no-repeat;
    }

    .graph-underrepresented__box .corner-l-b {
        left: 0;
        top: 190px;
        background: url(/report/img/graph-underrepresented-corner-l-b.png) 50% 50% no-repeat;
    }

    .graph-underrepresented__box .left-side {
        float: left;
        width: 50%;
        z-index: 2;
        position: relative;
    }

    .graph-underrepresented__box .right-side {
        float: right;
        width: 50%;
        z-index: 2;
        position: relative;
    }

    .graph-underrepresented__box h4 {
        font-size: 10px;
        font-family: 'ForzaMedium', arial, sans-serif;
        font-weight: normal;
        padding: 0 10px;
    }

    .graph-underrepresented__box h4 strong {
        font-family: 'ForzaBlack';
        font-weight: normal;
        white-space: nowrap;
    }

    .graph-underrepresented__box .graph-cols {
        margin: 0;
        padding: 0;
        list-style: none;
        border-bottom: 1px solid #0d1c6e;
        position: relative;
        text-align: center;
        font-size: 0;
    }

    .graph-underrepresented__box .left-side .graph-cols {
        margin: 10px 0 0 10px;
        height: 120px;
    }

    .graph-underrepresented__box .right-side .graph-cols {
        margin: 10px 10px 0 0;
        height: 120px;
    }

    .graph-underrepresented__box .graph-cols .graph-col--left {
        width: 25%;
        margin-left: 25%;
        margin-right: 3%;
        display: inline-block;
        height: 120px;
        position: absolute;
        top: 0px;
        left: 30px;
    }

    .graph-underrepresented__box .graph-cols .graph-col--right {
        width: 25%;
        margin-left: 3%;
        margin-right: 3%;
        display: inline-block;
        position: absolute;
        top: 0px;
        left: 30px
    }

    .graph-underrepresented__box .graph-cols .col-number {
        display: block;
        font-size: 11px;
        font-family: 'ForzaMedium', arial, sans-serif;
        font-weight: normal;
        position: absolute;
        top: 0px;
        left: 10px
    }

    .graph-underrepresented__box .graph-cols .col {
        display: block;
        width: 12px;
        height: 100px;
        margin: 0 auto;
        position: absolute;
        top: 20px;
        left: 15px;
    }

    .graph-underrepresented__box .graph-cols .col--red {
        background: #f08793;
    }

    .graph-underrepresented__box .graph-cols .col--blue {
        background: #777eaf;
    }

    .graph-underrepresented__box .graph-cols .col-name {
        display: block;
        font-size: 10px;
        font-family: 'IdealSansLight', arial, sans-serif;
        font-weight: normal;
        line-height: 14px;
        position: absolute;
        left: 7px;
        top: 120px;
        text-align: center;
    }

    .graph-underrepresented__box .graph-cols .graph-median {
        position: absolute;
        left: 5px;
        right: 5px;
        top: 20%;
        border-bottom: 1px dotted #32458B;
        text-align: left;
    }

    .graph-underrepresented__box .graph-cols .graph-line-name {
        font-size: 9px;
        line-height: 9px;
        font-family: 'ForzaBook', arial, sans-serif;
        font-weight: normal;
        top: -12px;
        position: absolute;
    }

    .graph-underrepresented__box .graph-cols .graph-line-number {
        font-size: 11px;
        line-height: 9px;
        font-family: 'ForzaBook', arial, sans-serif;
        font-weight: normal;
        position: absolute;
        right: 25px;
        top: -12px;
    }

    /* right col */

    .page-content__right-col {
        vertical-align: top;
        border-left: 1px dotted #868eb6;

    }

    .page-content__right-col-inner {
        padding: 15px 10px 0 15px;
    }

    .table-act {
        margin-top: 20px;
        width: 100%;
        font-family: 'ForzaBold', arial, sans-serif;
        font-size: 11px;
        line-height: 12px;
        font-weight: normal;
        margin-bottom: 20px;
    }

    .table-act th {
        font-family: 'ForzaBook', arial, sans-serif;
        font-size: 10px;
        padding: 5px;
        text-align: center;
        background: #cfd2e2;
        vertical-align: middle;
    }

    .table-act td {
        padding: 5px;
        text-align: center;
    }

    .table-act .first-col {
        border-right: 1px dotted #364386;
    }

    .table-act td.first-col {
        font-family: 'ForzaMedium', arial, sans-serif;
        font-weight: normal;
    }

    .table-act .second-line td {
        background: #EAD8E2;
    }

    .table-scores {
        width: 100%;
        margin-bottom: 6px;
    }

    .table-scores td {
        padding: 0 6px;
        vertical-align: middle;
    }

    .table-scores__title {
        width: 30%;
        font-family: 'ForzaBook', arial, sans-serif;
        font-size: 12px;
        font-weight: normal;
        line-height: 10px;
    }

    .table-scores__percents {
        font-family: 'ForzaMedium', arial, sans-serif;
        font-size: 26px;
        font-weight: normal;
        text-align: center;
    }

    .first-line .table-scores__percents {
        color: #556099;
    }

    .second-line .table-scores__percents {
        color: #ed6b7a;
    }

    .third-line .table-scores__percents {
        color: #6e77a8;
    }

    .table-scores__details table {
        width: 100%;
        font-size: 11px;
    }

    .table-scores__details table td {
        padding: 0 3px;
        font-family: 'ForzaMedium', arial, sans-serif;
        font-weight: normal;
        line-height: 9px;
        height: 14px;
    }

    .table-scores__details table td.align-right {
        text-align: right;
        font-family: 'ForzaBook', arial, sans-serif;
        font-weight: normal;
    }

    .table-scores tr.first-line td {
        background: #E7ECEC;
    }

    .table-scores tr.second-line td {
        background: #FEE2E6;
    }

    .table-scores tr.third-line td {
        background: #D3F3FC;
    }

    .table-scores tr.first-line td.table-scores__end-line {
        background: transparent url('/report/img/bg-ribbon-gray.png') 0 50% no-repeat;
    }

    .table-scores tr.second-line td.table-scores__end-line {
        background: transparent url('/report/img/bg-ribbon-rose.png') 0 50% no-repeat;
    }

    .table-scores tr.third-line td.table-scores__end-line {
        background: transparent url('/report/img/bg-ribbon-blue.png') 0 50% no-repeat;
    }

    /* page 3 */
    .page-content__left-col-inner.no-top,
    .page-content__right-col-inner.no-top {
        padding-top: 0;
    }

    .page-content__right-col-inner.no-top h3:first-child,
    .page-content__left-col-inner.no-top h3:first-child {
        margin-top: 0;
    }

    .stat-bars {
        margin-top: 10px;
        margin-bottom: 20px;
        background: url('/report/img/bg-map.png') 50% no-repeat;
    }

    .box-title {
        font-family: 'ForzaBold';
        font-weight: normal;
        font-size: 18px;
        color: #adb2ce;
        margin-top: 15px;
        margin-bottom: 10px;
    }

    .stat-bars-list {
        margin: 0;
        padding: 0;
        list-style: none;
    }

    .stat-bars-list li {
        position: relative;
        font-size: 11px;
        margin: 0;
        padding: 0;
        color: #3d498b;
        font-family: 'ForzaBook', arial, sans-serif;
        font-weight: normal;
        vertical-align: top;
        line-height: 11px;
    }

    .stat-bars-list li + li {
        margin-top: 6px;
    }

    .stat-bars-list .bar {
        padding: 0 4px;
        color: #fff;
        height: 18px;
        display: inline-block;
        position: relative;
        margin-right: 10px;
        line-height: 10px;
    }

    .stat-bars-list .bar table {
        width: 100%;
    }

    .stat-bars-list .bar .text {
        font-size: 13px;
        font-family: 'ForzaMedium', arial, sans-serif;
        font-weight: normal;
        width: 100%;
    }

    .stat-bars-list .bar .number {
        font-size: 10px;
        font-family: 'ForzaBold', arial, sans-serif;
        font-weight: normal;
    }

    .stat-bars-list .bar--red {
        background: #ea5566;
    }

    .stat-bars-list .bar--red:before {
        content: '';
        display: block;
        position: absolute;
        top: 0;
        right: -6px;
        width: 0;
        height: 0;
        border-style: solid;
        border-width: 9px 0 9px 6px;
        border-color: transparent transparent transparent #ea5566;
    }

    .stat-bars-list .bar--blue {
        background: #777eaf;
    }

    .stat-bars-list .bar--blue:before {
        content: '';
        display: block;
        position: absolute;
        top: 0;
        right: -6px;
        width: 0;
        height: 0;
        border-style: solid;
        border-width: 9px 0 9px 6px;
        border-color: transparent transparent transparent #777eaf;
    }

    .stat-bars-list .bar--pink {
        background: #ea7f8e;
    }

    .stat-bars-list .bar--pink:before {
        content: '';
        display: block;
        position: absolute;
        top: 0;
        right: -6px;
        width: 0;
        height: 0;
        border-style: solid;
        border-width: 9px 0 9px 6px;
        border-color: transparent transparent transparent #ea7f8e;
    }

    h4.subtitle {
        font-family: 'IdealSansBold', arial, sans-serif;
        font-size: 14px;
        font-weight: normal;
        line-height: 11px;
        margin: 20px 0 0 0;
    }

    h4.subtitle.no-top {
        margin: 0;
    }

    .colleges-choice-box {
        background: url('/report/img/bg-colleges-choice.png') 50% 50% no-repeat;
        position: relative;
        overflow: hidden;
        min-height: 180px;
    }

    .colleges-choice-box .bg {
        width: 100%;
        position: absolute;
        left: 0;
        top: 0;
        bottom: 0;
        z-index: 1;
    }

    .colleges-choice-box .col-left {
        width: 50%;
        position: relative;
        vertical-align: top;
    }

    .colleges-choice-box .col-right {
        width: 50%;
        position: relative;
        vertical-align: top;
    }

    .colleges-choice-box .col-left .colleges-list {
        margin: 0;
        padding: 52px 10px 0 62px;
        list-style: none;
    }

    .colleges-choice-box .col-right .colleges-list {
        margin: 0;
        padding: 52px 20px 0 34px;
        list-style: none;
    }

    .colleges-choice-box .colleges-list li {
        font-family: 'IdealSansLight', arial, sans-serif;
        font-size: 11px;
        font-weight: normal;
        line-height: 9px;
        margin-top: 8px;
        /*white-space: nowrap;*/
    }

    .colleges-choice-box .badge {
        font-family: 'ForzaBold', arial, sans-serif;
        color: #fff;
        font-size: 9px;
        line-height: 6px;
        display: block;
        position: absolute;
        top: 27px;
        height: 19px;
    }

    .colleges-choice-box .badge--left {
        width: 48px;
        left: 0;
        background: #eb6070;
        padding: 6px 5px 0 0;
        text-align: right;
    }

    .colleges-choice-box .badge--left:before {
        position: absolute;
        left: 0;
        top: 0;
        content: '';
        width: 0;
        height: 0;
        display: block;
        border-style: solid;
        border-width: 12px 0 12px 6px;
        border-color: transparent transparent transparent #E9F7FE;
    }

    .colleges-choice-box .badge--right {
        width: 60px;
        right: 0;
        background: #6e77a8;
        padding: 6px 0 0 4px;
        text-align: left;
    }

    .colleges-choice-box .badge--right:before {
        position: absolute;
        right: 0;
        top: 0;
        content: '';
        width: 0;
        height: 0;
        display: block;
        border-style: solid;
        border-width: 12px 6px 12px 0;
        border-color: transparent #E9F7FE transparent transparent;
    }

    .careers-box {
        margin-top: 20px;
        background: #E6DBE2;
        padding: 10px 20px;
        position: relative;
        height: 110px;
        width: 100%;
    }

    .careers-box h3 {
        font-family: 'IdealSansBold', arial, sans-serif;
        font-size: 20px;
        font-weight: normal;
        line-height: 16px;
        margin: 5px 0 5px 5px;
        padding: 0;

    }

    .careers-box p {
        font-family: 'ForzaBook', arial, sans-serif;
        font-size: 17px;
        font-weight: normal;
        line-height: 14px;
        margin: 0;
    }

    .careers-box p b {
        font-family: 'ForzaBold', arial, sans-serif;
        font-size: 17px;
        font-weight: normal;
        line-height: 14px;
        margin: 0;
    }

    .careers-box__content {
        width: 100%
    }

    .careers-box__content-img-holder {
        width: 90px;
    }

    .careers-box__content-img-holder img {
        vertical-align: top;
        width: 80px;
    }

    .careers-box .corner {
        width: 20px;
        height: 20px;
        position: absolute;
        z-index: 1;
    }

    .careers-box .corner-l-t {
        left: 0;
        top: 0;
        background: url(/report/img/careers-box-corner-l-t.png) 50% 50% no-repeat;
    }

    .careers-box .corner-r-t {
        right: 0;
        top: 0;
        background: url(/report/img/careers-box-corner-r-t.png) 50% 50% no-repeat;
    }

    .careers-box .corner-r-b {
        right: 0;
        top: 110px;
        background: url(/report/img/careers-box-corner-r-b.png) 50% 50% no-repeat;
    }

    .careers-box .corner-l-b {
        left: 0;
        top: 110px;
        background: url(/report/img/careers-box-corner-l-b.png) 50% 50% no-repeat;
    }

    .qualified-workers {

    }

    .qualified-workers h3 {
        font-family: 'IdealSansBold', arial, sans-serif;
        font-size: 20px;
        font-weight: normal;
        line-height: 16px;
        margin-top: 20px;
    }

    .qualified-workers .col-left {
        width: 35%;
    }

    .qualified-workers .col-right {
        width: 60%;
    }

    .qualified-workers p {
        font-family: 'IdealSansLight', arial, sans-serif;
        font-size: 16px;
        font-weight: normal;
        font-style: italic;
        line-height: 14px;
        margin: 0 20px 0 0;
    }

    .workers-table {
        margin-left: 10px;
        width: 100%;
        background: url('/report/img/table-bg-workers.png') 30px 50% no-repeat;
    }

    .workers-table th {
        font-family: 'ForzaMedium', arial, sans-serif;
        font-size: 11px;
        font-weight: normal;
        line-height: 10px;
        padding: 5px;
        text-align: center;
        vertical-align: top;
    }

    .workers-table td {
        padding: 8px 8px 7px 8px;
        border-bottom: 1px solid #6e77a8;
        line-height: 15px;
    }

    .workers-table tr.last-line td {
        border-bottom: none;
    }

    .workers-table td.first-col {
        font-family: 'IdealSansMedium', arial, sans-serif;
        font-size: 20px;
        font-weight: normal;
        font-style: italic;
    }

    .workers-table td.second-col {
        font-family: 'ForzaBlack', arial, sans-serif;
        font-size: 17px;
        font-weight: normal;
        text-align: center;
        color: #3d498b;
        border-right: 1px dotted #6e77a8;
    }

    .workers-table td.third-col {
        font-family: 'ForzaBlack', arial, sans-serif;
        font-size: 17px;
        font-weight: normal;
        text-align: center;
        color: #ee7785;
    }

    /* colors */
    .color-darkblue {
        color: #364386;
    }

    .color-midblue {
        color: #556099;
    }

    .color-lightblue {
        color: #6e77a8;
    }

    .color-lighten-blue {
        color: #868eb6;
    }

    /* COVER FRONT */

    .cover-wrapper-inner {
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        z-index: 1;
        background: #e9f7fe;
    }

    .cover-wrapper-inner .left-border {
        width: 15px;
        position: absolute;
        left: -15px;
        top: 0;
        bottom: -15px;
        background: #fff;
    }

    .cover-wrapper-inner .right-border {
        width: 15px;
        position: absolute;
        right: -15px;
        top: 0;
        bottom: -15px;
        background: #fff;
    }

    .cover-wrapper-inner .bottom-border {
        height: 15px;
        position: absolute;
        left: -15px;
        right: -15px;
        bottom: -15px;
        background: #fff;
    }

    .cover-top-right-corner {
        position: absolute;
        top: 0;
        right: 0;
        width: 40px;
        height: 40px;
    }

    .cover-bottom-right-corner {
        position: absolute;
        bottom: 0;
        right: 0;
        width: 40px;
        height: 40px;
    }

    .cover-top-right-corner img,
    .cover-bottom-right-corner img {
        width: 100%;
    }

    .cover-logo {
        position: absolute;
        top: 0;
        right: 40px;
        width: 60px;
        height: 60px;
    }

    .cover-logo img {
        width: 100%;
        vertical-align: top;
    }

    .cover-title {
        margin-top: 210px;
        text-align: center;
    }

    .cover-title img {
        vertical-align: top;
        width: 359px;
    }

    .cover-stars-box {
        position: relative;
        width: 361px;
        margin: 52px auto 0;
    }

    .cover-stars-box .state-map {
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        bottom: 0;
        width: 100%;
        z-index: 1;
        vertical-align: top;
    }

    .cover-stars-box .title-box {
        position: relative;
        z-index: 2;
        text-align: center;
    }

    .cover-stars-box .state-name {
        font-family: 'IdealSansLight', arial, sans-serif;
        font-weight: normal;
        font-size: 50px;
        line-height: 60px;
        margin: 130px 0 0 0;
    }

    .cover-stars-box .district-name {
        font-family: 'ForzaMedium', arial, sans-serif;
        font-style: italic;
        font-weight: normal;
        font-size: 20px;
        line-height: 24px;
        margin: 0;
    }

    .cover-content .cover-name {
        font-family: 'ForzaBook', arial, sans-serif;
        font-weight: normal;
        font-size: 26px;
        line-height: 30px;
        width: 320px;
        text-align: center;
        margin: 170px auto 0 auto;
    }

    /* COVER BACK */

    /* REPORT1  */
    .cover-back-wrapper {
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        padding: 0;
        z-index: 1;
        background: #e9f7fe;
    }

    .cover-back-wrapper .left-top-corner,
    .cover-back-wrapper .left-bottom-corner,
    .cover-back-wrapper .right-top-corner,
    .cover-back-wrapper .right-bottom-corner {
        width: 15px;
        height: 15px;
        position: absolute;
    }

    .cover-back-wrapper .left-top-corner {
        left: 0;
        top: 0;
    }

    .cover-back-wrapper .left-bottom-corner {
        left: 0;
        bottom: 0;
    }

    .cover-back-wrapper .right-top-corner {
        right: 0;
        top: 0;
    }

    .cover-back-wrapper .right-bottom-corner {
        right: 0;
        bottom: 0;
    }

    .cover-back-wrapper .left-top-corner img,
    .cover-back-wrapper .left-bottom-corner img,
    .cover-back-wrapper .right-top-corner img,
    .cover-back-wrapper .right-bottom-corner img {
        vertical-align: top;
        width: 100%;
    }

    .cover-back-table {
        width: 360px;
        margin: 480px auto 0 auto;
    }

    .cover-back-table-col-1 {
        text-align: right;
        padding-right: 20px;
        width: 166px;
        font-family: 'ForzaBook', arial, sans-serif;
        font-size: 18px;
        line-height: 16px;
        text-transform: uppercase;
    }

    .cover-back-table-col-2 {
        width: 28px;
    }

    .cover-back-table-col-2 img {
        width: 28px;
    }

    .cover-back-table-col-3 {
        text-align: left;
        padding-left: 20px;
        width: 166px;
    }

    .cover-back-table-col-3 img {
        width: 109px;
    }

    .cover-back-footer {
        position: absolute;
        left: 15px;
        right: 15px;
        top: 1000px;
    }

    .cover-back-footer-info {
        vertical-align: bottom;
    }

    .cover-back-footer-left {
        text-align: left;
        font-family: 'IdealSansMedium', arial, sans-serif;
        font-size: 12px;
        line-height: 12px;
        vertical-align: bottom;
    }

    .cover-back-footer-right {
        text-align: right;
        vertical-align: bottom;
    }

    .cover-back-footer-right img {
        width: 53px;
        vertical-align: middle;
        margin-bottom: 4px;
    }

    .cover-back-footer-info-bottom {
        font-family: 'IdealSansLight', arial, sans-serif;
        font-size: 8px;
        line-height: 10px;
        padding: 10px 0 0 0;
    }

    /*
        // START HERE
    */

    body {
        background: #ffffff;
    }

    .page_1 {
        position: absolute;
        top: 0;
        left: 0;
        width: 50%;
        height: 50%;
    }

    .page_1 .site-wrapper {
        transform: scale(0.5);
        top: -280px;
        bottom: 280px;
        left: -200px;
        right: -200px;
        overflow: hidden;
    }
    .page_1 .site-wrapper .cover-back-wrapper {
        bottom: 280px;
    }

    .page_1 .site-wrapper .cover-back-wrapper .right-bottom-corner {
        bottom: 280px;
    }

    .page_2 {
        position: absolute;
        top: 0;
        left: 50%;
        width: 50%;
        height: 50%;
    }

    .page_2 .site-wrapper {
        transform: scale(0.5);
        top: -280px;
        bottom: 280px;
        left: -200px;
        right: -200px;
        overflow: hidden;
    }

    .page_2 .site-wrapper .cover-wrapper-inner {
        bottom: 280px;
    }

    .page_2 .site-wrapper .cover-wrapper-inner .cover-bottom-right-corner {
        bottom: 280px;
    }

    .page_3 {
        position: absolute;
        top: 50%;
        left: 0%;
        width: 50%;
        height: 50%;
        background:  #e9f7fe;
    }
    .page_3 .site-wrapper {
        transform: scale(0.5);
        top: -121px;
        bottom: 280px;
        left: -200px;
        right: -200px;
        border: 0px;
        border-top: 80px solid white;
    }

    .page_3 .site-wrapper .site-wrapper-inner {
        border: none;
    }
    .page_3 .site-wrapper .site-wrapper-inner .site-wrapper-page-content {
        border: 0px;
    }



    .page_4 {
        position: absolute;
        top: 50%;
        left: 50%;
        width: 50%;
        height: 50%;
        background:  #e9f7fe;
    }
    .page_4 .site-wrapper {
        transform: scale(0.5);
        top: -121px;
        bottom: 280px;
        left: -200px;
        right: -200px;
        border: 0px;
        border-top: 80px solid white;
    }

    .page_4 .site-wrapper .site-wrapper-inner {
        border: none;
    }
    .page_4 .site-wrapper .site-wrapper-inner .site-wrapper-page-content {
        border: 0px;
    }

</style>


<?php
$l = strlen($recipient);

switch (true) {
    case ($l < 31):
        $cl = 's1';
        break;
    case ($l < 41):
        $cl = 's2';
        break;
    case ($l < 61):
        $cl = 's3';
        break;
    case ($l < 76):
        $cl = 's4';
        break;
    case ($l < 101):
        $cl = 's5';
        break;
    default:
        $cl = 's6';
        $recipient = wordwrap($recipient, 80, "<br />");
}
?>

<div class="page_1">
    <!-- cover-back -->
    <div class="site-wrapper">
        <div class="cover-back-wrapper">
            <div class="right-top-corner"><img src="report/img/cover-back-top-right-corner-@2x.png"/></div>
            <div class="right-bottom-corner"><img src="report/img/cover-back-bottom-right-corner-@2x.png"/></div>

            <div class="cover-back-info">
                <table class="cover-back-table">
                    <tr>
                        <td class="cover-back-table-col-1"><?= $state_name ?></td>
                        <td class="cover-back-table-col-2"><img src="report/img/cover-back-head-icon-@2x.png"/></td>
                        <td class="cover-back-table-col-3"><img src="report/img/cover-back-name-@2x.png"/></td>
                    </tr>
                </table>
            </div>

            <div class="cover-back-footer">
                <table class="cover-back-footer-info">
                    <tr>
                        <td class="cover-back-footer-left">www.act.org</td>
                        <td class="cover-back-footer-right"><img src="report/img/cover-back-logo-@2x.png"/></td>
                    </tr>
                    <tr>
                        <td colspan="2" class="cover-back-footer-info-bottom">
                            Sources: ACT. (2014). ACT test registration data. | ACT. (2014). The ACT National Career Readiness Certiﬁcate and job requirements. Retrieved from http://www.act.org/workkeys/briefs/ﬁles/NCRCRequirements.pdf. | National Student Clearinghouse (2015). Data matched to ACT test registration data. | Western Interstate Commission for Higher Education (2012). Knocking at the College Door: Projections of High School Graduates, 8th edition.
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="page_2">
    <!-- cover -->
    <div class="site-wrapper">
        <div class="cover-wrapper-inner">

            <div class="left-border"></div>
            <div class="right-border"></div>
            <div class="bottom-border"></div>

            <div class="cover-logo">
                <img src="report/img/cover-logo-@2x.png" alt="Logo"/>
            </div>

            <div class="cover-top-right-corner">
                <img src="report/img/cover-top-right-corner-@2x.jpg"/>
            </div>
            <div class="cover-bottom-right-corner">
                <img src="report/img/cover-bottom-right-corner-@2x.jpg"/>
            </div>

            <div class="cover-content">
                <div class="cover-title">
                    <img src="report/img/field-notes-@2x.png" alt="FIELD NOTES"/>
                </div>

                <div class="cover-stars-box">
                    <img class="state-map" src="report/img/states/<?= $state ?>-@2x.png"/>

                    <div class="title-box">
                        <h1 class="state-name"><?= $state_name ?></h1>

                        <h3 class="district-name"><?= $district ?> District</h3>
                    </div>
                </div>

                <h2 class="cover-name">ACT's Guide to Your Constituency</h2>
            </div>
        </div>
    </div>
</div>

<div class="page_3">
    <!-- page 1 -->
    <div class="site-wrapper">
        <div class="site-wrapper-inner">

            <div class="site-wrapper-page-content">


                <div class="page-header">
                    <div class="page-header__first-line">
                        <h3>ACT’s Guide to Your Constituency</h3>
                    </div>
                    <div class="page-header__second-line">
                        <table>
                            <tr>
                                <td class="page-header__second-line--left">
                                    <h1 class="<?= $cl ?>"><?= $recipient ?></h1>
                                </td>
                                <td class="page-header__second-line--right">
                                    <div class="border"></div>
                                    <p>
                                        Class of<span class="year"><?= $data['year'] ?></span>
                                    </p>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="arrow-line">
                    <table class="arrow-line__table">
                        <tr>
                            <td class="first-td">
                                <div class="td-box">
                                    <span><?= $students_count ?></span> students took at the ACT in <?= $data['year'] ?>. Of those, <strong><?= number_format($data['total_act_state']) ?> students</strong> were from your state
                                </div>
                            </td>
                            <td class="second-td"><span class="top-text">This Represents</span><span class="number"><?= $data['tested_percent'] ?>%</span> of your state’s <?= $data['year'] ?> high school graduates.</td>
                            <td class="arrows-center"></td>
                            <td class="arrow-right">
                                <div class="td-box">
                                    <span class="top">In your district</span>
                                    <span class="middle"><span class="middle-number"><?= number_format($data['total_act_district']) ?></span> students</span>
                                    <span class="bottom">took the ACT</span>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="page-content page-content--top-line">
                    <table>
                        <tr>
                            <!-- left col -->
                            <td class="page-content__left-col">
                                <div class="page-content__left-col-inner">
                                    <div class="graph-ethnic">
                                        <h3>What are your students’ racial/ethnic backgrounds?</h3>

                                        <div class="graph-ethnic__box">

                                            <!-- corners-->
                                            <div class="corner corner-l-t"></div>
                                            <div class="corner corner-r-t"></div>
                                            <div class="corner corner-r-b"></div>
                                            <div class="corner corner-l-b"></div>
                                            <!-- end corners -->

                                            <?php
                                            $d = [
                                                'white'            => 'n-dot--blue',
                                                'black'            => 'n-dot--rose',
                                                'hispanic'         => 'n-dot--gray',
                                                'asian'            => 'n-dot--blue-light',
                                                'pacific_islander' => 'n-dot--red',
                                                'native_american'  => 'n-dot--blue-lighten'
                                            ];
                                            foreach ($d as $color => $label) {
                                                $x = $data['district_backgrounds_percent'][$color];
                                                if ($x > 10) {
                                                    $p = round(log($x) * 17);
                                                    $s = 9 + round(log($x));
                                                    $t = round($p / 2 - $s / 2 - log($x) * 0.8);
                                                } else {
                                                    $p = round(log($x + 5) * 5);
                                                    $s = 10;
                                                    $t = 10;
                                                }

                                                $num = (string)number_format($data['district_backgrounds_percent'][$color], 2);
                                                $num = (substr($num, -1) == '0') ? substr($num, 0, -1) : $num;
                                                $num = (substr($num, -2) == '.0') ? substr($num, 0, -2) : $num;


                                                $r = round($p / 2);


                                                echo '<div class="n-dot ' . $label . ' ' . ($x <= 10 ? 'offset-text' : '') . '"
                                                           style="width: ' . $p . 'px;
                                                                  height: ' . $p . 'px;"><img src="report/img/' . $label . '.png" />
                                                          <div style="font-size: ' .  $s. 'px; line-height: '  . $s . 'px; padding-top: ' . $t . 'px; ">' . $num . '%</div>
                                                      </div>';
                                            }

                                            ?>
                                            <!-- end dots -->

                                            <!-- labels -->
                                            <div class="labels-line">
                                                <div class="label label--blue">White</div>
                                                <div class="label label--rose">Black</div>
                                                <div class="label label--gray">Hispanic</div>
                                                <div class="label label--blue-light">Asian</div>
                                                <div class="label label--red">Pacific Islander</div>
                                                <div class="label label--blue-lighten">Native American</div>
                                                <i>Two or more (<?= number_format($data['district_backgrounds_percent']['two_or_more'], 2) ?>%)</i> | <i>No response (<?= number_format($data['district_backgrounds_percent']['no_response_missing'], 2) ?>%)</i>
                                            </div>
                                            <!-- end labels -->
                                        </div>
                                    </div>

                                    <div class="graph-underrepresented">
                                        <h3>What percentage of your students come from underrepresented groups?</h3>

                                        <div class="graph-underrepresented__box">

                                            <!-- corners-->
                                            <div class="corner corner-l-t"></div>
                                            <div class="corner corner-r-t"></div>
                                            <div class="corner corner-r-b"></div>
                                            <div class="corner corner-l-b"></div>
                                            <!-- end corners -->


                                            <div class="left-side">
                                                <h4>How many live in <strong>first-generation</strong> households?</h4>
                                                <ul class="graph-cols">
                                                <li class="graph-col--left">
                                                    <span class="col-number" style="top: <?= ((95 + (100 / ($data['first_gen_district'] ? $data['first_gen_district'] : 1) * 0.04)) - round($data['first_gen_district'])) ?>px"><?= number_format($data['first_gen_district']) ?>%</span>
                                                    <span class="col col--red" style="top: <?= ((112 + (100 / ($data['first_gen_district'] ? $data['first_gen_district'] : 1) * 0.06)) - round($data['first_gen_district'])) ?>px; height: <?= (8 - (100 / ($data['first_gen_district'] ? $data['first_gen_district'] : 1) * 0.06)) + round($data['first_gen_district']) ?>px"></span>
                                                    <span class="col-name">District</span>
                                                </li>
                                                <li class="graph-col--right">
                                                    <span class="col-number" style="top: <?= ((95 + (100 / ($data['first_gen_state'] ? $data['first_gen_state'] : 1) * 0.04)) - round($data['first_gen_state'])) ?>px"><?= number_format($data['first_gen_state']) ?>%</span>
                                                    <span class="col col--red" style="top: <?= ((112 + (100 / ($data['first_gen_state'] ? $data['first_gen_state'] : 1) * 0.06)) - round($data['first_gen_state'])) ?>px; height: <?= (8 - (100 / ($data['first_gen_state'] ? $data['first_gen_state'] : 1) * 0.06)) + round($data['first_gen_state']) ?>px"></span>
                                                    <span class="col-name">State</span>
                                                </li>
                                                <li class="graph-median" style="top: <?= round(120 - ($data['first_gen_nation'] / 100 * 120) ) ?>px">
                                                    <span class="graph-line-name">Nation</span>
                                                    <span class="graph-line-number"><?= number_format($data['first_gen_nation']) ?>%</span>
                                                </li>
                                                </ul>
                                            </div>
                                            <div class="right-side">
                                                <h4>How many live in <strong>low-income</strong> households?</h4>
                                                <ul class="graph-cols">
                                                    <li class="graph-col--left">
                                                        <span class="col-number" style="top: <?= ((95 + (100 / ($data['low_income_district'] ? $data['low_income_district'] : 1) * 0.04)) - round($data['low_income_district'])) ?>px"><?= number_format($data['low_income_district']) ?>%</span>
                                                        <span class="col col--blue" style="top: <?= ((112 + (100 / ($data['low_income_district'] ? $data['low_income_district'] : 1) * 0.06)) - round($data['low_income_district'])) ?>px; height: <?= (8 - (100 / ($data['low_income_district'] ? $data['low_income_district'] : 1) * 0.06)) + round($data['low_income_district']) ?>px"></span>
                                                        <span class="col-name">District</span>
                                                    </li>
                                                    <li class="graph-col--right">
                                                        <span class="col-number" style="top: <?= ((95 + (100 / ($data['low_income_state'] ? $data['low_income_state'] : 1) * 0.04)) - round($data['low_income_state'])) ?>px"><?= number_format($data['low_income_state']) ?>%</span>
                                                        <span class="col col--blue" style="top: <?= ((112 + (100 / ($data['low_income_state'] ? $data['low_income_state'] : 1) * 0.06)) - round($data['low_income_state'])) ?>px; height: <?= (8 - (100 / ($data['low_income_state'] ? $data['low_income_state'] : 1) * 0.06)) + round($data['low_income_state']) ?>px"></span>
                                                        <span class="col-name">State</span>
                                                    </li>
                                                    <li class="graph-median" style="top:  <?= round(120 - ($data['low_income_nation'] / 100 * 120) ) ?>px">
                                                        <span class="graph-line-name">Nation</span>
                                                        <span class="graph-line-number"><?= number_format($data['low_income_nation']) ?>%</span>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <!-- end left col -->

                            <!-- right col -->
                            <td class="page-content__right-col">

                                <div class="page-content__right-col-inner">
                                    <h3>Are your students ready for college?</h3>

                                    <p>The ACT test is the most frequently taken college entrance exam in the U.S. The chart below shows the ACT Composite score distribution for students in your district, state, and nation.</p>
                                    <table class="table-act">
                                        <tr>
                                            <th class="first-col">ACT<br/>COMPOSITE</th>
                                            <th>DISTRICT</th>
                                            <th>STATE</th>
                                            <th>NATION</th>
                                        </tr>
                                        <tr class="first-line">
                                            <td class="first-col">1-18</td>
                                            <td><?= number_format($data['composite_score__19_district']) ?>%</td>
                                            <td><?= number_format($data['composite_score__19_state']) ?>%</td>
                                            <td><?= number_format($data['composite_score__19_nation']) ?>%</td>
                                        </tr>
                                        <tr class="second-line">
                                            <td class="first-col">19-23</td>
                                            <td><?= number_format($data['composite_score_19_23_district']) ?>%</td>
                                            <td><?= number_format($data['composite_score_19_23_state']) ?>%</td>
                                            <td><?= number_format($data['composite_score_19_23_nation']) ?>%</td>
                                        </tr>
                                        <tr class="third-line">
                                            <td class="first-col">24-36</td>
                                            <td><?= number_format($data['composite_score_24__district']) ?>%</td>
                                            <td><?= number_format($data['composite_score_24__state']) ?>%</td>
                                            <td><?= number_format($data['composite_score_24__nation']) ?>%</td>
                                        </tr>
                                        </tr>
                                    </table>
                                    <h3>...But college readiness is more than ONE number.</h3>

                                    <p>Along with their ACT Composite score, students also receive scores in four subject areas – Math, Science, English, and Reading – along with target (or “Benchmark”) scores that will help them gauge their likelihood of earning a B or C in credit-bearing first-year college courses. The percentages of students who met at least three of these four Benchmark scores are provided below.</p>

                                    <h3 class="top-m">STUDENTS IN YOUR DISTRICT WHO MET AT LEAST 3 OF 4 COLLEGE-READY BENCHMARK SCORES</h3>
                                    <table class="table-scores">
                                        <tr class="first-line">
                                            <td class="table-scores__title">Overall</td>
                                            <td class="table-scores__percents"><?= number_format($data['college_ready_benchmark_overall_district']) ?>%</td>
                                            <td class="table-scores__details">
                                                <table>
                                                    <tr>
                                                        <td class="align-right">State:</td>
                                                        <td><?= number_format($data['college_ready_benchmark_overall_state']) ?>%</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="align-right">Nation:</td>
                                                        <td><?= number_format($data['college_ready_benchmark_overall_nation']) ?>%</td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td class="table-scores__end-line"></td>
                                        </tr>
                                    </table>
                                    <table class="table-scores">
                                        <tr class="second-line">
                                            <td class="table-scores__title">First<br/>Generation</td>
                                            <td class="table-scores__percents"><?= number_format($data['college_ready_benchmark_first-generation_district']) ?>%</td>
                                            <td class="table-scores__details">
                                                <table>
                                                    <tr>
                                                        <td class="align-right">State:</td>
                                                        <td><?= number_format($data['college_ready_benchmark_first-generation_state']) ?>%</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="align-right">Nation:</td>
                                                        <td><?= number_format($data['college_ready_benchmark_first-generation_nation']) ?>%</td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td class="table-scores__end-line"></td>
                                        </tr>
                                    </table>
                                    <table class="table-scores">
                                        <tr class="third-line">
                                            <td class="table-scores__title">Low-Income</td>
                                            <td class="table-scores__percents"><?= number_format($data['college_ready_benchmark_low-income_district']) ?>%</td>
                                            <td class="table-scores__details">
                                                <table>
                                                    <tr>
                                                        <td class="align-right">State:</td>
                                                        <td><?= number_format($data['college_ready_benchmark_low-income_state']) ?>%</td>
                                                    </tr>
                                                    <tr>
                                                        <td class="align-right">Nation:</td>
                                                        <td><?= number_format($data['college_ready_benchmark_low-income_nation']) ?>%</td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td class="table-scores__end-line"></td>
                                        </tr>
                                    </table>
                                </div>

                            </td>
                            <!-- end right col -->
                        </tr>
                    </table>
                </div>


            </div>


        </div>

    </div>
</div>

<div class="page_4">
    <!-- page 2 -->
    <div class="site-wrapper">

        <div class="site-wrapper-inner">

            <div class="site-wrapper-page-content">

                <div class="page-content page-content--bottom-line">
                    <table>
                        <tr>
                            <td class="page-content__left-col">
                                <div class="page-content__left-col-inner no-top">

                                    <h3>How many students in your district<br>go to college?</h3>

                                    <p>Unfortunately, low-income and first-generation students lag behind their peers in their college enroll- ment rates. Below is a comparison of the college-going rates of these traditionally underrepresented students in your district, state, and nation.</p>

                                    <?php
                                    $sections = ['overall' => 'red', 'first-generation' => 'blue', 'low-income' => 'pink'];
                                    $divisions = ['district', 'state', 'nation'];
                                    ?>
                                    <div class="stat-bars">
                                        <?php foreach ($sections as $section => $color) : ?>
                                            <h2 class="box-title"><?= strtoupper($section) ?></h2>
                                            <ul class="stat-bars-list">
                                                <?php foreach ($divisions as $division) : ?>
                                                    <?php
                                                    $p = number_format($data['pse_'.$section.'_'.$division.'_percent']);
                                                    //$p = 70;
                                                    //$p = 270;
                                                    $w_p = 70 + $p * 2
                                                    ?>
                                                    <li>
                                                        <div class="bar bar--<?= $color ?>" style="width: <?= $w_p ?>px;">
                                                            <table>
                                                                <tr>
                                                                    <td class="text"><?= ucfirst($division) ?></td>
                                                                    <td class="number"><?= number_format($data['pse_' . $section . '_' . $division . '_percent']) ?>%</td>
                                                                </tr>
                                                            </table>
                                                        </div> <?= number_format($data['pse_' . $section . '_' . $division . '_number']) ?></li>
                                                <?php endforeach ?>
                                            </ul>
                                        <?php endforeach ?>
                                    </div>
                                </div>
                            </td>

                            <td class="page-content__right-col">
                                <div class="page-content__right-col-inner no-top">
                                    <h3>Are your students attending<br>their first choice college?</h3>

                                    <p>Where students send their ACT scores is a good indication of which colleges they would like to attend. More often than not, students from underrepresented groups are less likely than<br> their peers to enroll in their top choice colleges.</p>

                                    <h4 class="subtitle">Top 3 ﬁrst-choice and ﬁrst-enrolled colleges of all students</h4>

                                    <div class="colleges-choice-box">
                                        <table>
                                            <tr>
                                                <td class="col-left">
                                                    <span class="badge badge--left">FIRST CHOICE</span>
                                                    <ul class="colleges-list">
                                                        <li>1. <?= $data['top_3_fc'][0] ?></li>
                                                        <li>2. <?= $data['top_3_fc'][1] ?></li>
                                                        <li>3. <?= $data['top_3_fc'][2] ?></li>
                                                    </ul>
                                                </td>
                                                <td class="col-right">
                                                    <span class="badge badge--right">FIRST ENROLLED</span>
                                                    <ul class="colleges-list">
                                                        <li>1. <?= $data['top_3_fe'][0] ?></li>
                                                        <li>2. <?= $data['top_3_fe'][1] ?></li>
                                                        <li>3. <?= $data['top_3_fe'][2] ?></li>
                                                    </ul>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>

                                    <h4 class="subtitle no-top">Top 3 ﬁrst-choice and ﬁrst-enrolled colleges<br> of underrepresented students</h4>

                                    <div class="colleges-choice-box">
                                        <table>
                                            <tr>
                                                <td class="col-left">
                                                    <span class="badge badge--left">FIRST CHOICE</span>
                                                    <ul class="colleges-list">
                                                        <li>1. <?= $data['top_3_fc_g'][0] ?></li>
                                                        <li>2. <?= $data['top_3_fc_g'][1] ?></li>
                                                        <li>3. <?= $data['top_3_fc_g'][2] ?></li>
                                                    </ul>
                                                </td>
                                                <td class="col-right">
                                                    <span class="badge badge--right">FIRST ENROLLED</span>
                                                    <ul class="colleges-list">
                                                        <li>1. <?= $data['top_3_fe_g'][0] ?></li>
                                                        <li>2. <?= $data['top_3_fe_g'][1] ?></li>
                                                        <li>3. <?= $data['top_3_fe_g'][2] ?></li>
                                                    </ul>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="full-width-col">

                    <div class="careers-box">

                        <div class="corner corner-l-t"></div>
                        <div class="corner corner-r-t"></div>
                        <div class="corner corner-r-b"></div>
                        <div class="corner corner-l-b"></div>

                        <h3>STEM Careers: Are your students interested and ready?</h3>

                        <table class="careers-box__content">
                            <tr>
                                <td class="careers-box__content-img-holder">
                                    <img src="report/img/bg-careers-@2x.png"/>
                                </td>
                                <td>
                                    <p>In your state, <b><?= number_format($data['expressed_stem']) ?>%</b> of ACT-tested students from the class of 2014 reported being interested in either a STEM major or career. <b><?= number_format($data['measured_stem']) ?>%</b> are prepared for first-year college coursework related to these careers.</p>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <div class="qualified-workers">
                        <h3>Can your state match qualiﬁed workers with available jobs?</h3>

                        <table>
                            <tr>
                                <td class="col-left">
                                    <p>Across the country, thousands of high schools, community colleges, and employers use ACT’s National Career Readiness Certificate to provide a credential to match students with jobs, and match employees with training and advancement opportunities. There are four credentials – Platinum, Gold, Silver, and Bronze – each one corresponding to a particular skill level.</p>
                                </td>
                                <td class="col-right">
                                    <table class="workers-table">
                                        <tr>
                                            <th></th>
                                            <th>QUALIFIED FOR % OF JOBS IN WORKERS DATABASE</th>
                                            <th>CERTIFIED WORKERS IN YOUR STATE FOR JOBS AT THIS LEVEL</th>
                                        </tr>

                                        <?php

                                        foreach ([
                                                     'platinum' => ['99', 'color-darkblue'],
                                                     'gold'     => ['93', 'color-midblue'],
                                                     'silver'   => ['69', 'color-lightblue'],
                                                     'bronze'   => ['17', 'color-lighten-blue']
                                                 ] as $i => $_dtc) : ?>

                                            <tr>
                                                <td class="first-col"><span class="<?= $_dtc[1] ?>"><?= ucfirst($i) ?></span></td>
                                                <td class="second-col"><?= $_dtc[0] ?>%</td>
                                                <td class="third-col"><?= number_format($data['qw_aj_' . $i]) ?></td>
                                            </tr>
                                        <?php endforeach ?>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
