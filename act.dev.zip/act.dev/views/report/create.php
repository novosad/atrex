<?php
/**
 * @var yii\web\View                       $this
 * @var app\models\forms\report\CreateForm $model
 */

use app\models\Data;
use app\models\State;
use kartik\select2\Select2;
use yii\bootstrap\ActiveForm;
use yii\bootstrap\Button;
use yii\helpers\Url;

Url::remember();

$js = <<<JS
history.navigationMode = 'compatible';
$(document).ready(function(){
  $('#radio28').prop('checked', true);
});



$('.options input, select').on('change keyup paste input', function() {
    var _id = $(this).attr('name'), st = _id.match(/\[(.*)\]$/gm).toString().replace('[', '').replace(']', '');
    if (st.length) {
        $('#selected_' + st).html(st == 'template_id' ? $('input[name*="' + st + '"]:checked').parent().text() : $(this).val());
    }
});

$('select[name*=region]').on('change', function() {
    $('select[name*=state]').select2("val", "");
});

$('select[name*=state]').on('change', function() {
    $('select[name*=district]').select2("val", "");
});

$('input[type=radio][name*=template_id]').change(function() {
    if (this.value == 4) {
        $('.district_select_cnt').hide();
        $('.region_select_cnt').show();
    } else {
        $('.district_select_cnt').show();
        $('.region_select_cnt').hide();
    }
});
JS;

$this->registerJs($js, \yii\web\View::POS_END);
?>


<section class="page">
    <div class="container">

        <div class="page-info-wrapper">
            <div class="row">
                <div class="col-xs-12">
                    <h3 class="page__title no-desc">Create New Report</h3>
                </div>
            </div>
        </div>

        <?php
        $form = ActiveForm::begin([
            'options'                => [
                'class'   => 'create-form clearfix',
                'enctype' => 'multipart/form-data',
            ],
            'successCssClass'        => '',
            'enableClientValidation' => true,
            'validateOnSubmit'       => true,
            'validateOnBlur'         => true,
            'validateOnType'         => true,
        ])
        ?>


        <div class="row">
            <div class="table-wrapper clearfix">

                <div class="choose-template-layout">
                    <label>Choose A Template</label>

                    <div class="radio-boxes-row">

                        <div class="radio-box">
                            <input type="radio" class="radio-layout" id="radio18" name="CreateForm[template_id]" value="1">
                            <label class="radio-layout-label" for="radio18">
                                <span class="layout-type layout-type-full">
                                    <span class="layout-title">D/S</span>
                                </span>
                                District State Tabloid
                            </label>
                        </div>
                        <div class="radio-box">
                            <input type="radio" checked="checked" class="radio-layout" id="radio28" name="CreateForm[template_id]" value="2">
                            <label class="radio-layout-label" for="radio28">
                                <span class="layout-type layout-type-full">
                                    <span class="layout-title">D/S</span>
                                    <span class="layout-img"><img src="../img/template-img.png"/></span>
                                </span>
                                District State Tabloid AACC
                            </label>
                        </div>
                        <div class="radio-box half">
                            <input type="radio" class="radio-layout" id="radio38" name="CreateForm[template_id]" value="3">
                            <label class="radio-layout-label" for="radio38">
                                <span class="layout-type layout-type-half">
                                    <span class="layout-title">D/S</span>
                                </span>
                                District State Letter
                            </label>
                        </div>
                        <div class="radio-box half">
                            <input type="radio" class="radio-layout" id="radio48" name="CreateForm[template_id]" value="4">
                            <label class="radio-layout-label" for="radio48">
                                <span class="layout-type layout-type-half">
                                    <span class="layout-title">S/R</span>
                                </span>
                                State Region Letter
                            </label>
                        </div>
                    </div>
                </div>

                <div class="choose-template-filter">
                    <div class="row">
                        <div class="col-sm-4">
                            <?= $form->field($model, 'data_id', ['template' => "{label}<span class=\"act-dropdown dropdown-border\">{input}</span>{hint}{error}"])->dropDownList(Data::all(), ['encode' => false, 'prompt' => 'Select Data'])->label('Choose Data') ?>
                        </div>


                        <div class="col-sm-4 region_select_cnt required" style="display: none">
                            <?= $form->field($model, 'region', ['template' =>"{label}<span class=\"act-dropdown dropdown-border\">{input}</span>{hint}{error}"])->dropDownList(State::regions(), ['encode' => false, 'prompt' => 'Select Region'])->label('Select Region') ?>
                        </div>

                        <div class="col-sm-4 state_select_cnt">
                            <?php
                            echo $form->field($model, 'state')->widget(Select2::classname(), [
                                'options'       => ['placeholder' => 'Select a state ...'],
                                'hideSearch'    => true,
                                'pluginOptions' => [
                                    'allowClear' => false,
                                    'ajax'       => [
                                        'url'      => Url::to(['/report/available-states']),
                                        'dataType' => 'json',
                                        'data'     => new \yii\web\JsExpression('function(params) { return {region: $("input[type=radio][name*=template_id]:checked").val() == 4 ? $("#createform-region").val() : false }; }'),
                                        'cache'    => true
                                    ],
                                ],
                            ]);
                            ?>
                        </div>

                        <div class="col-sm-4 district_select_cnt required">
                            <?php
                            echo $form->field($model, 'district')->widget(Select2::classname(), [
                                'options'       => ['placeholder' => 'Select a district ...'],
                                'hideSearch'    => true,
                                'pluginOptions' => [
                                    'allowClear' => false,
                                    'ajax'       => [
                                        'url'      => Url::to(['/report/available-districts']),
                                        'dataType' => 'json',
                                        'data'     => new \yii\web\JsExpression('function(params) { return {data_id: $("#createform-data_id").val(), state: $("#createform-state").val() }; }'),
                                        'cache'    => true
                                    ],
                                ],
                            ]);
                            ?>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <label>Name Recipient</label>

                            <div class="form-group">
                                <input type="text" name="CreateForm[recipient]" class="form-control" maxlength="150">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <label>Number of ACT-tested Students</label>

                            <div class="form-group">
                                <input type="text" name="CreateForm[students_count]" class="form-control" value="X.X million" maxlength="20">
                            </div>
                        </div>

                    </div>
                </div>

                <div class="choose-template-action">
                    <?= Button::widget([
                        'label'       => 'Generate Preview',
                        'encodeLabel' => false,
                        'options'     => [
                            'class'             => 'btn btn-primary',
                            'data-loading-text' => 'Please wait...',
                            'type'              => 'submit',
                        ]
                    ]) ?>
                </div>
            </div>
        </div>
        <?php ActiveForm::end() ?>
    </div>
</section>
