<?php
/**
 * @var yii\web\View                $this
 * @var                             $filter
 * @var                             $status
 * @var                             $recent_data
 * @var yii\data\ActiveDataProvider $dataProvider
 */

use app\components\widgets\GridPager;
use app\models\Report;
use yii\grid\GridView;
use yii\helpers\Url;
use yii\widgets\Pjax;
use yii\helpers\Html;

Url::remember();

$update_url = Url::to(['report/update']);

$js = <<<JS
$(document).on('click', '#update-selected', function (e) {
    var _dt = jQuery.parseJSON($(this).attr('dataoptions'));
    if (typeof _dt.status != 'undefined') {
        var selected = [];

        $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]:checked').each(function() {
            selected.push($(this).val());
        });

        if ((selected.length)) {
            $.post("{$update_url}", {'ids': selected, 'status': _dt.status}, function(res) {
                if (res.success) {
                    $(document).trigger( "updateCounterEvent", 0);
                    $(document).trigger( "triggerReloadEvent", {});
                    showMessage('info', 'Successfully '  + _dt.status + ' ' + selected.length + ' report' + (selected.length > 1 ? 's' : '') );
                } else {
                    showMessage('error', res.error);
                }
            }, 'json').fail(function () {
                showMessage('error', 'Unexpected error');
            });
        }
    }
});



$(document).on('click', '.clickable-row td', function (e) {
    if ($(this).find('.checkbox-col').length == 0) {


        window.open( $(this).parent().data("href"));
    }
});

JS;

$this->registerJs($js, \yii\web\View::POS_END);
?>

<section class="page">
    <div class="container">
        <div class="page-info-wrapper">
            <div class="row">
                <div class="col-xs-12">
                    <h3 class="page__title">Welcome, <?= Yii::$app->user->identity->first_name ?></h3>
                    <p class="page__log-out"><a href="<?= Url::to(['/user/logout']) ?>">Log Out</a></p>
                </div>
            </div>
            <div class="row page-info__actions">
                <div class="col-sm-3 col-sm-offset-9 text-right">
                        <?php
                            if ($status == Report::STATUS_ARCHIVED) {
                                ?><a href="<?= Url::to(['/report/index', 'status' => Report::STATUS_ACTIVE]) ?>" role="tab">View Active Reports</a> <?php
                            } else {
                                ?><a href="<?= Url::to(['/report/index', 'status' => Report::STATUS_ARCHIVED]) ?>" role="tab">View Archived Reports</a><?php
                            }
                        ?>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="table-wrapper clearfix">
                <div class="table-wrapper__actions">
                    <div class="row">
                        <div class="col-sm-7">
                            <h4 class="table-wrapper__title"><?= $recent_data ? 'Most Recent Data Upload: ' . date('m/d/Y', $recent_data) : ''?></h4>
                        </div>
                        <div class="col-sm-5">
                            <div class="input-group table-action-filter">
                                <div class="search-wrapper <?= !isset($filter) && $dataProvider->getTotalCount() == 0 ? 'disabled' : '' ?>"> <!-- add .disabled -->
                                    <input type="text" value="<?= isset($filter) && isset($filter['search']) ? $filter['search'] : '' ?>" id="filter_search" placeholder="Search" class="form-control" <?= !isset($filter) && $dataProvider->getTotalCount() == 0 ? 'disabled' : '' ?> />
                                    <i class="fa fa-search"></i>
                                </div>
                                <div class="input-group-btn mass_actions">
                                    <button
                                        type="button"
                                        class="btn <?= $status == Report::STATUS_ACTIVE ? 'btn-primary' : 'btn-primary' ?> actions disabled"
                                        disabled="disabled"
                                        data-toggle='confirmation'
                                        data-id="update-selected"
                                        data-dataoptions='{"status": "<?= $status == Report::STATUS_ACTIVE ? Report::STATUS_ARCHIVED : Report::STATUS_ACTIVE ?>"}'
                                        data-href="javascript: void(0)"><i class="fa fa-archive"></i><span class="btn-label"><?= $status == Report::STATUS_ACTIVE ? 'Archive' : 'Un-Archive' ?></span>
                                    </button>
                                    <button
                                        type="button"
                                        class="btn btn-primary actions disabled"
                                        disabled="disabled"
                                        data-toggle='confirmation'
                                        data-id="update-selected"
                                        data-dataoptions='{"status": "<?= Report::STATUS_DELETED ?>"}'
                                        data-href="javascript: void(0)"><i class="fa fa-trash"></i><span class="btn-label">Delete</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-wrapper__data">
                    <?php
                    Pjax::begin(['id' => 'pjax_grid_view', 'timeout' => 60000, 'options' => ['class' => 'pjax-grid']]);

                    echo GridView::widget([
                        'dataProvider' => $dataProvider,
                        'rowOptions'   => function ($model) {
                            return [
                                'data-key' => $model['id'],
                                'data-href' => Url::to(['/report/view', 'id' => $model['id']]),
                                'class' => 'clickable-row',
                            ];
                        },
                        'columns'      => [
                            [
                                'class'           => 'yii\grid\CheckboxColumn',
                                'name'            => 'ids[]',
                                'contentOptions'  => ['class' => 'checkbox-col'],
                                'checkboxOptions' => function ($model) {
                                    $result = ['value' => $model->id];
                                    return $result;
                                }
                            ],
                            'data.year',
                            'state_name',
                            [
                                'attribute' => 'district',
                                'label' => 'District/Region',
                                'value' => function ($model) {
                                    return $model->district ? $model->district : 'Region: ' . $model->region;
                                }
                            ],
                            'recipient',
                            'template.type',
                            [
                                'attribute' => 'data.name',
                                'format' => 'raw',
                                'value' => function ($model) {
                                    $v = $model->data['name'];
                                    return str_replace(',', '<br>', $v);
                                }
                            ],
                            [
                                'attribute' => 'created',
                                'format'=>['DateTime','php:M d, Y, h:ia']
                            ],
                            /*
                            [
                                'class'          => 'yii\grid\ActionColumn',
                                'template'       => '{view}',
                                'buttons'        => [
                                    'view' => function ($url, $model) {
                                        return Html::a('<span class="glyphicon glyphicon-new-window"></span>', $url, ["data-pjax" => "0", 'target' => '_blank']);
                                    }
                                ],
                                'contentOptions' => ['class' => 'action-col'],
                            ]
                            */
                        ],
                        'layout'       => $dataProvider->getTotalCount() > 20 ? '{pager}{items}' : '{items}',
                        'pager'        => ['class' => GridPager::className()],
                        'tableOptions' => [
                            'class'         => 'list-table report-table fixed-header',
                            'id'            => 'list-table',
                            'total_count'   => $dataProvider->getTotalCount(),
                            'items_on_page' => count($dataProvider->getKeys()),
                        ]
                    ]);

                    Pjax::end();
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>
