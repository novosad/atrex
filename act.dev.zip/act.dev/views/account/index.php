<?php
/**
 * @var yii\web\View                        $this
 * @var                                     $filter
 * @var yii\data\ActiveDataProvider         $dataProvider
 * @var app\models\forms\account\CreateForm $model
 */

use app\components\widgets\GridPager;
use app\models\User;
use yii\bootstrap\ActiveForm;
use yii\grid\GridView;
use yii\helpers\Url;
use yii\widgets\Pjax;

Url::remember();

$delete_url = Url::to(['account/delete']);
$update_url = Url::to(['account/update']);

$js = <<<JS
$(document).on('click', '#delete-selected', function (e) {
    e.stopPropagation();
    var selected = [];
    $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]:checked').each(function() {
        selected.push($(this).val());
    });
    if ((selected.length)) {
        $.post("{$delete_url}", {'ids': selected}, function(res) {
            if (res.success) {
                $(document).trigger( "updateCounterEvent", 0);
                $(document).trigger( "triggerReloadEvent", {});
                showMessage('info', 'Successfully delete ' + selected.length + ' account' + (selected.length > 1 ? 's' : ''));

                var tc = $('.table-wrapper__title span'), u = tc.text(), _u = parseInt(u) - selected.length;
                tc.text(_u);
            } else {
                showMessage('error', res.error);
            }
        }, 'json').fail(function () {
            showMessage('error', 'Unexpected error');
        });
    }
});

$(document).on('click', '.hide-edit', function (e) {
    e.stopPropagation();
    var id = $(this).attr('data-id'),
        tr = $('#list-table').find('tr[data-key="' + id + '"]:first');

    $('#edit-' + id).remove();
    tr.show();
});

$(document).on('click', '#edit-user', function (e) {
    e.stopPropagation();
    var selected = [];
    $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]:checked').each(function() {
        selected.push($(this).val());
    });
    if (selected.length == 1) {
        var id = selected[0],
            tr = $('#list-table').find('tr[data-key="' + id + '"]:first'),
            td = tr.find('td'),
            first_name = '', last_name = '', role = '', email = '',
            i = 0;

        if ($('#edit-' + id).length) return;

        tr.find('td').each(function() {
            if (i == 1) first_name = $(this).text();
            if (i == 2) last_name = $(this).text();
            if (i == 3) role = $(this).text();
            if (i == 4) email = $(this).text();
            i++;
        });

        var html = '<tr class="edit-row" id="edit-' + id + '">' +
                   '      <td colspan="5" class="edit-td" style="display: inline-block;">' +
                   '          <div class="edit-form-wrapper">' +
                   '              <button type="button" class="hide-edit close" data-id="' + id + '" aria-label="Close"><span aria-hidden="true">&times;</span></button>' +
                   '              <form class="form-inline edit-form" action="{$update_url}?id='+id+'" method="POST">' +
                   '                  <input type="hidden" name="UpdateForm[id]"  value="' + id + '">' +
                   '                  <div class="form-group">' +
                   '                     <input type="text" class="form-control" name="UpdateForm[first_name]" placeholder="First Name" value="' + first_name + '">' +
                   '                  </div>' +
                   '                  <div class="form-group">' +
                   '                      <input type="text" class="form-control" name="UpdateForm[last_name]" placeholder="Last Name" value="' + last_name + '">' +
                   '                  </div>' +
                   '                  <div class="form-group">' +
                   '                      <span class="act-dropdown">' +
                   '                          <select name="admin-status" name="UpdateForm[role]" >' +
                   '                              <option selected="selected" disabled="disabled" value="">Admin Status</option>' +
                   '                              <option value="administrator" ' + (role == 'administrator' ? 'selected="selected"' : '') + '>administrator</option>' +
                   '                              <option value="manager"       ' + (role == 'manager' ? 'selected="selected"' : '') + '>manager</option>' +
                   '                          </select>' +
                   '                      </span>' +
                   '                  </div>' +
                   '                  <div class="form-group">' +
                   '                     <input type="email" name="UpdateForm[email]" class="form-control" placeholder="Email" value="' + email + '">' +
                   '                  </div>' +
                   '                  <button type="submit" class="btn btn-primary" style="margin-top:10px">Update User</button>' +
                   '              </form>' +
                   '          </div>' +
                   '      </td>' +
                   '</tr>';

        tr.hide();
        tr.after(html);
    }
});

$(document).on('click', '#pjax_grid_view input[type="checkbox"][name^="ids"]:not(:disabled)', function (e) {
    e.stopPropagation();
    var count = 0;
    $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]').each(function () {
        if ($(this).is(":checked")) {
            count++;
        }
    });
    $('#edit-user').prop('disabled', count == 1 ? false : true);
});


$(document).on('click', '#add-user', function (e) {
    e.stopPropagation();
    $('#add-user-cnt').show(300);
});

$(document).on('click', '#close-add-user', function (e) {
    e.stopPropagation();
    $('#add-user-cnt').hide(300);
});



JS;

$this->registerJs($js, \yii\web\View::POS_READY);
?>

<section class="page">
    <div class="container">

        <div class="page-info-wrapper">
            <div class="row">
                <div class="col-xs-12">
                    <h3 class="page__title no-desc">Manage Users</h3>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="table-wrapper clearfix">
                <div class="table-wrapper__actions">
                    <div class="row">
                        <div class="col-sm-3">
                            <h4 class="table-wrapper__title"><span><?= $dataProvider->getTotalCount() ?></span> Total Users</h4>
                        </div>
                        <div class="col-sm-3">
                            <div id="selected_count" style="margin-top: 10px;"></div>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group table-action-filter">
                                <div class="search-wrapper <?= !isset($filter) && $dataProvider->getTotalCount() == 0 ? 'disabled' : '' ?>"> <!-- add .disabled -->
                                    <input type="text" value="<?= isset($filter) && isset($filter['search']) ? $filter['search'] : '' ?>" id="filter_search" placeholder="Search" class="form-control" <?= !isset($filter) && $dataProvider->getTotalCount() == 0 ? 'disabled' : '' ?> />
                                    <i class="fa fa-search"></i>
                                </div>
                                <?php if(Yii::$app->user->identity->role == User::ROLE_ADMIN): ?>
                                <div class="input-group-btn mass_actions">
                                    <?php
                                    /*data-toggle="collapse" data-target="#add-user-cnt" aria-expanded="false" aria-controls="add-user-cnt"*/
                                    ?>
                                    <button class="btn btn-info do_not_disable" id="add-user" type="button"><i class="fa fa-plus"></i><span class="btn-label">New</span></button>
                                    <button disabled="disabled" id="edit-user" class="btn btn-primary" type="button"><i class="fa fa-pencil"></i><span class="btn-label">Edit</span></button>
                                    <button
                                        type="button"
                                        class="btn btn-primary disabled"
                                        disabled="disabled"
                                        data-toggle='confirmation'
                                        data-id="delete-selected"
                                        data-href="javascript: void(0)"><i class="fa fa-trash"></i><span class="btn-label">Delete</span></button>

                                </div>
                                <?php endif ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-wrapper__data">
                    <?php if($model): ?>
                    <div class="edit-form-wrapper" id="add-user-cnt" <?= $model->hasErrors() ? '' : 'style="display:none"'?>>
                        <?php
                        /*data-toggle="collapse" data-target="#add-user-cnt" aria-expanded="false" aria-controls="add-user-cnt"*/
                        ?>
                        <button type="button" class="close" id="close-add-user" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <?php
                        $form = ActiveForm::begin([
                            'options'                => [
                                'class'   => 'form-inline',
                                'enctype' => 'multipart/form-data',
                            ],
                            'successCssClass'        => '',
                            'enableClientValidation' => true,
                            'validateOnSubmit'       => true,
                            'validateOnBlur'         => false,
                            'validateOnType'         => false,
                        ])
                        ?>
                        <?= $form->field($model, 'first_name')->textInput(["placeholder" => "First Name"])->label(false) ?>
                        <?= $form->field($model, 'last_name')->textInput(["placeholder" => "Last Name"])->label(false) ?>
                        <?= $form->field($model, 'role', ['template' => "<span class='act-dropdown'>{input}</span>{hint}{error}"])->dropDownList([User::ROLE_ADMIN => User::ROLE_ADMIN, User::ROLE_MANAGER => User::ROLE_MANAGER], ['prompt' => 'Admin Status']) ?>
                        <?= $form->field($model, 'email')->textInput(["placeholder" => "Email"])->label(false) ?>
                        <button type="submit" class="btn btn-primary">Create User</button>
                        <?php ActiveForm::end() ?>
                    </div>
                    <?php endif ?>
                    <?php
                    Pjax::begin(['id' => 'pjax_grid_view', 'timeout' => 60000, 'options' => ['class' => 'pjax-grid']]);

                    echo GridView::widget([
                        'dataProvider' => $dataProvider,
                        'rowOptions'   => function ($model) {
                            return ['data-key' => $model['id']];
                        },
                        'columns'      => [
                            [
                                'class'           => 'yii\grid\CheckboxColumn',
                                'name'            => 'ids[]',
                                'contentOptions'  => ['class' => 'checkbox-col'],
                                'checkboxOptions' => function ($model) {
                                    $result = ['value' => $model->id];
                                    //Yii::$app->user->identity->getId() == $model->id && $result['disabled'] = 'disabled' && $result['title'] = "You can't delete yourself";
                                    return $result;
                                }
                            ],
                            'first_name',
                            'last_name',
                            'role',
                            'email',
                        ],
                        'layout'       => $dataProvider->getTotalCount() > 20 ? '{pager}{items}' : '{items}',
                        'pager'        => ['class' => GridPager::className()],
                        'tableOptions' => [
                            'class'         => 'list-table accounts-table fixed-header',
                            'id'            => 'list-table',
                            'total_count'   => $dataProvider->getTotalCount(),
                            'items_on_page' => count($dataProvider->getKeys()),
                        ]
                    ]);
                    Pjax::end();
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>
