<?php
/**
 * @var yii\web\View                $this
 * @var                             $filter
 * @var yii\data\ActiveDataProvider $dataProvider
 */

use app\components\widgets\GridPager;
use app\models\User;
use yii\grid\GridView;
use yii\helpers\Url;
use yii\widgets\Pjax;

Url::remember();

$delete_url = Url::to(['data/delete']);
$download_url = Url::to(['data/download']);

$js = <<<JS
$(document).on('click', '#delete-selected', function (e) {
    e.stopPropagation();
    var selected = [];
    $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]:checked').each(function() {
        selected.push($(this).val());
    });
    if ((selected.length)) {
        $.post("{$delete_url}", {'ids': selected}, function(res) {
            if (res.success) {
                $(document).trigger( "updateCounterEvent", 0);
                $(document).trigger( "triggerReloadEvent", {});
                showMessage('info', 'Successfully delete ' + selected.length + ' file' + (selected.length > 1 ? 's' : '') );
            } else {
                showMessage('error', res.error);
            }
        }, 'json').fail(function () {
            showMessage('error', 'Unexpected error');
        });
    }
});

$(document).on('click', '#download-selected', function (e) {
    e.stopPropagation();
    var selected = [];
    $('#pjax_grid_view input[type="checkbox"][name^="ids\[\]"]:checked').each(function() {
        selected.push($(this).val());
    });
    if ((selected.length)) {
        var ids = JSON.stringify(selected);
        window.location.href = '{$download_url}?ids=' + ids;
    }
});
JS;

$this->registerJs($js, \yii\web\View::POS_READY);

?>

<section class="page">
    <div class="container">
        <div class="page-info-wrapper">
            <div class="row">
                <div class="col-xs-12">
                    <h3 class="page__title no-desc">Manage Data</h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="table-wrapper clearfix">
                <div class="table-wrapper__actions">
                    <div class="row">
                        <div class="col-sm-6">
                            <h4 class="table-wrapper__title"><?= $dataProvider->getTotalCount() ? $dataProvider->getTotalCount() . ' Total' : 'No' ?> Data Submissions</h4>
                        </div>
                        <div class="col-sm-6">
                            <div class="input-group table-action-filter">
                                <div class="search-wrapper <?= !isset($filter) && $dataProvider->getTotalCount() == 0 ? 'disabled' : '' ?>"> <!-- add .disabled -->
                                    <input type="text" value="<?= isset($filter) && isset($filter['search']) ? $filter['search'] : '' ?>" id="filter_search" placeholder="Search" class="form-control" <?= !isset($filter) && $dataProvider->getTotalCount() == 0 ? 'disabled' : '' ?> />
                                    <i class="fa fa-search"></i>
                                </div>

                                <?php if(Yii::$app->user->identity->role == User::ROLE_ADMIN): ?>
                                <div class="input-group-btn mass_actions">
                                    <a href="<?= Url::to(['/data/upload']) ?>" class="btn btn-info" type="button"><i class="fa fa-plus"></i><span class="btn-label">New</span></a> <!-- add disabled="disabled" -->
                                    <button
                                        type="button"
                                        class="btn btn-primary disabled"
                                        disabled="disabled"
                                        id="download-selected"
                                        data-id="download-selected"
                                        data-href="javascript: void(0)"><i class="fa fa-download"></i><span class="btn-label">Download</span></button>
                                    <button
                                        type="button"
                                        class="btn btn-primary disabled"
                                        disabled="disabled"
                                        data-toggle='confirmation'
                                        data-id="delete-selected"
                                        data-href="javascript: void(0)"><i class="fa fa-trash"></i><span class="btn-label">Delete</span></button>
                                </div>
                                <?php endif ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="table-wrapper__data">
                    <?php
                    Pjax::begin(['id' => 'pjax_grid_view', 'timeout' => 60000, 'options' => ['class' => 'pjax-grid']]);

                    echo GridView::widget([
                        'dataProvider' => $dataProvider,
                        'rowOptions'   => function ($model) {
                            return ['data-key' => $model['id']];
                        },
                        'columns'      => [
                            [
                                'class'           => 'yii\grid\CheckboxColumn',
                                'name'            => 'ids[]',
                                'contentOptions'  => ['class' => 'checkbox-col'],
                                'checkboxOptions' => function ($model) {
                                    $result = ['value' => $model->id];
                                    return $result;
                                }
                            ],
                            'year',
                            [
                                'attribute' => 'created',
                                'format'=>['DateTime','php:M d Y h:ia']
                            ],
                            [
                                'attribute' => 'name',
                                'format' => 'raw',
                                'value' => function ($model) {
                                    $v = $model->name;
                                    return str_replace(',', '<br>', $v);
                                }
                            ],
                        ],
                        'layout'       => $dataProvider->getTotalCount() > 20 ? '{pager}{items}' : '{items}',
                        'pager'        => ['class' => GridPager::className()],
                        'tableOptions' => [
                            'class'         => 'list-table data-table fixed-header',
                            'id'            => 'list-table',
                            'total_count'   => $dataProvider->getTotalCount(),
                            'items_on_page' => count($dataProvider->getKeys()),
                        ]
                    ]);
                    Pjax::end();
                    ?>
                </div>
            </div>
        </div>
    </div>
</section>


