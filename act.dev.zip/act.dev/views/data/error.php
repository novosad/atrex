<?php
/**
 * @var yii\web\View                     $this
 * @var app\models\forms\data\UploadForm $model
 */

use yii\helpers\Url;

Url::remember();
?>

<section class="page">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-8 col-sm-offset-2">
                <div class="upload-page-info">
                    <h3 class="page__title">Upload Data</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sollicitudin pharetra est, eget facilisis quam aliquam vel. Proin sit amet felis ipsum. Nunc nec scelerisque lorem. Ut sit amet pharetra Phasellus eget ligula ac eros vehicula luctus a non nibh. Praesent bibendum egestas metus ut viverra. Nulla bibendum, metus nec ornare porttitor, ex diam tincidunt arcu, et interdum purus nisi vitae aenean a imperdiet dui, eu pellentesque. nisl. Duis non convallis lacus. Aenean varius condimentum.</p>
                </div>
                <div class="upload-area">
                    <h4 class="title-error">Upload Error</h4>
                    <i class="icon icon-error"></i>

                    <p class="error-message">Error message lorem ipsum dolor sit amet.</p>
                    <a class="btn btn-primary" href="#">Try Again</a>
                </div>
            </div>
        </div>
    </div>
</section>
