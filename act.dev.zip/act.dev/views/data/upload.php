<?php
/**
 * @var yii\web\View                     $this
 * @var app\models\forms\data\UploadForm $model
 */

use kartik\file\FileInput;
use yii\bootstrap\ActiveForm;
use yii\helpers\Url;

Url::remember();

$this->registerJs('var _dt = [];', \yii\web\View::POS_READY); // js var used for collecting responses while each file upload
?>

<section class="page">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-8 col-sm-offset-2">
                <div class="upload-page-info">
                    <h3 class="page__title">Upload Data</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin sollicitudin pharetra est, eget facilisis quam aliquam vel. Proin sit amet felis ipsum. Nunc nec scelerisque lorem. Ut sit amet pharetra Phasellus eget ligula ac eros vehicula luctus a non nibh. Praesent bibendum egestas metus ut viverra. Nulla bibendum, metus nec ornare porttitor, ex diam tincidunt arcu, et interdum purus nisi vitae aenean a imperdiet dui, eu pellentesque. nisl. Duis non convallis lacus. Aenean varius condimentum.</p>
                </div>

                <?php
                /* Seems ActiveForm not needed as we submit by ajax + Controller advise  */

                $form = ActiveForm::begin([
                    'options'                => [
                        'class'   => 'create-form clearfix',
                        'enctype' => 'multipart/form-data',
                    ],
                    'successCssClass'        => '',
                    'enableClientValidation' => true,
                    'validateOnSubmit'       => true,
                    'validateOnBlur'         => true,
                    'validateOnType'         => true,
                ])
                ?>

                <div class="row">
                    <div class="col-sm-12 data-file">
                        <?= $form->field($model, 'file')->widget(FileInput::classname(), [
                            'options'       => [
                                'multiple' => true,
                                'id'       => 'data-file-id'
                            ],
                            'pluginOptions' => [
                                'uploadUrl'               => Url::to(['/data/upload']),
                                'uploadAsync'             => true,
                                'allowedPreviewMimeTypes' => ['text/csv'],
                                'allowedFileExtensions'   => ['csv', 'txt'],
                                'dropZoneEnabled'         => true,
                                'dropZoneTitle'           => 'Drag and drop .CSV to upload',
                                'showRemove'              => false,
                                'showUpload'              => false,
                                'maxFileCount'            => 3,
                                'showPreview'             => true,
                                'maxFileSize'             => isset(Yii::$app->params['maxFileSize']) ? Yii::$app->params['maxFileSize'] : 1024 * 10,
                            ],
                            'pluginEvents'  => [
                                'filebatchselected'       => "function(event, files) { if (files.length == 3) { $('#data-file-id').fileinput('upload') } }",
                                'fileuploaded'  => "function(event, data) { var r = data.response.success;  _dt.push({id:r.id, file_name:r.file_name});     }",
                                'filebatchuploadcomplete' => "function(event, files, extra) { var f = JSON.stringify(_dt), url = '" . Url::to(['/data/create'], 1) . "?files=' + f; window.location.href = url }",
                            ],
                            'pluginLoading' => true,
                            'sortThumbs' => false,
                            'purifyHtml' => false
                        ]);
                        ?>
                    </div>
                </div>
                <?php ActiveForm::end() ?>
            </div>
        </div>
    </div>
</section>