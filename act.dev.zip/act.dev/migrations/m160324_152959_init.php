<?php

use yii\db\Migration;
use yii\helpers\BaseFileHelper;

class m160324_152959_init extends Migration
{
    public function up()
    {
        $this->createTable('user', [
            'id'           => 'pk',
            'first_name'   => 'varchar(256) NOT NULL',
            'last_name'    => 'varchar(256) NOT NULL',
            'email'        => 'varchar(256) NOT NULL',
            'password'     => 'varchar(256) NOT NULL',
            'role'         => 'varchar(15) NOT NULL',
            'created'      => "int(11) DEFAULT NULL",
            'updated'      => "int(11) DEFAULT NULL",
            'last_login'   => "int(11) DEFAULT NULL",
            'status'       => 'varchar(10) NOT NULL',
            'access_token' => 'varchar(256) NOT NULL',
            'reset_token'  => 'varchar(256) DEFAULT NULL',
        ]);

        $this->insert('user', [
            'first_name'   => 'Admin',
            'last_name'    => 'ACT',
            'email'        => 'admin@act.dev',
            'password'     => md5('admin'),
            'role'         => 'administrator',
            'created'      => time(),
            'status'       => 'active',
            'access_token' => Yii::$app->security->generateRandomString()
        ]);

        $this->createTable('data', [
            'id'        => 'pk',
            'name'      => 'varchar(512) NOT NULL',
            'file_data' => 'text',
            'year'      => 'varchar(4) NOT NULL',
            'user_id'   => 'int(11) NOT NULL',
            'status'    => 'varchar(10) NOT NULL',
            'processed' => 'tinyint DEFAULT 0',
            'created'   => "int(11) DEFAULT NULL",
            'updated'   => "int(11) DEFAULT NULL",
        ]);

        $this->createTable('report', [
            'id'             => 'pk',
            'template_id'    => 'int(11) NOT NULL',
            'data_id'        => 'int(11) NOT NULL',
            'state'          => 'varchar(256) NOT NULL',
            'state_name'     => 'varchar(256) NOT NULL',
            'district'       => 'varchar(256) DEFAULT NULL',
            'region'         => 'varchar(256) DEFAULT NULL',
            'recipient'      => 'varchar(256) NOT NULL',
            'students_count' => 'varchar(256) NOT NULL',
            'path'           => 'varchar(1024) NOT NULL',
            'status'         => 'varchar(10) NOT NULL',
            'user_id'        => 'int(11) NOT NULL',
            'created'        => "int(11) DEFAULT NULL",
            'updated'        => "int(11) DEFAULT NULL",
        ]);

        $this->createTable('template', [
            'id'      => 'pk',
            'type'    => 'varchar(256) NOT NULL',
            'path'    => 'varchar(1024) NOT NULL',
            'status'  => 'varchar(10) NOT NULL',
            'created' => "int(11) DEFAULT NULL",
            'updated' => "int(11) DEFAULT NULL",
        ]);

        $this->insert('template', [
            'type'    => 'District State Tabloid',
            'path'    => '1',
            'status'  => 'active',
            'created' => time()
        ]);

        $this->insert('template', [
            'type'    => 'District State Tabloid AACC',
            'path'    => '2',
            'status'  => 'active',
            'created' => time()
        ]);

        $this->insert('template', [
            'type'    => 'District State Letter',
            'path'    => '3',
            'status'  => 'active',
            'created' => time()
        ]);

        $this->insert('template', [
            'type'    => 'State Region Letter',
            'path'    => '4',
            'status'  => 'active',
            'created' => time()
        ]);


        // ----------------------------------------------------- cvs


        // Recode: Race/ethnicity
        // Student: Full Congressional district

        $this->createTable('store_ret', [
            'id'                  => 'pk',
            'data_id'             => 'int(11) NOT NULL',
            'state'               => 'varchar(256) NOT NULL',
            'district'            => 'varchar(256) NOT NULL',
            'white'               => 'integer DEFAULT 0',
            'black'               => 'integer DEFAULT 0',
            'hispanic'            => 'integer DEFAULT 0',
            'asian'               => 'integer DEFAULT 0',
            'pacific_islander'    => 'integer DEFAULT 0',
            'native_american'     => 'integer DEFAULT 0',
            'two_or_more'         => 'integer DEFAULT 0',
            'no_response_missing' => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_ret', 'store_ret', ['data_id', 'state', 'district']);

        // Recode: Potential first-gen college student
        // Student: Full Congressional district
        $this->createTable('store_pfg', [
            'id'       => 'pk',
            'data_id'  => 'int(11) NOT NULL',
            'state'    => 'varchar(256) NOT NULL',
            'district' => 'varchar(256) NOT NULL',
            'no'       => 'integer DEFAULT 0',
            'yes'      => 'integer DEFAULT 0',
            'undef'    => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_pfg', 'store_pfg', ['data_id', 'state', 'district']);

        // Recode: Family income ($36k or less)
        // Student: Full Congressional district
        $this->createTable('store_fin', [
            'id'       => 'pk',
            'data_id'  => 'int(11) NOT NULL',
            'state'    => 'varchar(256) NOT NULL',
            'district' => 'varchar(256) NOT NULL',
            'no'       => 'integer DEFAULT 0',
            'yes'      => 'integer DEFAULT 0',
            'undef'    => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_fin', 'store_fin', ['data_id', 'state', 'district']);

        // Recode: ACT Composite score [categorical]
        // Student: Full Congressional district
        $this->createTable('store_csc', [
            'id'       => 'pk',
            'data_id'  => 'int(11) NOT NULL',
            'state'    => 'varchar(256) NOT NULL',
            'district' => 'varchar(256) NOT NULL',
            '_19'      => 'integer DEFAULT 0',
            '19_23'    => 'integer DEFAULT 0',
            '24_'      => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_csc', 'store_csc', ['data_id', 'state', 'district']);

        // Recode: Met 3 or more benchmarks  -- 3 same sections with different data
        // Student: Full Congressional district
        $this->createTable('store_mmb', [
            'id'       => 'pk',
            'data_id'  => 'int(11) NOT NULL',
            'section'  => 'varchar(256) NOT NULL',
            'state'    => 'varchar(256) NOT NULL',
            'district' => 'varchar(256) NOT NULL',
            'no'       => 'integer DEFAULT 0',
            'yes'      => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_mmb', 'store_mmb', ['data_id', 'section', 'state', 'district']);

        // PSE: Student enrolled in college in Fall 2015 -- 3 same sections with different data
        // Student: Full Congressional district
        $this->createTable('store_pse', [
            'id'       => 'pk',
            'data_id'  => 'int(11) NOT NULL',
            'section'  => 'varchar(256) NOT NULL',
            'state'    => 'varchar(256) NOT NULL',
            'district' => 'varchar(256) NOT NULL',
            'no'       => 'integer DEFAULT 0',
            'yes'      => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_pse', 'store_pse', ['data_id', 'section', 'state', 'district']);

        // Recode: Race/ethnicity
        // Student: Home state of residence [alpha]
        // & store_ret

        // Recode: Potential first-gen college student
        // Student: Home state of residence [alpha]
        // &store_pfg

        // Recode: Family income ($36k or less)
        // Student: Home state of residence [alpha]
        // &store_fin

        // Recode: ACT Composite score [categorical]
        // Student: Home state of residence [alpha]
        // &store_csc

        // Recode: Met 3 or more benchmarks
        // Student: Home state of residence [alpha] ---- 3
        // &store_mmb

        // PSE: Student enrolled in college in Fall 2015
        // Student: Home state of residence [alpha] ---- 3
        // &store_pse


        // Recode: Expressed interest in STEM major or occupation
        // Student: Home state of residence [alpha]
        $this->createTable('store_smo', [
            'id'      => 'pk',
            'data_id' => 'int(11) NOT NULL',
            'state'   => 'varchar(256) NOT NULL',
            'no'      => 'integer DEFAULT 0',
            'yes'     => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_smo', 'store_smo', ['data_id', 'state']);

        // Recode: Measured STEM interest [Science or Technical]
        // Student: Home state of residence [alpha]
        $this->createTable('store_ist', [
            'id'      => 'pk',
            'data_id' => 'int(11) NOT NULL',
            'state'   => 'varchar(256) NOT NULL',
            'no'      => 'integer DEFAULT 0',
            'yes'     => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_ist', 'store_ist', ['data_id', 'state']);


        // Stores from txt file

        $this->createTable('store_cd', [
            'id'       => 'pk',
            'data_id'  => 'int(11) NOT NULL',
            'section'  => 'varchar(256) NOT NULL',
            'state'    => 'varchar(256) NOT NULL',
            'district' => 'varchar(256) NOT NULL',
            'inst'     => 'varchar(256) NOT NULL',
            'freq'     => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_cd', 'store_cd', ['data_id', 'section', 'state', 'district']);

        // we not use this data eat
        $this->createTable('store_st', [
            'id'      => 'pk',
            'data_id' => 'int(11) NOT NULL',
            'section' => 'varchar(256) NOT NULL',
            'state'   => 'varchar(256) NOT NULL',
            'inst'    => 'varchar(256) NOT NULL',
            'freq'    => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_st', 'store_st', ['data_id', 'section', 'state']);

        // we not use this data eat
        $this->createTable('store_nl', [
            'id'      => 'pk',
            'data_id' => 'int(11) NOT NULL',
            'section' => 'varchar(256) NOT NULL',
            'inst'    => 'varchar(256) NOT NULL',
            'freq'    => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_nl', 'store_nl', ['data_id', 'section']);

        /*
         *  separate cvs file
         */
        $this->createTable('store_ud', [
            'id'       => 'pk',
            'data_id'  => 'int(11) NOT NULL',
            'state'    => 'varchar(256) NOT NULL',
            'district' => 'varchar(256) NOT NULL',
            'percent'  => 'integer DEFAULT 0',
            'platinum' => 'integer DEFAULT 0',
            'gold'     => 'integer DEFAULT 0',
            'silver'   => 'integer DEFAULT 0',
            'bronze'   => 'integer DEFAULT 0',
        ]);
        $this->createIndex('i_ud', 'store_ud', ['data_id', 'state', 'district']);


        $uploadPath = isset(Yii::$app->params['uploadsPath']) ? Yii::$app->params['uploadsPath'] : '@runtime/uploads';
        $path = Yii::getAlias($uploadPath);
        BaseFileHelper::createDirectory($path, 0775);

        $reportsPath = isset(Yii::$app->params['reportsPath']) ? Yii::$app->params['reportsPath'] : '@runtime/reports';
        $path = Yii::getAlias($reportsPath);
        BaseFileHelper::createDirectory($path, 0775);
    }

    public function down()
    {
        echo "m160324_152959_init cannot be reverted.\n";

        return false;
    }
}
